"""Damped Newton with bounded Armijo and a scaled trust-step fallback."""

from functools import wraps

from mpmath import mp
from mpmath.calculus.optimization import MDNewton

from geosolver.runtime.deadline import check_deadline, count_event

from .refiner_config import LINE_SEARCH_MAX_STEPS


class _BoundedNewtonFailure(ValueError):
    def __init__(self, point, completed):
        super().__init__("bounded Newton did not converge")
        self.point, self.completed = point, completed


class LeastSquaresNewton(MDNewton):
    """Accept Newton steps by sufficient decrease of the least-squares merit.

    An overdetermined Newton step minimizes ||F + J s||_2. Its descent
    property is for ||F||_2**2, rather than mpmath's default infinity norm.
    Ordinary backtracking uses the existing LM limit. If a huge direction
    exhausts that limit, restart at a coordinate-scaled trust step rather than
    spending hundreds of trials merely bringing an overshoot into scale.
    """

    def __init__(self, ctx, function, initial, *, variable_scales=None, **kwargs):
        super().__init__(ctx, function, initial, **kwargs)
        self.variable_scales = variable_scales

    def __iter__(self):
        ctx, function, point = self.ctx, self.f, self.x0
        check_deadline()
        residual = ctx.matrix(function(*point))
        norm = ctx.norm(residual, 2)
        armijo = ctx.mpf("0.0001")
        trust_radius = ctx.one
        while True:
            check_deadline()
            jacobian = self.J(*point)
            step = ctx.lu_solve(jacobian, -residual)
            directional = ctx.fdot(residual, jacobian * step)
            if not ctx.isfinite(directional) or directional >= 0:
                count_event("newton_non_descent_directions")
                return
            scales = [
                abs(value)
                if value
                else (
                    ctx.mpf(self.variable_scales[index])
                    if self.variable_scales is not None
                    else ctx.one
                )
                for index, value in enumerate(point)
            ]
            ratio = max(abs(delta) / scale for delta, scale in zip(step, scales, strict=True))
            squared = norm * norm
            alpha = ctx.one
            accepted = False
            for restart in range(2):
                for _ in range(LINE_SEARCH_MAX_STEPS):
                    check_deadline()
                    trial = point + alpha * step
                    if trial == point:
                        count_event("newton_stagnant_steps")
                        return
                    values = ctx.matrix(function(*trial))
                    trial_norm = ctx.norm(values, 2)
                    if ctx.isfinite(trial_norm) and (
                        trial_norm < norm
                        and trial_norm * trial_norm <= squared + 2 * armijo * alpha * directional
                    ):
                        # Carry the successful step scale into the next local
                        # solve. This adapts near translated or narrow basins;
                        # the next full Newton proposal is still tried first.
                        trust_radius = min(ctx.one, 2 * alpha * ratio)
                        point, residual, norm = trial, values, trial_norm
                        yield point, norm
                        accepted = True
                        break
                    count_event("newton_backtracks")
                    alpha /= 2
                if accepted:
                    break
                if restart:
                    break
                if not ctx.isfinite(ratio) or ratio <= 0:
                    break
                trust_alpha = min(ctx.one, trust_radius / ratio)
                # Never revisit the ordinary trials already rejected. A
                # larger suggested trust radius still leaves the remaining
                # smaller Armijo steps available in this second local search.
                alpha = min(alpha, trust_alpha)
                count_event("newton_scaled_trust_restarts")
            if not accepted:
                count_event("newton_line_search_exhausted")
                return


def _findroot_bounded(function, initial, *, tol, maxsteps, J=None, variable_scales=None, **kwargs):
    """Run bounded Newton with mpmath's working precision and stop checks.

    mpmath.findroot unconditionally chooses MDNewton for vector functions,
    even when passed a custom solver. Run its iteration protocol explicitly.
    Full source certification is performed separately by the caller.
    """
    check_deadline()
    with mp.workprec(mp.prec + 20):
        initial_values = initial if isinstance(initial, list | tuple | mp.matrix) else (initial,)
        point = mp.matrix([mp.mpf(value) for value in initial_values])
        if any(not mp.isfinite(value) for value in point):
            raise ValueError("Newton initial coordinates must be finite")
        if variable_scales is not None and (
            len(variable_scales) != len(point)
            or any(not mp.isfinite(scale) or scale <= 0 for scale in variable_scales)
        ):
            raise ValueError("Newton variable scales must be positive and match dimension")

        def norm(values):
            return mp.norm(values, 2)

        values = mp.matrix(function(*point))
        initial_norm = norm(values)
        if not mp.isfinite(initial_norm):
            raise ValueError("Newton initial residual must be finite")
        if initial_norm == 0:
            return point
        options = {"norm": norm, "verbose": False, "variable_scales": variable_scales}
        if J is not None:
            options["J"] = J
        iterations = LeastSquaresNewton(mp, function, point, **options)
        completed = 0
        for index, (point, error) in enumerate(iterations, 1):
            completed = index
            if error < tol * max(1, norm(point)) or index >= int(maxsteps):
                break
        check_deadline()
        if not completed:
            raise _BoundedNewtonFailure(point, completed)
        final_norm = norm(mp.matrix(function(*point)))
        if not mp.isfinite(final_norm):
            raise ValueError("Newton final residual must be finite")
        if final_norm**2 > tol:
            raise _BoundedNewtonFailure(point, completed)
        return point


def findroot_least_squares(function, initial, *, tol, maxsteps, J=None, accept_root=None, **kwargs):
    """Try bounded least-squares proposals, retaining native convergence fallback.

    An arbitrary smooth function can require more than the bounded number of
    trials. Retry the original mpmath algorithm from the original starting point,
    with the original iteration budget and at the original working precision.
    """
    try:
        point = _findroot_bounded(function, initial, tol=tol, maxsteps=maxsteps, J=J, **kwargs)
        if accept_root is not None and not accept_root(point):
            raise ValueError("bounded Newton point failed original source admission")
        return point
    except (ValueError, ZeroDivisionError, OverflowError):
        check_deadline()
        count_event("newton_native_fallbacks")

        def checked_function(*point):
            check_deadline()
            values = function(*point)
            if not mp.isfinite(mp.norm(mp.matrix(values), 2)):
                raise ValueError("Native Newton residual must be finite")
            return values

        @wraps(J)
        def checked_jacobian(*point):
            check_deadline()
            values = J(*point)
            check_deadline()
            return values

        options = {"J": checked_jacobian} if J is not None else {}
        point = mp.findroot(checked_function, initial, tol=tol, maxsteps=maxsteps, **options)
        check_deadline()
        final_norm = mp.norm(mp.matrix(checked_function(*point)), 2)
        if not mp.isfinite(final_norm) or final_norm**2 > tol:
            raise ValueError("Native Newton fallback did not meet its residual tolerance") from None
        return point
