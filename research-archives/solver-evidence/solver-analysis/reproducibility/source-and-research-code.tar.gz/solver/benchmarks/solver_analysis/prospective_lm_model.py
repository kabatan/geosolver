"""Frozen analytic-recurrence predictions from known input-derived starts.

No production evaluator or optimizer is imported. This limited-computation
supplement does not change the original input-only forecasts. A 350-digit
analytic Jacobian recurrence predicts the finite native LM event under explicit
full-step and interior-domain assumptions; actual trajectories are read only
by the separate assessment command.
"""
import argparse, hashlib, json, time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from mpmath import mp
from exact_codec import dumps, loads

GEN='HMMT-NOV-2023-GEN-06'
PARA='GENERATED-PARABOLA-NORMAL-FOLD'
OBS='GENERATED-OBSERVER-OFFSET-CONTACT'


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    if p.exists(): raise FileExistsError(p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(dumps(v)+'\n')


def residual(ident,variant,x):
    if ident==GEN:
        a,t=x;u=a/2;h=u-t;v=(25-u*u+h*h)/10;R=mp.sqrt(u*u+v*v)
        f={'original':-h*h,'signed':-h,'resquared':h*h,
           'stable_gap':h*h/(R+abs(5-v))}[variant]
        return mp.matrix([f,2*R-6])
    if ident==OBS:
        h=x[0]
        return mp.matrix([{'original':-h*h,'signed':-h,'squared':h*h,
                          'stable_gap':h*h/(mp.sqrt(4+h*h)+2)}[variant]])
    if ident==PARA:
        t=x[0]
        if variant=='reduced':return mp.matrix([(t-1)**2*(t+2)/(2*t)])
        if variant=='reduced_signed':return mp.matrix([(t-1)*(t*t+t+1)/t])
        lam=x[1];g=1-lam+t*t
        f={'original':t*t/2+lam-mp.mpf('2.5'),'signed':g,'resquared':g*g}[variant]
        return mp.matrix([t*(1-lam)+1,f])
    raise ValueError(ident)


def interior(ident,x):
    if ident==GEN:
        a,t=x;u=a/2;h=u-t;v=(25-u*u+h*h)/10
        return 0<t<5 and a>0 and v>0 and 5-v>0
    if ident==OBS:return -1<x[0]<1
    if ident==PARA:return mp.mpf('.5')<x[0]<mp.mpf('1.5') and (len(x)==1 or 1<x[1]<3)
    return False


def recurrence(ident,variant,point,dps):
    x=mp.matrix(point);lam=mp.mpf('1e-6');floor=mp.mpf('1e-12');target=mp.power(10,-int(.7*dps))
    rows=[];small_count=0;status='max_iters';r=mp.norm(residual(ident,variant,x))
    for k in range(80):
        if r<=target:status='target_reached';break
        f=residual(ident,variant,x)
        J=mp.matrix([[mp.diff(lambda z:residual(ident,variant,[z if c==j else x[c] for c in range(len(x))])[i],x[j])
                      for j in range(len(x))] for i in range(len(f))])
        step=mp.lu_solve(J.T*J+lam*mp.eye(len(x)),-J.T*f);nxt=x+step
        rn=mp.norm(residual(ident,variant,nxt));I=(r-rn)/max(r,mp.mpf('1e-30'))
        row={'index':k,'x':list(x),'step':list(step),'lambda':lam,'norm':r,'next_norm':rn,
             'product_improvement':I,'small':I<mp.mpf('1e-10'),
             'full_step_improves':rn<r,'interior':bool(interior(ident,x) and interior(ident,nxt))}
        rows.append(row)
        if not row['interior'] or not row['full_step_improves']:
            status='abstain_full_step_assumption';break
        x=nxt;r=rn;lam=max(floor,lam/4)
        small_count=small_count+1 if row['small'] else 0
        if small_count>=5:status='stalled';break
    if status=='max_iters' and r<=target:status='target_reached'
    return {'steps':rows,'event':status,'step_count':len(rows),'final_x':list(x),
            'final_norm':r,'target':target,'first_five_small':len(rows)>=5 and all(z['small'] for z in rows[:5])}


def jobs(archive):
    paths=[('mid',archive/'unknown-local-v1/mid-plan.json'),
           ('final',archive/'unknown-local-v1/final-plan.json'),
           ('mid',archive/'unknown-intake/observer-contact-mid-v1/plan.json')]
    for split,path in paths:
        plan=json.loads(path.read_text())
        for group in plan['groups']:
            for job in group['jobs']:
                c=job['command'];dsl=Path(c[4]);out=Path(c[8]);d=json.loads(dsl.read_text());ident=d['id']
                if ident not in (GEN,PARA,OBS) or '/matched-runs/' in str(out):continue
                variant=out.stem.split('__')[-2]
                yield {'split':split,'case_id':ident,'variant':variant,'dsl':str(dsl),'dsl_sha256':sha(dsl),
                       'pool':c[6],'pool_sha256':sha(Path(c[6])),'index':int(c[7]),'dps':int(c[c.index('--dps')+1]),
                       'outcome':str(out),'plan':str(path),'plan_sha256':sha(path)}


def freeze(archive):
    dest=archive/'unknown-intake/finite-lm-supplement-v1';records=list(jobs(archive))
    assert records and not dest.exists()
    assert not any(Path(r['outcome']).exists() for r in records),'Cannot freeze after any selected outcome exists'
    begun=time.monotonic();created=datetime.now(timezone.utc).isoformat();pred=[]
    with mp.workdps(350):
        for r in records:
            start=time.monotonic();point=loads(Path(r['pool']).read_text())['points'][r['index']]['x']
            pred.append({**r,'prediction':recurrence(r['case_id'],r['variant'],point,r['dps']),
                         'compute_seconds':time.monotonic()-start})
    manifest={'created_utc':created,'completed_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(Path(__file__)),
        'base_forecast_sha256':sha(archive/'unknown-intake/individual-predictions-v1.json'),
        'information':'Only DSL, source algorithm constants, saved input-derived initial points and fixed plans. No selected optimizer trajectory or final outcome existed when called.',
        'category':'limited initial computation; analytic full-step recurrence, not bare-input classification or a new optimizer experiment',
        'derivation':'Explicit input geometry F and analytic J; delta=-(J^T J+lambda I)^-1 J^T F; lambda=max(1e-12,lambda/4) on each full accepted step; I=(r-r_next)/max(r,1e-30); stop after five I<1e-10, target or80 iterations.',
        'precision':350,'cost_includes':'all analytic residuals, derivatives and small linear solves for predicted trajectory',
        'limitations':['Manually selected 1 natural case and2 generated families with known charts; no global output claim.',
            'Full steps and domain interior are explicit assumptions; failure remains a reported abstention.',
            'Analytic derivative recurrence omits finite differences, arithmetic rounding, timeouts and hard-feasibility line shortening.',
            'Separate source-derived program simulation is a finite mechanism test, not an additional general theorem.',
            'Official source references had already been acquired separately; they are not read by this script or used as solver inputs.'],
        'scoring':{'first5_step_relative_tolerance':'1e-6','first5_norm_relative_tolerance':'1e-6',
                   'small_step_cutoff':'10**(-dps/2) excluded from relative-step scoring; absolute error retained',
                   'event':'exact named event, and step count separately (tolerance1)',
                   'later_goal_digits':'not predicted by this supplement',
                   'assumptions':'report unconditional failures and separate subset with first5 full accepted steps; no post hoc exclusion from denominators'},
        'rows':pred,'total_seconds':time.monotonic()-begun,'outcomes_existing_at_start':0}
    save(dest/'predictions.json',manifest)
    save(dest/'summary.json',{'created_utc':created,'predictions_sha256':sha(dest/'predictions.json'),
        'runs':len(pred),'by_split':dict(Counter(r['split'] for r in pred)),
        'predicted_events':dict(Counter(r['prediction']['event'] for r in pred)),
        'seconds':manifest['total_seconds'],'scope':manifest['category']})
    print((dest/'summary.json').read_text())


def analyze(archive,split,out):
    if out.exists():raise FileExistsError(out)
    forecast=archive/'unknown-intake/finite-lm-supplement-v1/predictions.json';data=loads(forecast.read_text());rows=[]
    with mp.workdps(350):
        for r in data['rows']:
            if r['split']!=split:continue
            p=r['prediction'];path=Path(r['outcome']);base={k:v for k,v in r.items() if k!='prediction'}
            base.update(predicted_event=p['event'],predicted_steps=p['step_count'])
            if not path.exists():rows.append({**base,'status':'missing'});continue
            actual=loads(path.read_text());events=[];pending=None
            for ev in actual['trace']:
                if ev['kind']=='lm_step':pending=ev
                elif ev['kind']=='line_search' and pending:
                    events.append((pending,ev));pending=None
            checks=[]
            for k,((lm,ls),q) in enumerate(zip(events,p['steps'])):
                step=mp.matrix(lm['output']);truth=mp.matrix(q['step']);point=mp.matrix(ls['input']['point'])
                output=ls.get('output');new=mp.matrix(output[0]) if output and output[0] is not None else point
                sn=mp.norm(truth);rel=mp.norm(step-truth)/sn if sn else None
                nr=ls['input']['current_norm'];norm_rel=abs(nr-q['norm'])/q['norm'] if q['norm'] else None
                full=bool(output and output[-1] and mp.norm(new-point-step)<=mp.mpf('1e-12')*max(mp.mpf('1e-300'),mp.norm(step)))
                rn=mp.norm(output[1]) if output and output[1] is not None else nr
                I=(nr-rn)/max(nr,mp.mpf('1e-30'))
                af=residual(r['case_id'],r['variant'],point)
                aj=mp.matrix([[mp.diff(lambda z:residual(r['case_id'],r['variant'],
                    [z if c==j else point[c] for c in range(len(point))])[i],point[j])
                    for j in range(len(point))] for i in range(len(af))])
                exactstep=mp.lu_solve(aj.T*aj+lm['input']['damping']*mp.eye(len(point)),-aj.T*af)
                localerr=mp.norm(step-exactstep)/mp.norm(exactstep) if mp.norm(exactstep) else None
                local_scored=mp.norm(exactstep)>mp.power(10,-mp.mpf(r['dps'])/2)
                rawf=mp.matrix(lm['input']['residual_vector'])
                assert len(rawf)>=len(af)
                # General6's third equality is OnSegment(T,C,D), identically
                # zero on the declared interior chart; retain its native noise.
                fullaf=mp.matrix(list(af)+[mp.mpf(0)]*(len(rawf)-len(af)))
                checks.append({'index':k,'relative_step_error':rel,'absolute_step_error':mp.norm(step-truth),
                    'step_scored':sn>mp.power(10,-mp.mpf(r['dps'])/2),
                    'step_pass':rel is not None and rel<=mp.mpf('1e-6'),
                    'relative_norm_error':norm_rel,'norm_pass':norm_rel is not None and norm_rel<=mp.mpf('1e-6'),
                    'actual_full_step':full,
                    'actual_chart_interior':bool(interior(r['case_id'],list(point)) and interior(r['case_id'],list(new))),
                    'same_point_step_relative_error':localerr,'same_point_step_scored':local_scored,
                    'same_point_step_pass':localerr is not None and localerr<=mp.mpf('1e-6'),
                    'same_point_residual_relative_error':mp.norm(fullaf-rawf)/mp.norm(af) if mp.norm(af) else None,
                    'predicted_small':q['small'],'actual_small':I<mp.mpf('1e-10'),
                    'small_agrees':q['small']==(I<mp.mpf('1e-10'))})
            event=actual['status'];count=len(events)
            rows.append({**base,'status':'assessed','source_sha256':sha(path),'actual_event':event,'actual_steps':count,
                'event_pass':event==p['event'],'step_count_pass':abs(count-p['step_count'])<=1,
                'first5':checks[:5], 'all_steps':checks,
                'first5_full_steps':len(checks)>=5 and all(c['actual_full_step'] for c in checks[:5]),
                'first5_full_steps_and_interior':len(checks)>=5 and all(c['actual_full_step'] and c['actual_chart_interior'] for c in checks[:5]),
                'all_actual_steps_compared':len(checks)==count,
                'all_steps_full_and_interior':len(checks)==count and all(c['actual_full_step'] and c['actual_chart_interior'] for c in checks),
                'all_scored_same_point_steps_pass':all(c['same_point_step_pass'] for c in checks if c['same_point_step_scored']),
                'actual_safety_deadline':actual.get('safety_deadline_hit'),'error':actual.get('error')})
    by=defaultdict(list)
    for r in rows:by[r['case_id']].append(r)
    summary=[]
    for ident,rr in by.items():
        checks=[c for r in rr for c in r.get('first5',[])];sc=[c for c in checks if c['step_scored']]
        ac=[c for r in rr for c in r.get('all_steps',[])];asc=[c for c in ac if c['same_point_step_scored']]
        summary.append({'case_id':ident,'planned':len(rr),'assessed':sum(r['status']=='assessed' for r in rr),
            'event_pass':sum(r.get('event_pass',False) for r in rr),'step_count_pass':sum(r.get('step_count_pass',False) for r in rr),
            'first5_full_step_runs':sum(r.get('first5_full_steps',False) for r in rr),
            'first5_assumption_runs':sum(r.get('first5_full_steps_and_interior',False) for r in rr),
            'first_steps':len(checks),'step_scored':len(sc),'step_pass':sum(c['step_pass'] for c in sc),
            'norm_pass':sum(c['norm_pass'] for c in checks),'small_agrees':sum(c['small_agrees'] for c in checks),
            'all_steps':len(ac),'all_steps_full':sum(c['actual_full_step'] for c in ac),
            'all_steps_interior':sum(c['actual_chart_interior'] for c in ac),
            'all_same_point_step_scored':len(asc),'all_same_point_step_pass':sum(c['same_point_step_pass'] for c in asc),
            'all_small_agrees':sum(c['small_agrees'] for c in ac),
            'all_steps_assumptions_runs':sum(r.get('all_steps_full_and_interior',False) for r in rr),
            'all_scored_same_point_steps_pass_runs':sum(r.get('all_scored_same_point_steps_pass',False) for r in rr),
            'baseline_always_stalled_correct':sum(r.get('actual_event')=='stalled' for r in rr),
            'baseline_always_max_iters_correct':sum(r.get('actual_event')=='max_iters' for r in rr),
            'baseline_always80_count_within1':sum(abs(r.get('actual_steps',-999)-80)<=1 for r in rr),
            'optimistic_fitted_precision_modal_event_correct':sum(max(Counter(r.get('actual_event') for r in rr if r['dps']==d).values()) for d in set(r['dps'] for r in rr))})
    save(out/'rows.json',{'rows':rows,'forecast_sha256':sha(forecast),'script_sha256':sha(Path(__file__))})
    save(out/'summary.json',{'split':split,'summary':summary,'forecast_sha256':sha(forecast)})
    print((out/'summary.json').read_text())


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['freeze','analyze']);p.add_argument('archive',type=Path)
    p.add_argument('--split',choices=['mid','final']);p.add_argument('--output',type=Path);a=p.parse_args()
    if a.mode=='freeze':freeze(a.archive)
    else:analyze(a.archive,a.split,a.output)
