"""Rebuild research figures from archived results with no solver imports.

Run in the report-only environment; never change the benchmark dependency lock.
Figures use final saved revisions, and final-return times rather than invented
first-answer times. Numeric conversion to binary64 occurs only after logarithms.
"""
import argparse,hashlib,json,math,statistics
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from mpmath import mp

COLORS=['#235b91','#31a392','#ef9b3b','#b3474c','#8561a8']
FONT='/usr/share/fonts/opentype/ipafont-gothic/ipagp.ttf'
font_manager.fontManager.addfont(FONT)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=FONT).get_name(),
    'font.size':10,'axes.titlesize':12,'axes.labelsize':10,'figure.dpi':140,
    'savefig.dpi':190,'axes.spines.top':False,'axes.spines.right':False,
    'axes.grid':True,'grid.color':'#d8e0e7','grid.alpha':.65,'axes.axisbelow':True,
    'svg.fonttype':'none','axes.unicode_minus':False})


def decode(v):
    if isinstance(v,list):return [decode(x) for x in v]
    if not isinstance(v,dict):return v
    if '@mpf' in v:return mp.make_mpf(tuple(map(int,v['@mpf'])))
    if '@float' in v:return float.fromhex(v['@float'])
    if '@tuple' in v:return tuple(decode(x) for x in v['@tuple'])
    if '@matrix' in v:return decode(v['@matrix'])
    if '@dataclass' in v:return {'_class':v['@dataclass'],**decode(v['fields'])}
    if '@model' in v:return {'_model':v['@model'],**decode(v['value'])}
    if '@enum' in v:return v['value']
    return {k:decode(x) for k,x in v.items()}


class Figures:
    def __init__(self,archive,out):self.a=archive;self.out=out;self.inputs={};self.figures=[];out.mkdir(parents=True,exist_ok=True)
    def read(self,name,lines=False):
        p=self.a/name
        self.inputs[str(p.relative_to(self.a))]=hashlib.sha256(p.read_bytes()).hexdigest()
        return [decode(json.loads(v)) for v in p.read_text().splitlines()] if lines else decode(json.loads(p.read_text()))
    def save(self,fig,name,caption):
        fig.savefig(self.out/(name+'.png'),bbox_inches='tight',facecolor='white')
        fig.savefig(self.out/(name+'.svg'),bbox_inches='tight',facecolor='white')
        plt.close(fig);self.figures.append({'name':name,'caption':caption})
    def baseline(self):
        stats=self.read('analysis/baseline-v1/strata.json');runs=self.read('analysis/baseline-v1/run-index.jsonl',True)
        fig,axs=plt.subplots(1,2,figsize=(10.6,3.4),gridspec_kw={'width_ratios':[1.1,1]})
        labels=['自由変数なし\n31問・155実行','1変数専用探索\n43問・215実行','多変数\n249問・1,245実行']
        kinds=['zero','scalar','multivariate'];names=['完全一致','一部の正答','同定で未出力','検証で未出力']
        for i,k in enumerate(kinds):
            r=stats[k];values=[r['matched'],r['any_answer']-r['matched'],r['numeric_feasible_reported']-r['any_answer'],r['runs']-r['numeric_feasible_reported']]
            left=0
            for j,v in enumerate(values):
                share=100*v/r['runs'];axs[0].barh(i,share,left=left,color=COLORS[j],height=.57,label=names[j] if i==0 else None)
                if share>3:axs[0].text(left+share/2,i,f'{v:,}',ha='center',va='center',color='white',fontsize=9)
                left+=share
        axs[0].set(yticks=range(3),yticklabels=labels,xlim=(0,100),xlabel='全実行に占める割合（%）',title='判定段階を分けた基準結果');axs[0].invert_yaxis()
        for i,k in enumerate(kinds):
            rr=[r for r in runs if r['stratum']==k];times=sorted(r['wall_seconds'] for r in rr if r['matched'])
            axs[1].step(times,np.arange(1,len(times)+1)/len(rr),where='post',color=COLORS[i],label=labels[i].split('\n')[0])
        axs[1].set(xscale='log',xlim=(.5,190),ylim=(0,1.02),xlabel='プロセス終了までの実時間（秒）',ylabel='完全一致の累積率（全実行分母）',title='失敗を分母に残した終了時間分布');axs[1].legend(fontsize=8,loc='lower right')
        axs[0].legend(ncol=2,bbox_to_anchor=(0,-.32),loc='upper left',fontsize=8)
        fig.tight_layout(w_pad=2)
        self.save(fig,'baseline-stages','全323問×5seed。数値配置はsolver診断。時刻は最終returnであり最初の正答の発見時刻ではない。')
    def jmo(self):
        rr=self.read('analysis/stage-v2b/rows.jsonl',True)
        rr=[r for r in rr if r['case_id']=='JMO-2013-PRE-05']
        fig,ax=plt.subplots(figsize=(8.4,3.7))
        for j,(prefix,label) in enumerate([('original','元残差'),('projection_squared','signedを再二乗'),('projection','signed一次')]):
            data=[];xs=[]
            for k,dps in enumerate((50,100,200)):
                vals=[r['pre_verifier_goal_digits'] for r in rr if r['condition']==prefix+'__lm'+str(dps)]
                if not vals:continue
                xpos=k+.045*(j-1.5);xs.append(xpos);data.append(np.percentile(vals,[25,50,75]))
                ax.scatter(np.full(len(vals),xpos)+np.random.default_rng(71+j+k).uniform(-.012,.012,len(vals)),vals,s=6,alpha=.12,color=COLORS[j])
            if data:
                values=np.array(data);ax.plot(xs,values[:,1],marker='o',color=COLORS[j],label=label)
                ax.vlines(xs,values[:,0],values[:,2],color=COLORS[j],lw=3)
        ax.axhline(20,color='#777',ls=':',lw=1);ax.text(2.12,20,'20桁',va='center',fontsize=8)
        ax.set(xticks=[0,1,2],xticklabels=['50','100','200'],xlabel='作業精度（dps）',ylabel='元の半径比の正確な桁数',title='JMO：精度を上げる効果は残差表現で異なる',ylim=(0,110),xlim=(-.25,2.35))
        ax.legend(ncol=2,loc='upper left',fontsize=9);fig.tight_layout()
        self.save(fig,'jmo-precision','同じ保持107開始点、最大80LM反復。点は個々の開始点、線は中央値、縦線は四分位範囲。verifier前の保存座標を独立式で評価。')
    def damping(self):
        paths=[f'development/damping-campaign-v1/runs/JMO-2013-PRE-05/0/original__floor_1e-24_carry_{i}.json' for i in (0,1)]
        if not all((self.a/p).exists() for p in paths):return
        fig,axs=plt.subplots(1,3,figsize=(8.4,3.4))
        with mp.workdps(400):
            def gd(x):
                th,p,q=x;c=mp.cos(th)
                value=q*mp.sqrt(p*p+4-4*p*c)/(p*mp.sqrt(q*q+81-18*q*c))
                return float(min(350,-mp.log10(max(mp.mpf('1e-350'),abs(value-mp.root(mp.mpf(2)/9,3))))))
            for i,path in enumerate(paths):
                r=self.read(path);events=[];pending=None
                for event in r['trace']:
                    if event['kind']=='lm_step':pending=event
                    elif event['kind']=='line_search' and pending:
                        if event['input']['dps']==100:events.append((pending,event))
                        pending=None
                if not events:continue
                indices=[];improvements=[];ratios=[];goal_digits=[]
                for k,(lm,ls) in enumerate(events):
                    if 'output' not in ls:continue
                    point,rv,ok=ls['output'];rn=ls['input']['current_norm']
                    if not ok or rv is None:continue
                    I=(rn-mp.norm(rv))/max(rn,mp.mpf('1e-30'))
                    J=mp.matrix(lm['input']['jacobian']);F=mp.matrix(lm['input']['residual_vector'])
                    sigmaeff=mp.norm(J.T*F)**2/mp.norm(F)**2 if mp.norm(F) else mp.mpf(0)
                    indices.append(k+1);improvements.append(float(max(mp.mpf('1e-320'),I)))
                    ratios.append(float(lm['input']['damping']/sigmaeff) if sigmaeff else np.nan)
                    goal_digits.append(gd(point))
                label='段階ごとに初期化' if i==0 else '前段のλを継続'
                for ax,values in zip(axs,(improvements,ratios,goal_digits)):
                    ax.plot(indices,values,color=COLORS[i],label=label,marker='o',ms=2,lw=1.4)
                    ax.set_xlabel('100桁段階のstep')
            axs[0].set(yscale='log',ylabel='実装の改善率 I',title='5回続く小さい改善')
            axs[0].axhline(1e-10,color='#777',ls=':',label='停止閾値 1e−10');axs[0].legend(fontsize=9)
            axs[1].set(yscale='log',ylabel='λ / σeff²',title='減衰状態の差')
            axs[2].set(ylabel='半径比の正確な桁数',title='元の目標精度')
            fig.tight_layout(w_pad=1.5)
        self.save(fig,'damping-stage','保持台帳の先頭点を固定して表示。元残差、λfloor=1e−24。100桁段階だけを比較し、全107点の効果と開始点の一致は本文の対応集計を参照。')
    def goal_pullback(self):
        with mp.workdps(120):
            hs=[mp.mpf(10)**(-mp.mpf(k)/10) for k in range(10,121)]
            xx=[];f=[];ga=[];gp=[];rat=[]
            for h in hs:
                u=mp.sqrt(h*h-25+10*mp.sqrt(9-h*h));v=(25-u*u+h*h)/10
                gap=3-(5-v);a=abs(mp.sqrt((u-h)**2+25)-mp.sqrt(30));p=abs(mp.sqrt(u*u+25)-mp.sqrt(30))
                xx.append(float(h));f.append(float(gap));ga.append(float(a));gp.append(float(p));rat.append(float(a/p))
        fig,axs=plt.subplots(1,2,figsize=(9.4,3.5))
        axs[0].loglog(xx,f,color=COLORS[0],label='接触残差（2次）');axs[0].loglog(xx,ga,color=COLORS[3],label='補助接点の距離誤差（1次）');axs[0].loglog(xx,gp,color=COLORS[1],label='物理的な垂足の距離誤差（2次）')
        axs[0].set(xlabel='接触座標 |h|',ylabel='独立式での誤差',title='同じ配置軌道に異なる目標を評価');axs[0].legend(fontsize=8)
        axs[1].loglog(f,ga,color=COLORS[3],label='補助目標：指数 1/2');axs[1].loglog(f,gp,color=COLORS[1],label='物理目標：指数 1')
        axs[1].set(xlabel='元の接触残差',ylabel='目標の絶対誤差',title='残差だけでは目標精度を区別できない');axs[1].legend(fontsize=8)
        fig.tight_layout(w_pad=2)
        self.save(fig,'goal-pullback','General6の他条件を厳密に消去した正のh枝を独立式で評価。solver軌道でも未知一般化の成績でもない。')
    def hmmt(self):
        rr=self.read('analysis/stage-v2b/rows.jsonl',True);rr=[r for r in rr if r['case_id']=='HMMT-2014-FEB-GEO-10']
        a={r['point_index']:r for r in rr if r['condition']=='original__native_refine'}
        b={r['point_index']:r for r in rr if r['condition']=='signed_contact__native_refine'}
        ids=sorted(set(a)&set(b));x=[a[i]['pre_verifier_goal_digits'] for i in ids];y=[b[i]['pre_verifier_goal_digits'] for i in ids]
        fig,ax=plt.subplots(figsize=(6.8,3.9));cap=55
        cc=[COLORS[1] if b[i]['pre_verifier_20digit_goal'] else COLORS[3] for i in ids]
        ax.scatter(np.clip(x,-3,cap),np.clip(y,-3,cap),c=cc,s=18,alpha=.65,edgecolors='white',linewidths=.3)
        ax.plot([-3,cap],[-3,cap],color='#aaa',lw=1);ax.axhline(20,color='#777',ls=':',lw=1)
        ax.set(xlim=(-3,cap+1),ylim=(-3,cap+1),xlabel='元残差：verifier前の目標精度（桁）',ylabel='signed：verifier前の目標精度（桁）',title='HMMT2014：一次化しても全開始点は回復しない')
        ax.text(.48,.2,'保持149開始点・同一点から再実行\n20桁到達：元残差 0 → signed 47\n55桁以上は上端に表示・重複点あり',transform=ax.transAxes,ha='left',va='top',fontsize=9)
        fig.tight_layout();self.save(fig,'hmmt-paired','緑はsigned腕で20桁以上、赤は未達。全点を表示し、合法な枝へ到達しなかった点を除外しない。')
    def prospective(self):
        files=[p for p in ('unknown-local-v1/probes/mid/summary.json','unknown-local-v1/probes/final/summary.json') if (self.a/p).exists()]
        rr=[r for p in files for r in self.read(p)['rows']];rows=[]
        for r in rr:
            for goal,v in r['goal_scoring'].items():
                if v['predicted_q'] is not None and v['measured_q'] is not None:
                    rows.append((r['case_id'],goal,float(v['ratio_q_over_m']),float(v['measured_q']/r['slopes']['residual']),bool(v['pass'])))
        if not rows:return
        names=sorted({r[0] for r in rows});fig,axs=plt.subplots(1,2,figsize=(10.5,4.4),gridspec_kw={'width_ratios':[1,1.3]})
        for i,name in enumerate(names):
            vv=[r for r in rows if r[0]==name];pred=[r[2] for r in vv];actual=[r[3] for r in vv]
            axs[0].scatter(pred,actual,s=22,alpha=.55,label=name.replace('HMMT-NOV-','').replace('CEMC-EUCLID-',''),marker=['o','s','^','D','v','P','X','*'][i%8])
        axs[0].plot([0,2.2],[0,2.2],color='#777',lw=1);axs[0].set(xlim=(0,2.2),ylim=(0,2.2),xlabel='事前予測の q/m',ylabel='独立評価の q/m',title='認証した方向の指数予測')
        axs[0].text(.03,.94,'同じ座標の観測点は重なる',transform=axs[0].transAxes,fontsize=8,va='top')
        errors=[]
        for name in names:
            vv=[r for r in rows if r[0]==name]
            errors.append([statistics.mean(abs(r[3]-p) for r in vv) for p in (.5,1)]+[statistics.mean(abs(r[3]-r[2]) for r in vv)])
        y=np.arange(len(names));ee=np.array(errors)
        for j,label in enumerate(('常に 1/2','常に 1','幾何からの個別予測')):
            axs[1].barh(y+(j-1)*.23,ee[:,j],height=.21,color=COLORS[j],label=label)
        short=[n.replace('HMMT-NOV-','').replace('CEMC-EUCLID-','Euclid-').replace('GENERATED-PARABOLA-NORMAL-FOLD','法線写像fold') for n in names]
        axs[1].set(yticks=y,yticklabels=short,xlabel='指数の絶対誤差の方向内平均',title='各問題内の誤差を別々に表示');axs[1].legend(fontsize=8,loc='upper right')
        fig.tight_layout(w_pad=1.7);self.save(fig,'prospective-orders','各点は証明した方向・目標。複数方向は独立した問題ではない。混合相殺方向は予測が保留なら指数比較へ入れない。')
    def hmmt_destinations(self):
        source='analysis/stage-v3/rows.jsonl' if (self.a/'analysis/stage-v3/rows.jsonl').exists() else 'analysis/stage-v2b/rows.jsonl'
        rr=self.read(source,True);fig,axs=plt.subplots(1,2,figsize=(10.2,3.7),sharex=True,sharey=True)
        for ax,name,label in zip(axs,('original__native_refine','signed_contact__native_refine'),('元残差','signed接触残差')):
            rows=[r for r in rr if r['case_id']=='HMMT-2014-FEB-GEO-10' and r['condition']==name]
            x=[float(r['pre_verifier_geometry']['r1']) for r in rows];y=[float(r['pre_verifier_geometry']['r2']) for r in rows]
            ax.scatter(x,y,s=17,color=COLORS[0],alpha=.5,edgecolors='white',linewidths=.3,label='保存した全149終了点')
            ax.scatter([1507415/640008],[1235/108],marker='*',s=150,color=COLORS[1],edgecolors='#173b32',lw=.6,zorder=5,label='解析した合法解')
            ax.scatter([0],[math.sqrt(260)],marker='x',s=65,color=COLORS[3],lw=1.5,zorder=5,label='禁止境界 r1=t=0')
            ax.set(xscale='symlog',xlim=(-.002,1e6),ylim=(-1,70),xlabel='第一円の半径 r1（0近傍は線形目盛）',title=label)
            ax.set_xscale('symlog',linthresh=.01)
        axs[0].set_ylabel('第二円の半径 r2');axs[1].legend(loc='upper right',fontsize=8)
        fig.tight_layout(w_pad=1.3)
        self.save(fig,'hmmt-destinations','同じ149開始点からの終了座標を、r1–r2平面へ投影。全点を表示し、禁止境界・合法解の記号は独立な解析値。重なった点は一つに見える。tと元条件の成立は別の検査表を参照。')
    def stop_certificates(self):
        root='unknown-intake/rootfree-stop-v1/'
        if not (self.a/(root+'assessment.json')).exists():return
        fig,axs=plt.subplots(1,2,figsize=(10.5,4.2),gridspec_kw={'width_ratios':[1,1.2]})
        for name,label,color in [('baseline','元の分母床 1e-30',COLORS[3]),('lower-denominator','分母床のみ 1e-80',COLORS[0])]:
            raw=self.read('development/denominator-pair-v1/'+name+'.json');norms=[]
            for ev in raw['trace']:
                if ev['kind']!='line_search' or not ev.get('output') or not ev['output'][-1]:continue
                if not norms:norms.append(ev['input']['current_norm'])
                with mp.workdps(400):norms.append(mp.sqrt(sum(v*v for v in ev['output'][1])))
            with mp.workdps(400):digits=[float(-mp.log10(v)) for v in norms]
            axs[0].plot(range(len(digits)),digits,label=label,color=color,lw=2.8 if name=='baseline' else 1.2,
                ls='-' if name=='baseline' else '--')
            axs[0].scatter([len(digits)-1],[digits[-1]],color=color,s=40,zorder=5)
        axs[0].axvline(38,color='#888',ls=':',lw=1)
        axs[0].set(xlabel='100桁段階の反復回数',ylabel='−log10（実際の残差ノルム）',title='座標が同じまま、停止だけが分かれる')
        axs[0].legend(fontsize=8,loc='lower right')
        rows=self.read(root+'assessment.json')['rows'];table_rows=[]
        for r in rows:
            label=('Euclid ' if r['case_id'].startswith('CEMC') else 'Guts ')+str(r['index']+1)
            pred={'five_small_stall':'5回で停止','target_within4':'4回以内target','abstain':'保留'}[r['prediction']]
            actual=f"{r['steps']}回 "+('停止' if r['actual_event']=='stalled' else 'target')
            table_rows.append([label,pred,actual])
        axs[1].axis('off');axs[1].set_title('初期量だけの事前認定と実測',pad=12)
        table=axs[1].table(cellText=table_rows,colLabels=['開始点','事前の判定','実測'],loc='center',cellLoc='left',colWidths=[.25,.39,.31])
        table.auto_set_font_size(False);table.set_fontsize(9);table.scale(1,1.55)
        for (i,j),cell in table.get_celld().items():
            cell.set_edgecolor('#d4dee7')
            if i==0:cell.set_facecolor('#e7eff5');cell.set_text_props(weight='bold')
            elif i in (5,6):cell.set_facecolor('#f0f0f0')
        fig.tight_layout(w_pad=1.5)
        self.save(fig,'stop-certificates','左：同じJMO段階入口から分母床だけを変更し、38回まで座標が完全一致。右：根中心でないpilot開始点からの有理上界による補足。各4開始は1自然問題で、全体は2問題。保留も表示。')
    def finish(self):
        value={'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'inputs':self.inputs,'figures':self.figures,'libraries':{'matplotlib':matplotlib.__version__,'numpy':np.__version__},'font':FONT}
        (self.out/'figure-manifest.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
        print(json.dumps({'figures':len(self.figures),'names':[v['name'] for v in self.figures]}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    f=Figures(a.archive,a.output);f.baseline();f.jmo();f.damping();f.goal_pullback();f.hmmt();f.hmmt_destinations();f.prospective();f.stop_certificates();f.finish()
