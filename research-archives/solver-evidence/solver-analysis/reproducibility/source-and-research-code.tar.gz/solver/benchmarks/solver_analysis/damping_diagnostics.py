"""Describe saved finite damping regimes without another optimizer call."""
import argparse,hashlib,json,statistics
from collections import defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps


def median(xs):
    xs=list(xs);return float(statistics.median(xs)) if xs else None


def analyze(campaign,out):
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);rows=[]
    with mp.workdps(400):
        paths=sorted((campaign/'runs/JMO-2013-PRE-05').glob('*/original__*.json'))
        expected=json.loads((campaign/'completion.json').read_text())['planned']
        assert len(paths)==expected,(len(paths),expected)
        for p in paths:
            raw=loads(p.read_text());pending=None;events=[]
            for ev in raw['trace']:
                if ev['kind']=='lm_step':pending=ev
                elif ev['kind']=='line_search' and pending:
                    if ev['input']['dps']==100 and ev.get('output') and ev['output'][-1]:
                        f=mp.matrix(pending['input']['residual_vector']);J=mp.matrix(pending['input']['jacobian'])
                        r=ev['input']['current_norm'];rn=mp.norm(ev['output'][1]);true=(r-rn)/r if r else 0
                        prod=(r-rn)/max(r,mp.mpf('1e-30'));sig=mp.norm(J.T*f)**2/mp.norm(f)**2 if mp.norm(f) else 0
                        events.append({'norm':r,'next_norm':rn,'product_improvement':prod,'true_relative_improvement':true,
                            'residual_floor_factor':min(1,r/mp.mpf('1e-30')),
                            'lambda_over_sigmaeff_squared':pending['input']['damping']/sig if sig else None})
                    pending=None
            ratios=[e['lambda_over_sigmaeff_squared'] for e in events if e['lambda_over_sigmaeff_squared'] is not None]
            row={'point_index':int(p.parent.name),'condition':p.stem,'source':str(p),
                'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'accepted_stage100_steps':len(events),
                'minimum_lambda_over_sigmaeff_squared':min(ratios,default=None),
                'maximum_lambda_over_sigmaeff_squared':max(ratios,default=None),
                'first5':events[:5],'last5':events[-5:],
                'last5_product_small':len(events)>=5 and all(e['product_improvement']<mp.mpf('1e-10') for e in events[-5:]),
                'last5_true_not_small':len(events)>=5 and all(e['true_relative_improvement']>=mp.mpf('1e-10') for e in events[-5:]),
                'last5_all_below_residual_floor':len(events)>=5 and all(e['norm']<mp.mpf('1e-30') for e in events[-5:])}
            rows.append(row)
    by=defaultdict(list)
    for r in rows:by[r['condition']].append(r)
    summary=[]
    for condition,rr in sorted(by.items()):
        summary.append({'condition':condition,'n':len(rr),
            'median_max_lambda_over_sigmaeff_squared':median(r['maximum_lambda_over_sigmaeff_squared'] for r in rr if r['maximum_lambda_over_sigmaeff_squared'] is not None),
            'last5_product_small':sum(r['last5_product_small'] for r in rr),
            'last5_small_due_to_floor':sum(r['last5_product_small'] and r['last5_true_not_small'] and r['last5_all_below_residual_floor'] for r in rr),
            'median_last_true_improvement':median(r['last5'][-1]['true_relative_improvement'] for r in rr if r['last5'])})
    (out/'rows.jsonl').write_text(''.join(dumps(r)+'\n' for r in rows))
    result={'summary':summary,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'Post hoc diagnostic of completed development trajectories. No threshold was fitted or changed; not a new prospective prediction.'}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('campaign',type=Path);p.add_argument('output',type=Path);a=p.parse_args();analyze(a.campaign,a.output)
