"""Isolate proposal continuation from frozen natural exactification inputs.

No geometry evaluation, verifier, known answer, or expected polynomial is used.
The intervention only propagates the existing outer root-distance acceptance
test into polynomial enumeration; rejected relations no longer stop that loop.
This is an experimental monkeypatch; product files remain untouched.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
from unittest.mock import patch
from mpmath import mp
from exact_codec import dumps
from stage_replay import ensure_source,save
from geosolver.runtime.symbolic_operations import dispatch,decode_identification
from geosolver.runtime.deadline import runtime_session
import geosolver.exact.polynomial_search as ps


def run(raw,index,mode,seconds):
    ensure_source()
    document=json.loads(raw.read_text())
    record=document['solver_result']['diagnostics']['pipeline_summary']['exact_candidate_records'][index]
    c=record['candidate']
    with mp.workdps(600):
        residual=mp.mpf(c['residual_norm_hp'])
        tier='strict' if residual<=mp.mpf('1e-70') else 'standard' if residual<=mp.mpf('1e-55') else 'relaxed'
        value=mp.mpf(c['answer_hp']);uncertainty=mp.mpf(c['answer_uncertainty'])
        payload={'precision':c['answer_precision_dps'],'value':value._mpf_,
                 'uncertainty':uncertainty._mpf_,'tier':tier,'reusable_results':[],
                 'prefer_affine_pi':False,'closed_source':None}
    result=run_payload(payload,mode,seconds)
    return {**result,'raw_path':str(raw),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),
        'record_index':index,'candidate_uid':c['candidate_uid'],'revision':c['revision'],
        'archived_result':record['exact_result'],
        'limitations':['Archived decimal input has >=550 digits; exact binary event capture is used for new runs.',
          'Fresh symbolic call with empty reusable results: natural case had no previously accepted descriptors.',
          'Polynomial continuation can still revisit a rejected relation and need not find the true relation.']}


def run_payload(payload,mode,seconds):
    """Run only the frozen symbolic input, without evaluating geometry."""
    ensure_source();trace=[]
    uncertainty=mp.make_mpf(tuple(payload['uncertainty']))
    original=ps.verify_polynomial
    def verify(coefficients,r,precision):
        accepted=original(coefficients,r,precision)
        row={'coefficients':tuple(coefficients),'discovery_precision':precision,'inner_accepted':accepted}
        if accepted:
            with mp.workdps(payload['precision']+50):
                distance=ps.nearest_real_root_distance(coefficients,r)
                # Same outer threshold; negligible root evaluation allowance.
                allowed=uncertainty+(abs(r)+uncertainty)*mp.power(10,-(payload['precision']+40))
                row.update(root_distance=distance,allowed_distance=allowed,outer_accepted=bool(distance<=allowed))
            if mode=='continue_after_rejection':accepted=accepted and row['outer_accepted']
        trace.append(row)
        return accepted
    begun=time.monotonic();status='completed';result=None;error=None
    with runtime_session(begun+seconds),patch.object(ps,'verify_polynomial',verify):
        try:result=decode_identification(dispatch('identify',payload))
        except Exception as exc:status='error';error=type(exc).__name__+': '+str(exc)
    return {'schema':2,'source_hash':ensure_source(),
        'input_payload':payload,'input_sha256':hashlib.sha256(dumps(payload).encode()).hexdigest(),
        'mode':mode,'status':status,
        'result':result,'trace':trace,'seconds':time.monotonic()-begun,'safety_seconds':seconds,'error':error}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('raw',type=Path);p.add_argument('index',type=int);p.add_argument('output',type=Path)
    p.add_argument('--mode',choices=['original','continue_after_rejection'],default='original');p.add_argument('--seconds',type=float,default=30)
    a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    result=run(a.raw,a.index,a.mode,a.seconds);save(a.output,result)
    print(json.dumps({'output':str(a.output),'status':result['status'],'error':result['error'],
        'exact_status':getattr(result['result'],'exact_status',None),'seconds':result['seconds'],'proposals':len(result['trace'])}))
