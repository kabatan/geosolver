"""CEMC source-to-DSL adaptation; no solver or reference calls."""
from itertools import permutations
from unknown_authoring import put,eq,gt,lt,pred,pos,segment


def cemc():
    out=[]
    put(out,'CEMC-EG-01','k',[
        ('A','Point(3,0)'),('B','Point(0,0)'),('C','Point(0,-4)'),('D','Point(3+4*k,-3*k)')],
        [eq('Distance(C,D)',13),gt('k')],'Area(A,B,C,D)',
        'Diagram fixes D on the opposite side of AC from B; k>0 on the perpendicular ray at A. AB=3,BC=4 and both right angles are constructions.')
    put(out,'CEMC-EG-03','r s',[],
        [eq('r+s',10),eq('2*pi*r-2*pi*s',3),gt('r','s'),gt('s')],'pi*r**2-pi*s**2',
        'r is the larger positive radius. Circumference and disk-area formulas implement the stated measurements directly.')
    put(out,'CEMC-EG-04','',[
        ('A','Point(0,0)'),('B','Point(20,0)'),('C','Point(0,20)'),('pan','Circumcircle(A,B,C)')],
        [],'(pi*20**2/4)/(pi*Radius(pan)**2)',
        'Source sector has fixed radius20 and right angle; pan passes through the three specified points.')
    put(out,'CEMC-EG-05','w h e',[
        ('A','Point(0,h)'),('B','Point(w,h)'),('C','Point(w,0)'),('D','Point(0,0)'),('E','Point(e,0)'),('F','Intersect(Line(A,E),Line(B,D))')],
        [eq('Distance(A,F)',4),eq('Distance(D,F)',2),eq('Dot(Vector(A,E),Vector(B,D))')]+pos('w','h','e')+[lt('e','w')],
        'Area(B,C,E,F)','Positive rectangle with E in the interior of DC as drawn; F is the stated perpendicular intersection.')
    put(out,'CEMC-EG-08','a theta',[
        ('O','Point(0,0)'),('omega','Circle(O,1)'),('B','Point(-1,0)'),('A','Point(-1,a)'),('C','Point(-1,-a-1)'),
        ('E','Point(cos(theta),sin(theta))'),('V','Point(A.x+sin(35*pi/180),A.y-cos(35*pi/180))'),
        ('F','Intersect(Line(A,V),PerpendicularLine(Line(O,E),E))'),
        ('P','Intersect(Line(A,F),omega,near=A)'),('R','Intersect(Line(A,F),omega,far=A)'),
        ('Q','Intersect(Line(A,F),Line(B,E))')],
        [eq('Angle(E,F,A)','30*pi/180'),eq('Angle(F,P,E)','25*pi/180'),gt('a'),gt('theta','-pi'),lt('theta','pi'),
         gt('Distance(B,E)'),gt('Dot(Vector(A,F),Vector(A,V))')]+segment('P','A','F',True)+segment('R','P','F',True)+segment('Q','P','R',True)+segment('Q','B','E',True),
        'Angle(P,E,Q)*180/pi','Unit-circle similarity normalization. AC tangent is vertical; AF has the specified35 degree angle in the drawn orientation. Endpoint selectors and segment ordering preserve A-P-Q-R-F and B-Q-E; both tangents remain explicit. Answer measured in degrees.')
    put(out,'CEMC-EG-10','a c',[
        ('D','Point(0,0)'),('C','Point(c,0)'),('A','Point(a,20)'),('B','Point(a+c,20)'),
        ('E','Point(a,0)'),('F','ClosestPoint(A,Line(B,C))')],
        [eq('Distance(A,F)',32),eq('cos(Angle(E,A,F))','1/3')]+pos('c')+segment('E','D','C',True)+segment('F','C','B',True),
        'Area(A,E,C,F)','Parallelogram and the altitude AE=20 are constructed. Source feet lie on the two segments, selecting the drawn configuration.')
    put(out,'CEMC-EG-13','x y',[
        ('E','Point(0,10)'),('F','Point(10,10)'),('G','Point(10,0)'),('H','Point(0,0)'),
        ('W','Point(x,y+6)'),('X','Point(x+6,y+6)'),('Y','Point(x+6,y)'),('Z','Point(x,y)')],
        [gt('x'),lt('x',4),gt('y'),lt('y',4)],'Area(E,F,X,W)+Area(G,H,Z,Y)',
        'Adaptation of the source invariance proof question: ask the common sum of areas. All allowed translations remain variables; target is not replaced by its proved constant.')
    put(out,'CEMC-EUCLID-2024-01B','t',[
        ('A','Point(0,10)'),('B','Point(0,0)'),('C','Point(t-1,0)')],
        [eq('Distance(A,C)','t+1'),gt('t',1)],'t','Right triangle constructed with positive leg t-1.')
    put(out,'CEMC-EUCLID-2024-04A','d',[
        ('A','Point(0,12)'),('B','Point(0,0)'),('C','Point(-6,0)'),('D','Point(d,0)'),
        ('P','ClosestPoint(C,Line(A,D))'),('N','Intersect(Line(C,P),Line(A,B))')],
        [eq('Angle(A,D,B)','pi/4'),gt('d')],'Area(A,P,N)',
        'AB perpendicular CD and CP perpendicular AD are constructions. The source order C-B-D fixes d>0.')
    put(out,'CEMC-EUCLID-2024-04B','m',[
        ('O','Point(0,0)'),('A','Point(2,0)'),('B','Point(0,6)'),('D','Point(0,1)'),
        ('C','Intersect(Line(A,B),Line(D,Point(1,m+1)))')],
        [eq('Area(A,C,D)','Area(A,B,O)/2'),gt('m')],'C.x',
        'Adaptation: return the x component of the requested coordinate pair. Both source line equations and the area condition remain geometric constructions.')
    cells=['x*(h-y)','(w-x)*(h-y)','x*y']
    choices=['And('+','.join(f'({area}) == {v}' for area,v in zip(cells,perm))+')' for perm in permutations((2,3,6))]
    put(out,'CEMC-EUCLID-2024-05A','w h x y',[
        ('A','Point(0,h)'),('B','Point(0,0)'),('C','Point(w,0)'),('D','Point(w,h)'),('X','Point(x,y)')],
        [pred('Or('+','.join(choices)+')')]+pos('w','h','x','y')+[lt('x','w'),lt('y','h')],
        '(w-x)*y','The rectangle may be reflected/rotated to place the unspecified area in the bottom-right cell. All six assignments of2,3,6 to the other cells are retained via the native disjunction. All possible fourth areas are requested, as in the source.')
    put(out,'CEMC-EUCLID-2024-08A','cx cy m n',[
        ('A','Point(0,0)'),('B','Point(0,3)'),('omegaA','Circle(A,4)'),('omegaB','Circle(B,3)'),
        ('M','Point(m,-4)'),('N','Point(n,-4)'),('C','Point(cx,cy)'),
        *[(f'F{i}',f'ClosestPoint({center},Line(C,{endpoint}))') for i,(center,endpoint) in enumerate([('A','M'),('B','M'),('A','N'),('B','N')])]],
        [eq(f'IsTangent(Line(C,{v}),{o})') for v in ('M','N') for o in ('omegaA','omegaB')]+
        [lt('m',0),gt('n'),gt('cy',6)]+sum([segment(f'F{i}','C',v,True) for i,v in enumerate(('M','M','N','N'))],[]),
        'Area(M,N,C)','The common center line is vertical; larger-circle bottom tangent is y=-4. Four segment-contact constraints and C above both circles select the source common external tangents. Symmetry of C is not assumed as an equation.')
    put(out,'CEMC-EUCLID-2024-10A','t u v',[
        ('A','Point(-1,0)'),('B','Point(0,4)'),('C','Point(1,0)'),('S','Point(1,0)'),('T','Point(-t,0)'),
        ('P','Point(u-1,4*u)'),('Q','Point(v,4*(1-v))'),('X','Intersect(Line(S,P),Line(T,Q))')],
        [eq('Area(A,P,X,T)','Area(A,B,C)/4'),eq('Area(B,P,X,Q)','Area(A,B,C)/4'),
         eq('Area(C,Q,X)','Area(A,B,C)/4'),eq('Area(T,X,C)','Area(A,B,C)/4'),
         gt('t'),{'left':'t','operator':'<=','right':1},gt('u'),lt('u',1),gt('v'),lt('v',1)]+
        segment('X','S','P',True)+segment('X','T','Q',True),
        'P.x','Part10(a) fixes s=1. Four source partition areas retained; the fourth equality is deliberately not silently deleted. Adaptation returns P x-coordinate only, with the coordinate-pair task noted.')
    put(out,'CEMC-EUCLID-2023-02B','',[
        ('P','Point(3,6)'),('A','Intersect(Line(P,Point(4,9)),Line(Point(0,0),Point(1,0)))'),
        ('B','Intersect(Line(P,Point(4,5)),Line(Point(0,0),Point(1,0)))')],
        [],'Distance(A,B)','The stated two slopes are constructed; intercepts remain explicit line intersections.')
    put(out,'CEMC-EUCLID-2023-05B','a b u',[
        ('Q','Point(0,0)'),('P','Point(a,0)'),('R','Point(b*cos(pi/3),b*sin(pi/3))'),
        ('S','Point(0,0)'),('T','Point(a*cos(pi/6),a*sin(pi/6))'),('U','Point(u,0)')],
        [eq('Distance(P,R)',21),eq('Distance(T,U)','b'),eq('sin(Angle(T,U,S))','4/5')]+pos('a','b','u'),
        'a+b','Adaptation returns the sum of the requested positive side pair. The acute/obtuse alternatives for angleTUS are not preselected; sine condition is retained.')
    put(out,'CEMC-EUCLID-2023-06B','',[
        ('L1','Line(Point(0,3),Point(3,2))'),('L2','Line(Point(0,2),Point(3,1))'),
        ('L3','Line(Point(0,0),Point(1,3))'),('L4','Line(Point(1,0),Point(2,3))'),
        ('A','Intersect(L1,L4)'),('B','Intersect(L2,L4)'),('C','Intersect(L2,L3)'),('D','Intersect(L1,L3)')],
        [],'Area(A,B,C,D)','The four lattice segments were read from the rendered official diagram: (0,3)-(3,2), (0,2)-(3,1), (0,0)-(1,3), (1,0)-(2,3).')
    put(out,'CEMC-EUCLID-2022-04A','',[(p,f'Point({x},{y})') for p,(x,y) in zip('ABCDEF',[(0,0),(4,0),(7,2),(7,5),(3,5),(0,3)])],
        [],'Area(A,B,C,D,E,F)','Coordinates copied from the source; polygon orientation preserved.')
    put(out,'CEMC-EUCLID-2022-04B','x',[
        ('P','Point(0,0)'),('Q','Point(x,0)'),('S','Point(0,-x-3)'),('L','Distance(Q,S)'),
        ('R','Point(x+8*(x+3)/L,-8*x/L)')],
        [eq('Distance(R,S)','x+8'),gt('x')],'Distance(P,Q)+Distance(Q,R)+Distance(R,S)+Distance(S,P)',
        'The two right triangles share QS; the constructed perpendicular ray selects the source quadrilateral, with QR=8. All positive x satisfying RS=x+8 are retained.')
    put(out,'CEMC-EUCLID-2022-07B','x y',[
        ('B','Point(0,0)'),('C','Point(2,0)'),('D','Point(3,0)'),('A','Point(x,y)')],
        [eq('Distance(A,C)/Distance(A,D)','3/4'),eq('cos(Angle(A,C,D))','-3/5'),gt('y')],
        'Distance(A,B)','B-C-D are in the source order. Reflection fixes A above the base; both ratio and cosine are unsolved source constraints.')
    put(out,'CEMC-EUCLID-2022-08A','a x1 x2',[
        ('V','Point(0,2)'),('B','Point(x1,a*x1**2+2)'),('C','Point(x2,a*x2**2+2)')],
        [eq('B.y','-B.x+4*a'),eq('C.y','-C.x+4*a'),eq('Area(V,B,C)','72/5'),gt('a','1/2'),lt('x1','x2')],
        'a','Parabola vertex, two distinct secant intersections and source triangle area retained. Endpoint ordering removes only duplicate labelling.')
    return out
