"""Attach independent references to immutable reference-blind prospective runs.

The original runner intentionally rejects changing its manifest's reference
hash. This separate assessor preserves that manifest and writes a new artifact
with hashes of both the solver inputs and the later independent reference file.
"""
import argparse,hashlib,json,statistics,sys
from collections import Counter,defaultdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from research_runner import _load_cases,_answer_keys,_canonical_json,read_run_outcome,reference_expressions
from geosolver.exact import describe_exact


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def assess(campaign,references,out):
    if out.exists():raise FileExistsError(out)
    m=json.loads((campaign/'campaign-manifest.json').read_text());refs=_load_cases(references)
    rawrefs={r['id']:r for r in map(json.loads,references.read_text().splitlines())}
    refs={r.identifier:r for r in refs};expected={(r['id'],s) for r in m['cases'] for s in m['config']['seeds']}
    records={r['id']:r for r in m['cases']};rows=[];seen=set()
    canonical={}
    for ident,record in records.items():
        ref=refs[ident]
        if rawrefs[ident]['dsl']!=record.get('dsl',rawrefs[ident]['dsl']):raise ValueError('Reference input differs')
        # _load_cases computes the same problem hash from the authored problem.
        problem_hash=hashlib.sha256(_canonical_json(ref.dsl).encode('utf-8')).hexdigest()
        if problem_hash!=record['problem_hash']:raise ValueError('Reference problem hash changed: '+ident)
        if record['truth_status']!='unverified':raise ValueError('Not a reference-blind source campaign')
        canonical[ident]=sorted({_canonical_json(describe_exact(value).canonical_key()) for expr in ref.references for value in reference_expressions(expr)})
    for p in sorted((campaign/'runs').glob('*/*.json')):
        if '.tmp.' in p.name:continue
        r=json.loads(p.read_text());key=(r['case_id'],r['seed']);ident=key[0]
        if key not in expected or key in seen:raise ValueError('unplanned or duplicate raw run: '+str(p))
        seen.add(key)
        if r['problem_hash']!=records[ident]['problem_hash']:raise ValueError('raw input changed')
        for field in ('source_hash','dependency_lock_hash'):
            if r[field]!=m[field]:raise ValueError(field+' changed')
        for field in ('time_limit_seconds','cores','thread_environment'):
            if r['config'][field]!=m['config'][field]:raise ValueError(field+' changed')
        actual=_answer_keys(r.get('solver_result'));target=canonical[ident];outcome=read_run_outcome(r)
        extra=sorted(set(actual)-set(target));missing=sorted(set(target)-set(actual))
        no_root=bool(rawrefs[ident].get('expected_no_feasible_configuration'))
        if not target and not no_root:raise ValueError('Empty reference without input infeasibility proof: '+ident)
        d=(r.get('solver_result') or {}).get('diagnostics',{});pipe=d.get('pipeline_summary',{})
        rows.append({'case_id':ident,'seed':r['seed'],'matched':bool(outcome['normal_completion'] and actual==target),
            'actual':[json.loads(v) for v in actual],'expected':[json.loads(v) for v in target],
            'extra':[json.loads(v) for v in extra],'missing':[json.loads(v) for v in missing],
            'any_reference_value':bool(set(actual)&set(target)),'any_output':bool(actual),
            'numeric_feasible_reported':d.get('numeric_feasible'),
            'expected_no_feasible_configuration':no_root,'solver_proved_infeasible':False if no_root else None,
            'empty_set_interpretation':'No output agrees with independent infeasibility proof; solver itself supplies no global infeasibility certificate.' if no_root else None,
            'raw_path':str(p),'raw_sha256':sha(p),'source_family':rawrefs[ident].get('source_family'),
            'variables':len(rawrefs[ident]['dsl']['variables']),
            'search':pipe.get('search',{}),'initial_probe':pipe.get('initial_probe',{}),
            'staged_fallback':pipe.get('search_staged_fallback',{}),
            'refinement':pipe.get('refinement',{}),
            'exact_assembly':pipe.get('exact_assembly',{}),
            'reference_provenance':rawrefs[ident].get('reference_provenance',rawrefs[ident].get('reference_derivation')),
            **outcome})
    for ident,seed in sorted(expected-seen):rows.append({'case_id':ident,'seed':seed,'matched':False,'missing_raw':True,
        'variables':len(rawrefs[ident]['dsl']['variables']),'actual':[],
        'expected':[json.loads(v) for v in canonical[ident]],
        'source_family':rawrefs[ident].get('source_family'),
        'expected_no_feasible_configuration':bool(rawrefs[ident].get('expected_no_feasible_configuration')),
        'any_reference_value':False,'any_output':False})
    out.mkdir(parents=True);(out/'assessment.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in rows))
    bycase=defaultdict(list)
    for r in rows:bycase[r['case_id']].append(r)
    cases=[]
    for ident,rr in sorted(bycase.items()):
        cases.append({'case_id':ident,'runs':len(rr),'matched':sum(r['matched'] for r in rr),
            'any_reference_value':sum(r.get('any_reference_value',False) for r in rr),
            'any_output':sum(r.get('any_output',False) for r in rr),
            'numeric_feasible_reported':sum(bool(r.get('numeric_feasible_reported')) for r in rr),
            'extra_values':sum(bool(r.get('extra')) for r in rr),
            'status':dict(Counter(str(r.get('status','missing_raw')) for r in rr)),
            'median_wall':statistics.median(r['wall_seconds'] for r in rr if 'wall_seconds' in r) if any('wall_seconds' in r for r in rr) else None,
            'failure_stage':dict(Counter(str(r.get('failure_stage')) for r in rr)),
            'variables':len(rawrefs[ident]['dsl']['variables'])})
    (out/'problem-results.json').write_text(json.dumps(cases,indent=2,ensure_ascii=False)+'\n')
    receipt={'campaign':str(campaign),'campaign_manifest_sha256':sha(campaign/'campaign-manifest.json'),
        'reference_file':str(references),'reference_file_sha256':sha(references),'script_sha256':sha(Path(__file__)),
        'runs_planned':len(expected),'runs_seen':len(seen),'missing_raw':len(expected-seen),
        'matched':sum(r['matched'] for r in rows),'any_reference_value':sum(r.get('any_reference_value',False) for r in rows),
        'extra_runs':sum(bool(r.get('extra')) for r in rows),'no_root_runs':sum(r.get('expected_no_feasible_configuration',False) for r in rows),
        'truth_separation':'Original run manifest and solver inputs remain unmodified; references were not present in search or pilot inputs.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('campaign',type=Path);p.add_argument('references',type=Path);p.add_argument('output',type=Path);a=p.parse_args();assess(a.campaign,a.references,a.output)
