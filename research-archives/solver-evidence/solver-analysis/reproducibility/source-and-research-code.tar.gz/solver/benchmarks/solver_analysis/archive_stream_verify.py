"""Read a historical tar stream and compare every raw member against both seals."""
import argparse
import hashlib
import json
import tarfile
import time
from datetime import datetime,timezone
from pathlib import Path


def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def run(base,out):
    if out.exists():raise FileExistsError(out)
    start=time.monotonic();started=datetime.now(timezone.utc).isoformat()
    name='baseline-complete';files=base/'archived-runs'/(name+'.files.json');seal=base/name/'SHA256SUMS'
    expected=json.loads(files.read_text());lines={n:h for h,n in (r.split(maxsplit=1) for r in seal.read_text().splitlines() if r.strip())}
    archive=base/'archived-runs'/(name+'.tar.gz');actual={};unlisted=[]
    with tarfile.open(archive,'r|gz') as tf:
        for member in tf:
            if not member.isfile():continue
            stream=tf.extractfile(member);h=hashlib.file_digest(stream,'sha256').hexdigest()
            key=member.name.removeprefix('./');actual[key]=h
            if key not in expected:unlisted.append(key)
    errors=[]
    for key,h in expected.items():
        second=lines.get(key.removeprefix(name+'/'))
        if actual.get(key)!=h or second!=h:errors.append({'name':key,'member_hash':actual.get(key),'files_manifest_hash':h,'seal_hash':second})
    external=[]
    for n,h in lines.items():
        p=base/name/n
        if not n.startswith('runs/'):
            observed=digest(p) if p.exists() else None;external.append({'name':n,'expected':h,'actual':observed})
    out.parent.mkdir(parents=True,exist_ok=True)
    result={'kind':'solver-a1 historical full-baseline raw integrity; no solver rerun',
        'started_utc':started,'seconds':time.monotonic()-start,'tar_path':str(archive),'tar_bytes':archive.stat().st_size,
        'tar_members':len(actual),'expected_raw_members':len(expected),'raw_mismatches':errors,'unlisted_members':unlisted,
        'summary_and_assessment_seals':external,'mismatch_count':len(errors)+sum(r['expected']!=r['actual'] for r in external),
        'seal_sha256':digest(seal),'files_manifest_sha256':digest(files),'script_sha256':digest(Path(__file__)),
        'reuse_limit':'Old wall timing had16 parallel runs. Current8-core wall comparisons do not reuse it; target success and provenance remain usable.'}
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('summary_and_assessment_seals','raw_mismatches')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('base',type=Path);p.add_argument('output',type=Path);a=p.parse_args();run(a.base,a.output)
