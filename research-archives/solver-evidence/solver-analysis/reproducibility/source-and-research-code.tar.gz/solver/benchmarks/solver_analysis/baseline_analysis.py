"""Reference-aware baseline assessment and deterministic cohort extension.

This is post-run discovery analysis. It never supplies information to a solver
or to the unknown-problem prediction process.
"""
import argparse
import csv
import hashlib
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from archive_audit import features


def analyze(archive, cases_path):
    campaign=archive/'campaigns/baseline-5seed-20260911'
    dest=archive/'analysis/baseline-v1'
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir(parents=True)
    cases=[json.loads(s) for s in cases_path.read_text().splitlines() if s.strip()]
    assessments=[json.loads(s) for s in (campaign/'assessment.jsonl').read_text().splitlines()]
    byid=defaultdict(list)
    for row in assessments:byid[row['case_id']].append(row)
    stats={};compact=[]
    for case in cases:
        rows=byid[case['id']];feat=features(case)
        stats[case['id']]={**feat,'runs':len(rows),'matched':sum(r['matched'] for r in rows),
            'any_reference_answer':sum(bool(r['actual']) and len(r['missing'])<len(r['expected']) for r in rows),
            'any_answer':sum(bool(r['actual']) for r in rows),'extra_values':sum(bool(r['extra']) for r in rows),
            'median_wall':statistics.median(r['wall_seconds'] for r in rows),
            'min_wall':min(r['wall_seconds'] for r in rows),'max_wall':max(r['wall_seconds'] for r in rows),
            'statuses':dict(Counter(r['status'] for r in rows)),
            'failure_stages':dict(Counter(str(r['failure_stage']) for r in rows))}
        for r in rows:
            file=campaign/'runs'/case['id']/(str(r['seed'])+'.json')
            raw=json.loads(file.read_text());d=raw['solver_result']['diagnostics'];p=d['pipeline_summary']
            vrs=p.get('verification_records') or []
            compact.append({'case_id':case['id'],'seed':r['seed'],'variables':feat['variables'],
                'stratum':'zero' if not feat['variables'] else 'scalar' if feat['variables']==1 else 'multivariate',
                'matched':r['matched'],'any_reference_answer':bool(r['actual']) and len(r['missing'])<len(r['expected']),
                'any_answer':bool(r['actual']),'extra':bool(r['extra']),
                'numeric_feasible_reported':d.get('numeric_feasible'),
                'status':r['status'],'termination_reason':r['termination_reason'],
                'failure_stage':r['failure_stage'],'normal_completion':r['normal_completion'],
                'wall_seconds':r['wall_seconds'],'cpu_seconds':r['cpu_seconds'],
                'rejection_tags':r['rejection_tags'],'phase_timings':r['phase_timings'],
                'counters':r['counters'],'candidate_count':len(d.get('candidate_records') or []),
                'verification_record_count':len(vrs),
                'source_file':str(file),'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
    strata={}
    for st in ('zero','scalar','multivariate'):
        rows=[r for r in compact if r['stratum']==st]
        strata[st]={'problems':len(set(r['case_id'] for r in rows)),'runs':len(rows),
            **{k:sum(bool(r[k]) for r in rows) for k in ('matched','any_answer','any_reference_answer','extra','numeric_feasible_reported','normal_completion')},
            'status':dict(Counter(r['status'] for r in rows)),
            'failure_stage':dict(Counter(str(r['failure_stage']) for r in rows)),
            'median_wall':statistics.median(r['wall_seconds'] for r in rows),
            'total_wall':sum(r['wall_seconds'] for r in rows)}
    old=json.loads((archive/'history/final-v4-audit/discovery-cohort.json').read_text())
    old_set=set(old['fragile']+old['controls'])
    new=sorted(set(i for i,s in stats.items() if s['matched']<s['runs'])-set(old['fragile']))
    selected=set(old_set);pairs=[]
    def distance(a,b):
        x,y=stats[a],stats[b];cx,cy=set(x['calls']),set(y['calls'])
        return 3*abs(x['variables']-y['variables'])+.5*abs(x['equalities']-y['equalities'])+.1*abs(x['guards']-y['guards'])+.1*abs(x['constructions']-y['constructions'])+3*(1-len(cx&cy)/max(1,len(cx|cy)))
    for index,ident in enumerate(sorted(new,key=lambda i:(-stats[i]['variables'],i))):
        candidates=[i for i,s in stats.items() if s['matched']==s['runs'] and s['variables'] and i not in selected and i not in new]
        near=sorted(candidates,key=lambda i:(distance(ident,i),i))[:6]
        control=sorted(near,key=lambda i:(stats[i]['median_wall'],i))[0 if index%2==0 else -1]
        selected.update((ident,control));pairs.append({'case':ident,'control':control,'distance':distance(ident,control),'speed_preference':'fast' if index%2==0 else 'slow'})
    cohort={'selection_status':'outcome-informed discovery, not confirmation',
        'prior_cohort_size':len(old_set),'cases':sorted(selected),'new_fragile':new,
        'added_cases':sorted(selected-old_set),'new_pairs':pairs,'original_pairs':old['pairs'],
        'rule':old['rule'],'base_seeds':[0,1,2,3,4],'additional_seeds':list(range(5,30)),
        'same_seed_repeats':[0,1],'features':stats}
    (dest/'cohort.json').write_text(json.dumps(cohort,indent=2,ensure_ascii=False)+'\n')
    (dest/'strata.json').write_text(json.dumps(strata,indent=2)+'\n')
    (dest/'run-index.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in compact))
    (dest/'problem-results.json').write_text(json.dumps(stats,indent=2,ensure_ascii=False)+'\n')
    with (dest/'problem-results.csv').open('w',newline='') as f:
        keys=['case_id','variables','runs','matched','any_reference_answer','any_answer','extra_values','median_wall','min_wall','max_wall']
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for i,s in sorted(stats.items()):w.writerow({'case_id':i,**{k:s[k] for k in keys[1:]}})
    (dest/'receipt.json').write_text(json.dumps({'numeric_feasible_is_solver_diagnostic':True,
        'independent_geometric_certification':'Not established for every case. Separate analytic case studies only.',
        'assessment_sha256':hashlib.sha256((campaign/'assessment.jsonl').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
    print(json.dumps({'strata':strata,'cohort_size':len(selected),'new_pairs':pairs}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--cases',type=Path,default=Path('benchmarks/cases.jsonl'))
    a=p.parse_args();analyze(a.archive,a.cases)
