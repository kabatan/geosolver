"""Fixed-cost, reference-blind pilot for contact/goal applicability.

Float search uses the original public residual. The fixed HP stage uses the
production smoothing path. Contact coordinates are only evaluated afterwards.
Finite-point gradients never certify an order at a root. No references, exact
identification or final coordinate-correcting verification are used.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import random
import time
from pathlib import Path
import numpy as np
from mpmath import mp
from scipy.optimize import least_squares
from contact_detector import detect,prove_identity_rows
from local_sensitivity import diagnose,matrix
from exact_codec import dumps
from paired_stages import bundle_of,WorkLimit
from geosolver.engine.standard.refinement.mpmath_refiner import MpmathRefiner,_convert_problem_bounds
from geosolver.engine.standard.refinement.refiner_config import RefinerConfig
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.evaluation.classify_evaluation_failure import EvaluationStatus
from geosolver.engine.standard.problem.infer_problem_bounds import infer_problem_bounds
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode
from geosolver.runtime.deadline import runtime_session
from geosolver.engine.standard.evaluation.selection_trace import capture_selection_trace
from geosolver.engine.standard.evaluation.verification_numerics import same_branches

CONFIG={'seed':20260911,'random_points':64,'starts':4,'actual_float_calls_per_start':256,'hp_lm_iterations':20,
    'hp_dps':80,'difference_pairs':[(80,'1e-18'),(110,'1e-23')],'raw_residual_threshold':1e-7,
    'signed_contact_threshold':1e-4,'absolute_svd_threshold':1e-7,
    'relative_svd_threshold':1e-6,'unresolved_small_row_threshold':1e-25,
    'normalized_goal_threshold':1e-5,'safety_seconds':60}


def run(dsl):
    begun=time.monotonic();detection=detect(dsl);bundle=bundle_of(dsl);e=build_ir_evaluator(bundle)
    n=len(bundle.var_names);rows=[];calls=0;best=None;initial_best=None
    result={'schema':3,'case_id':dsl['id'],'config':CONFIG,'detection':detection,
        'prediction_information':'input plus fixed public-float / production-smoothed-HP pilot; finite-point diagnostics only',
        'root_goal_order_prediction':'abstain_no_root_order_certificate',
        'variables':n,'residual_rows':len(bundle.targets),'classification':'abstain',
        'detection_script_sha256':hashlib.sha256(Path(__file__).with_name('contact_detector.py').read_bytes()).hexdigest(),
        'diagnostic_script_sha256':hashlib.sha256(Path(__file__).with_name('local_sensitivity.py').read_bytes()).hexdigest()}
    if n==0:return {**result,'classification':'zero_variable','seconds':time.monotonic()-begun,'float_calls':0}
    bounds=infer_problem_bounds(bundle);lo=np.array([b[0] for b in bounds]);hi=np.array([b[1] for b in bounds]);rng=random.Random(CONFIG['seed'])
    def evaluate(x,stage):
        nonlocal calls,best,initial_best
        calls+=1;v=e.evaluate_float_residual(x)
        valid=v.evaluation_status is EvaluationStatus.OK
        residual=np.asarray(v.residual_vector) if valid else np.full(len(bundle.targets),1e6)
        guard=e.evaluate_guard(x)[0] if valid else False
        hard=e.evaluate_float_hard_feasibility(x,include_margins=False).hard_feasible if valid else False
        norm=float(np.linalg.norm(residual));row={'x':tuple(float(t) for t in x),'stage':stage,'valid':valid,'guard':guard,'hard':hard,'norm':norm}
        rows.append(row)
        if valid:
            key=(not (guard and hard),norm)
            if best is None or key<best[0]:best=(key,row)
            if stage=='probe' and (initial_best is None or key<initial_best[0]):initial_best=(key,row)
        return residual
    with runtime_session(begun+CONFIG['safety_seconds']) as timings:
        try:
            for _ in range(CONFIG['random_points']):evaluate([rng.uniform(a,b) for a,b in bounds],'probe')
            eligible=sorted((r for r in rows if r['valid']),key=lambda r:(not(r['guard'] and r['hard']),r['norm']))
            for j,start in enumerate(eligible[:CONFIG['starts']]):
                start_calls=calls
                def fun(x):
                    if calls-start_calls>=CONFIG['actual_float_calls_per_start']:raise WorkLimit('pilot evaluation cap')
                    return evaluate(x,f'least_squares_{j}')
                try:
                    least_squares(fun,np.asarray(start['x']),bounds=(lo,hi),x_scale='jac',
                        ftol=1e-12,xtol=1e-12,gtol=1e-12,max_nfev=CONFIG['actual_float_calls_per_start'])
                except WorkLimit:pass
                except Exception as ex:result.setdefault('search_errors',[]).append(type(ex).__name__+': '+str(ex))
            if best is not None:
                point=best[1];result.update(pilot_point=point,initial_best=initial_best[1],
                    progress_log10=float(np.log10(max(initial_best[1]['norm'],1e-300)/max(point['norm'],1e-300))))
                with mp.workdps(CONFIG['hp_dps']):
                    x=[mp.mpf(v) for v in point['x']]
                    refiner=MpmathRefiner(config=RefinerConfig(max_stage_iters=CONFIG['hp_lm_iterations']))
                    before=tuple(x)
                    stage_status,x,stage_residual=refiner._run_stage(bundle=bundle,evaluator=e,
                        start_point=x,bounds=_convert_problem_bounds(bundle),dps=CONFIG['hp_dps'],
                        target_residual=mp.mpf('1e-40'),preserve_hard_feasibility=point['hard'])
                    with high_precision_mode():
                        stage_hard=e.evaluate_hp_hard_feasibility(x,precision=CONFIG['hp_dps'],include_margins=False).hard_feasible
                        stage_guard=e.evaluate_guard(x)[0]
                    result['hp_pilot']={'input':before,'output':tuple(x),'status':stage_status,
                        'residual':stage_residual,'hard':stage_hard,'guard':stage_guard}
                proofs=prove_identity_rows(dsl);proved={r['condition_index'] for r in proofs}
                indices={r['condition_index'] for r in detection['contacts']}
                other=copy.deepcopy(dsl)
                other['conditions']=[r for i,r in enumerate(dsl['conditions']) if i not in indices|proved]
                contact=copy.deepcopy(dsl)
                contact['conditions']=[{'left':r['contact_coordinate'],'operator':'=','right':0} for r in detection['contacts']]
                fe=build_ir_evaluator(bundle_of(other));he=build_ir_evaluator(bundle_of(contact))
                jets=[];hp_calls={};probe_records=[]
                for precision,step in CONFIG['difference_pairs']:
                    with mp.workdps(precision):
                        scale=[max(mp.mpf(1),abs(v)) for v in x];eps=mp.mpf(step)
                        def sample(y):
                            values={}; traces={}
                            with high_precision_mode():
                                guard,tags=e.evaluate_guard(y)
                                hard=e.evaluate_hp_hard_feasibility(y,precision=precision,include_margins=True)
                                for key,ev in [('raw',e),('other',fe),('contact',he)]:
                                    with capture_selection_trace() as trace:
                                        v=ev.evaluate_hp_residual(y,precision=precision)
                                    hp_calls[key]=hp_calls.get(key,0)+1
                                    if not v.is_finite:raise ValueError(key+' nonfinite')
                                    values[key]=list(v.residual_vector);traces[key]=tuple(trace)
                                with capture_selection_trace() as trace:
                                    v=refiner._residual_vector_for_stage(bundle,e,y,precision,smooth_zero_constraints=True)
                                hp_calls['production_smoothed']=hp_calls.get('production_smoothed',0)+1
                                if v is None:raise ValueError('production smoothed residual unavailable')
                                values['production_smoothed']=list(v);traces['production_smoothed']=tuple(trace)
                                with capture_selection_trace() as trace:
                                    goal=e.evaluate_answer_hp(y,precision=precision).answer_hp
                                hp_calls['goal']=hp_calls.get('goal',0)+1
                                if goal is None:raise ValueError('goal unavailable')
                                values['goal']=[goal];traces['goal']=tuple(trace)
                            probe_records.append({'precision':precision,'step':step,'x':tuple(y),
                                'guard':guard,'guard_tags':tags,'hard':hard,'branch_traces':traces})
                            return values,traces,guard and hard.hard_feasible
                        base,base_trace,domain_ok=sample(x);columns={k:[] for k in base}
                        for j,sc in enumerate(scale):
                            plus=list(x);minus=list(x);plus[j]+=eps*sc;minus[j]-=eps*sc
                            av,at,ao=sample(plus);bv,bt,bo=sample(minus)
                            domain_ok &= ao and bo and all(same_branches(base_trace[k],at[k]) and same_branches(base_trace[k],bt[k]) for k in base)
                            for key in base:columns[key].append([(a-b)/(2*eps) for a,b in zip(av[key],bv[key])])
                        jac={k:matrix([[columns[k][j][i] for j in range(n)] for i in range(len(base[k]))],n) for k in base}
                        jac['goal']/=max(1,abs(base['goal'][0]))
                        jets.append({'precision':precision,'step':step,'jacobian':jac,'values':base,'probe_domain_stable':domain_ok})
                with mp.workdps(110):
                    errors={k:mp.norm(jets[1]['jacobian'][k]-jets[0]['jacobian'][k]) for k in jets[1]['jacobian']}
                    hi=jets[-1];jj=hi['jacobian'];raw_norm=mp.norm(hi['values']['raw']);contact_norm=mp.norm(hi['values']['contact'])
                    diagnostic=diagnose(jj['raw'],jj['other'],jj['contact'],jj['goal'],
                        derivative_error=max(errors.values(),default=mp.mpf(0)),
                        probe_domain_stable=all(j['probe_domain_stable'] for j in jets),has_contact=detection['positive'],
                        local_feasible=stage_guard and stage_hard and raw_norm<=CONFIG['raw_residual_threshold'] and contact_norm<=CONFIG['signed_contact_threshold'])
                    result['classification']=diagnostic['classification']
                    result['local']={'jets':jets,'difference_error_indicators':errors,'diagnostic':diagnostic,
                        'raw_norm':raw_norm,'contact_norm':contact_norm,'identity_proofs':proofs,
                        'hp_calls':hp_calls,'probe_records':probe_records,'numeric_arithmetic':'mpmath through full SVD; no float conversion',
                        'domain_limitation':'Original guards, hard margins and branch traces checked at probes; no interval neighborhood certificate.'}
        except Exception as ex:result['error']=type(ex).__name__+': '+str(ex)
    result.update(float_calls=calls,trace=rows,counters=timings.counters,seconds=time.monotonic()-begun,
        safety_censored=time.monotonic()-begun>=CONFIG['safety_seconds'])
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('dsl',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    r=run(json.loads(a.dsl.read_text()));r.update(input_sha256=hashlib.sha256(a.dsl.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(dumps(r)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k not in ('trace','local','detection','pilot_point','initial_best','hp_pilot','counters')}))
