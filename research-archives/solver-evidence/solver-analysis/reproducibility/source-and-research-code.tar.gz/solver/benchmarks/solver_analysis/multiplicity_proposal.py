"""Cross saved multiplicity interventions with proposal continuation.

Uses immutable stage-v2 outputs, never a known answer. Geometry is not rerun.
Failure/unverified/timeout inputs remain in the denominator with a closed gate.
"""
import argparse
import hashlib
import json
import random
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from exactify_probe import run_payload
from stage_replay import ensure_source


def run(directory,out):
    if out.exists():raise FileExistsError(out)
    rows=[];conditions=[(m,p) for m in ('original','projection') for p in ('original','continue_after_rejection')]
    random.Random(20260913+int(directory.name)).shuffle(conditions)
    for multiplicity,proposal in conditions:
        path=directory/(multiplicity+'__native_refine.json')
        row={'point_index':int(directory.name),'multiplicity':multiplicity,'proposal':proposal,
             'source_file':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None}
        if not path.exists():row['gate']='missing_numeric_result';rows.append(row);continue
        r=loads(path.read_text());v=r.get('verification')
        row.update(source_uid=r['point']['uid'],external_seed=r['point']['external_seed'],
                   numeric_error=r.get('error'),numeric_censored=r['safety_deadline_hit'])
        if not getattr(v,'verified',False):row['gate']='verification_not_accepted';rows.append(row);continue
        if v.answer_hp is None or v.answer_uncertainty is None:row['gate']='missing_goal_or_uncertainty';rows.append(row);continue
        with mp.workdps(600):
            tier='strict' if v.residual_norm<=mp.mpf('1e-70') else 'standard' if v.residual_norm<=mp.mpf('1e-55') else 'relaxed'
            payload={'precision':v.precision_dps,'value':v.answer_hp._mpf_,'uncertainty':v.answer_uncertainty._mpf_,
                'tier':tier,'reusable_results':[],'prefer_affine_pi':False,'closed_source':None}
        row.update(gate='accepted',verification_precision=v.precision_dps,
                   coordinate_revision='saved stage verifier output, separate from pre-verifier point',
                   symbolic=run_payload(payload,proposal,10))
        rows.append(row)
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(dumps({'source_hash':ensure_source(),'rows':rows,
        'scope':'fresh identification of saved verified stage outputs; no production cache or closed-expression shortcut',
        'input_gate':'same saved verifier result for both proposal arms','search_references_used':False})+'\n')
    print(json.dumps({'point':directory.name,'statuses':[getattr(r.get('symbolic',{}).get('result'),'exact_status',r['gate']) for r in rows]}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('output',type=Path);a=p.parse_args();run(a.directory,a.output)
