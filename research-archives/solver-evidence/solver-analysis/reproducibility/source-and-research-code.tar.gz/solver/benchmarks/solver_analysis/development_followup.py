"""Sequential heavy follow-up after the prescribed detailed benchmark.

No unknown input is solved here. Protocols are written before waiting. The
existing 107 retained JMO starts define paired units, not independent problems.
"""
import argparse
import hashlib
import json
import random
import subprocess
import sys
import time
from pathlib import Path
from mpmath import mp
from exact_codec import loads
from stage_campaign import THREADS
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]


def plan(archive):
    pool=archive/'development/jmo-legacy-source-pool.json'
    points=loads(pool.read_text())['points'];groups=[]
    for i,point in enumerate(points):
        conditions=[]
        for floor in ('1e-12','1e-24','1e-48'):
            for carry in (False,True):
                conditions.append({'name':f'original__floor_{floor}_carry_{int(carry)}','variant':'original',
                    'engine':'native_refine','dps':120,'iterations':80,'verify':True,
                    'damping':floor,'carry_damping':carry})
        if i<16:
            with mp.workdps(550):
                for scale in ('1','7','1/7'):
                    k=mp.mpf(scale)
                    for covariance in ([True] if scale=='1' else [False,True]):
                        factor=k*k if covariance else mp.mpf(1)
                        conditions.append({'name':f'original__scale_{scale.replace("/","over")}_covariant_{int(covariance)}',
                            'variant':'original','engine':'native_lm','dps':100,'iterations':20,'verify':False,
                            'damping':str(mp.mpf('1e-48')*factor),'initial_damping':str(mp.mpf('1e-24')*factor),
                            'residual_scale':scale})
        random.Random(12110+i).shuffle(conditions)
        groups.append({'case_id':'JMO-2013-PRE-05','point_index':i,'uid':point['uid'],'pool':str(pool),
            'pool_sha256':hashlib.sha256(pool.read_bytes()).hexdigest(),'conditions':conditions})
    random.Random(12111).shuffle(groups)
    return {'schema':1,'kind':'development mechanism intervention; no unknown outcomes',
        'archive':str(archive),'source_hash':ensure_source(),'thread_environment':THREADS,
        'safety_seconds_per_condition':30,'groups':groups,'planned_conditions':sum(len(g['conditions']) for g in groups),
        'predictions':[
            'At lowered floors, carrying final damping across precision stages removes the stage-100 five-small-improvement trap observed with reset. It does not guarantee arbitrary precision or final output.',
            'With the original 1e-12 floor, carrying damping alone offers little progress because transverse JtJ is still below that floor.',
            'Record stage-100 output separately; later promotion is part of total-pipeline effect and must not be attributed to an equal number of steps.',
            'Scaling all actual production residuals by k and damping initial/floor by k^2 preserves exact LM steps until absolute stopping thresholds intervene. Fixed damping need not preserve the trajectory.',
            'Scale experiment uses explicit callbacks even for k=1, ensuring the same derivative sparsity path.'],
        'scale_subset':'first 16 pool entries in original ledger order, selected without reference accuracy',
        'independence_warning':'107 retained points from one natural problem; repeated/internal seeds may overlap.'}


def main(archive):
    dest=archive/'development/damping-campaign-v1';p=archive/'development/damping-plan-v1.json'
    receipt=archive/'campaigns/development-followup-sequence.json'
    if dest.exists() or p.exists() or receipt.exists():raise FileExistsError('follow-up exists')
    frozen=plan(archive);p.write_text(json.dumps(frozen,indent=2)+'\n')
    r={'status':'waiting_for_detail_and_repeat','plan':str(p),'plan_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
       'no_concurrent_heavy_campaigns':True,'product_hash':ensure_source(),'completed':[]}
    receipt.write_text(json.dumps(r,indent=2)+'\n')
    prerequisite=archive/'campaigns/detail-sequence-receipt.json'
    while json.loads(prerequisite.read_text()).get('status')!='complete':time.sleep(10)
    commands=[
        [sys.executable,'-B',str(Path(__file__).with_name('stage_campaign.py')),'run',str(p),str(dest),'--jobs','8'],
        ['taskset','-c','0',sys.executable,'-B',str(Path(__file__).with_name('stage_analysis.py')),
         str(archive/'development/stage-campaign-v2'),str(archive/'analysis/stage-v3'),'--stationary'],
        ['taskset','-c','0',sys.executable,'-B',str(Path(__file__).with_name('stage_analysis.py')),
         str(dest),str(archive/'analysis/damping-v1'),'--stationary'],
        ['taskset','-c','0',sys.executable,'-B',str(Path(__file__).with_name('damping_analysis.py')),
         str(dest),str(archive/'analysis/damping-paired-v2')]]
    for command in commands:
        if ensure_source()!=r['product_hash']:raise ValueError('product changed')
        r.update(status='running',active_command=command);receipt.write_text(json.dumps(r,indent=2)+'\n')
        subprocess.run(command,cwd=ROOT,check=True)
        r['completed'].append(command)
    r.update(status='complete',source_hash_after=ensure_source());receipt.write_text(json.dumps(r,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);main(p.parse_args().archive)
