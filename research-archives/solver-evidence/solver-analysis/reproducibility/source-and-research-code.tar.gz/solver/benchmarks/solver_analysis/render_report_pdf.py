"""Render the editable Japanese Markdown with embedded fonts and vector math.

ReportLab handles page/table flow. Math is drawn as vector paths from
matplotlib, while scientific figure PNGs retain their standalone SVG originals.
No solver code or outcomes are executed during rendering.
"""
import argparse,hashlib,html,json,re
from datetime import datetime,timezone
from pathlib import Path
from markdown_it import MarkdownIt
import matplotlib
matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER,TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (BaseDocTemplate,PageTemplate,Frame,Paragraph,
    Spacer,PageBreak,CondPageBreak,Image,LongTable,TableStyle,Flowable,KeepTogether)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
from pypdf import PdfReader

FONT_SANS='/usr/share/fonts/opentype/ipafont-gothic/ipag.ttf'
FONT_SERIF='/usr/share/fonts/opentype/ipafont-mincho/ipam.ttf'
FONT_MONO='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
FONT_FALLBACK='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'
for name,path in [('IPAGothic',FONT_SANS),('IPAMincho',FONT_SERIF),('StudyMono',FONT_MONO),('StudyFallback',FONT_FALLBACK)]:pdfmetrics.registerFont(TTFont(name,path))
pdfmetrics.registerFontFamily('IPAMincho',normal='IPAMincho',bold='IPAGothic',italic='IPAMincho',boldItalic='IPAGothic')
pdfmetrics.registerFontFamily('IPAGothic',normal='IPAGothic',bold='IPAGothic',italic='IPAGothic',boldItalic='IPAGothic')
PAGE_W,PAGE_H=A4;MARGIN=18*mm;WIDTH=PAGE_W-2*MARGIN;BLUE=colors.HexColor('#235b91')


def clean(text):
    # Nonbreaking dashes cause font or wrap trouble; mathematical minus stays
    # math in display formulas. Human prose uses normal hyphens.
    return text.replace('\u2011','-').replace('\u2010','-').replace('\u2013','-').replace('\u2014','-')


MISSING_GLYPHS=set()


def escaped(text,font='IPAMincho'):
    """Keep Japanese typography while giving missing math glyphs a real font."""
    coverage=pdfmetrics.getFont(font).face.charWidths
    fallback=pdfmetrics.getFont('StudyFallback').face.charWidths
    result=[];run=[];using_fallback=False
    def flush():
        if run:
            content=html.escape(''.join(run))
            result.append('<font name="StudyFallback">'+content+'</font>' if using_fallback else content)
            run.clear()
    for character in clean(text):
        alternate=ord(character) not in coverage and not character.isspace()
        if alternate and ord(character) not in fallback:MISSING_GLYPHS.add(character)
        if alternate!=using_fallback:flush();using_fallback=alternate
        run.append(character)
    flush();return ''.join(result)


STYLES={
    'body':ParagraphStyle('StudyBody',fontName='IPAMincho',fontSize=9.7,leading=15.8,wordWrap='CJK',spaceAfter=7.5,allowWidows=0,allowOrphans=0),
    'title':ParagraphStyle('StudyTitle',fontName='IPAGothic',fontSize=21,leading=32,textColor=BLUE,spaceBefore=40,spaceAfter=22,wordWrap='CJK'),
    'h2':ParagraphStyle('StudyH2',fontName='IPAGothic',fontSize=16,leading=23,textColor=BLUE,spaceBefore=10,spaceAfter=13,keepWithNext=True,wordWrap='CJK'),
    'h3':ParagraphStyle('StudyH3',fontName='IPAGothic',fontSize=12,leading=18,textColor=BLUE,spaceBefore=12,spaceAfter=7,keepWithNext=True,wordWrap='CJK'),
    'h4':ParagraphStyle('StudyH4',fontName='IPAGothic',fontSize=10.5,leading=16,spaceBefore=10,spaceAfter=5,keepWithNext=True,wordWrap='CJK'),
    'table':ParagraphStyle('StudyTable',fontName='IPAMincho',fontSize=7.3,leading=11.6,wordWrap='CJK',spaceAfter=0),
    'thead':ParagraphStyle('StudyTableHead',fontName='IPAGothic',fontSize=7.6,leading=11.8,textColor=colors.white,wordWrap='CJK'),
    'caption':ParagraphStyle('StudyCaption',fontName='IPAMincho',fontSize=8,leading=12,textColor=colors.HexColor('#47586a'),wordWrap='CJK',spaceBefore=5,spaceAfter=13),
    'code':ParagraphStyle('StudyCode',fontName='StudyMono',fontSize=7.2,leading=10.8,wordWrap='CJK',backColor=colors.HexColor('#f1f5f8'),borderPadding=8,spaceBefore=5,spaceAfter=10),
}


class NumberedCanvas(Canvas):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.saved=[]
    def showPage(self):self.saved.append(dict(self.__dict__));self._startPage()
    def save(self):
        total=len(self.saved)
        for state in self.saved:
            self.__dict__.update(state)
            self.setFont('IPAGothic',7.5);self.setFillColor(colors.HexColor('#5c6b77'))
            self.drawRightString(PAGE_W-MARGIN,12*mm,f'{self._pageNumber} / {total}')
            self.drawString(MARGIN,12*mm,'GeoSolver 機構分析 | e703e2d99')
            Canvas.showPage(self)
        Canvas.save(self)


class StudyDocument(BaseDocTemplate):
    def afterFlowable(self,flowable):
        if hasattr(flowable,'study_heading'):
            level,title,key=flowable.study_heading
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(title,key,level=level,closed=False)
            if level==0:self.notify('TOCEntry',(0,title,self.page,key))


class VectorMath(Flowable):
    def __init__(self,formula,directory):
        super().__init__();formula=' '.join(formula.splitlines())
        formula=re.sub(r'\\le(?![A-Za-z])',r'\\leq ',formula)
        formula=re.sub(r'\\ge(?![A-Za-z])',r'\\geq ',formula)
        self.formula=formula
        key=hashlib.sha256(formula.encode()).hexdigest()[:20];p=directory/(key+'.svg')
        if not p.exists():
            with matplotlib.rc_context({'svg.fonttype':'path','mathtext.fontset':'dejavuserif'}):
                math_to_image('$'+formula+'$',p,prop=FontProperties(size=11),format='svg',dpi=200)
        self.drawing=svg2rlg(str(p));self.base_width=self.drawing.width;self.base_height=self.drawing.height
        self.hAlign='CENTER';self.spaceBefore=5;self.spaceAfter=11
    def wrap(self,availableWidth,availableHeight):
        self.scale=min(1,availableWidth/self.base_width)
        self.width=self.base_width*self.scale;self.height=self.base_height*self.scale+5
        return self.width,self.height
    def draw(self):
        self.canv.saveState();self.canv.scale(self.scale,self.scale)
        renderPDF.draw(self.drawing,self.canv,0,2);self.canv.restoreState()


def inline(tokens):
    result=[]
    for t in tokens or []:
        if t.type=='text':result.append(escaped(t.content))
        elif t.type=='code_inline':
            # CJK fonts also cover the Greek/math characters in inline code.
            result.append('<font name="IPAGothic" color="#344a5f">'+escaped(t.content,'IPAGothic')+'</font>')
        elif t.type in ('softbreak','hardbreak'):result.append('<br/>' if t.type=='hardbreak' else ' ')
        elif t.type=='strong_open':result.append('<b>')
        elif t.type=='strong_close':result.append('</b>')
        elif t.type=='em_open':result.append('<i>')
        elif t.type=='em_close':result.append('</i>')
        elif t.type=='link_open':result.append('<link href="'+html.escape(t.attrGet('href'),quote=True)+'" color="#235b91">')
        elif t.type=='link_close':result.append('</link>')
        elif t.type=='html_inline':result.append(escaped(t.content))
        elif t.type=='image':pass
        else:result.append(escaped(t.content))
    return ''.join(result)


def render(source,destination):
    destination.parent.mkdir(parents=True,exist_ok=True)
    assets=destination.parent/'pdf-assets';assets.mkdir(exist_ok=True)
    text=source.read_text();equations=[]
    def replace_math(m):
        equations.append(m[1].strip());return '\n\nMATHBLOCK_'+str(len(equations)-1)+'\n\n'
    text=re.sub(r'\\\[(.*?)\\\]',replace_math,text,flags=re.S)
    md=MarkdownIt('commonmark').enable('table');tokens=md.parse(text)
    story=[];i=0;headcount=0;body_started=False;list_depth=0;list_prefix=None;ordered=[];figures=[];warnings=[]
    manifest_path=source.parent/'figures/figure-manifest.json'
    captions={v['name']:v['caption'] for v in json.loads(manifest_path.read_text())['figures']} if manifest_path.exists() else {}
    while i<len(tokens):
        t=tokens[i]
        if t.type=='heading_open':
            tt=tokens[i+1];title=tt.content;level=int(t.tag[1:]);markup=inline(tt.children)
            if level==1:
                story.append(Paragraph('研究報告 / 2026',STYLES['caption']));story.append(Paragraph(markup,STYLES['title']))
            else:
                if level==2:
                    if not body_started:
                        story.append(Spacer(1,24));story.append(Paragraph('本報告は数値配置・目標精度・検証・同定・全値回収を分け、幾何の構成から計算過程までを検査する。',STYLES['body']))
                        story.append(PageBreak());story.append(Paragraph('目次',STYLES['h2']))
                        toc=TableOfContents();toc.levelStyles=[ParagraphStyle('TOC0',fontName='IPAGothic',fontSize=10,leading=21,wordWrap='CJK',leftIndent=2,rightIndent=15)]
                        story.append(toc);body_started=True
                    story.append(PageBreak())
                headcount+=1;p=Paragraph(markup,STYLES['h'+str(min(level,4))])
                if level in (2,3):p.study_heading=(level-2,title,'section_'+str(headcount))
                story.append(p)
            i+=3;continue
        if t.type=='paragraph_open':
            tt=tokens[i+1];content=tt.content;children=tt.children or []
            if re.fullmatch(r'MATHBLOCK_\d+',content):
                formula=equations[int(content.split('_')[1])]
                try:story.append(VectorMath(formula,assets))
                except Exception as ex:raise ValueError('Math rendering failed: '+formula) from ex
            elif any(c.type=='image' for c in children):
                for c in children:
                    if c.type!='image':continue
                    path=(source.parent/c.attrGet('src')).resolve()
                    if not path.exists():raise FileNotFoundError(path)
                    im=Image(str(path));width=WIDTH;height=width*im.imageHeight/im.imageWidth
                    if height>200*mm:width*=200*mm/height;height=200*mm
                    im.drawWidth=width;im.drawHeight=height;im.hAlign='CENTER'
                    cap=captions.get(path.stem,c.content);figures.append({'file':str(path),'caption':cap})
                    group=[im,Paragraph('図'+str(len(figures))+'　'+escaped(cap),STYLES['caption'])]
                    if story and hasattr(story[-1],'study_heading'):group.insert(0,story.pop())
                    story.append(KeepTogether(group))
            else:
                prefix=(list_prefix or '')
                style=STYLES['body'] if not list_depth else ParagraphStyle('List'+str(i),parent=STYLES['body'],leftIndent=12*list_depth,firstLineIndent=-8)
                story.append(Paragraph(prefix+inline(children),style));list_prefix=None
            i+=3;continue
        if t.type=='table_open':
            rows=[];row=[];head=True;headers=[];i+=1
            while i<len(tokens) and tokens[i].type!='table_close':
                q=tokens[i]
                if q.type=='tr_open':row=[]
                elif q.type=='inline':row.append(Paragraph(inline(q.children),STYLES['thead' if head else 'table']))
                elif q.type=='tr_close':rows.append(row)
                elif q.type=='thead_close':head=False
                i+=1
            count=len(rows[0]);first=rows[0][0].getPlainText()
            if first=='主張ID':weights=[.07,.30,.31,.32]
            elif '問題ID' in first and count==6:weights=[.34,.22,.08,.12,.10,.14]
            elif '問題ID' in first:weights=[.39]+[.61/(count-1)]*(count-1)
            elif count==2:weights=[.30,.70]
            elif count==3:weights=[.23,.33,.44]
            elif count==4:weights=[.20,.26,.26,.28]
            else:weights=[1/count]*count
            tab=LongTable(rows,colWidths=[WIDTH*w for w in weights],repeatRows=1,hAlign='LEFT',spaceBefore=6,spaceAfter=12)
            tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('VALIGN',(0,0),(-1,-1),'TOP'),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f2f6f9')]),
                ('LINEBELOW',(0,0),(-1,0),.6,BLUE),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d8e0e7')),
                ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
                ('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
            if story and hasattr(story[-1],'study_heading'):
                # A long, splittable table must not move an otherwise fitting
                # heading to a new page just because its total height is large.
                story[-1].keepWithNext=False
                story.insert(len(story)-1,CondPageBreak(75))
            story.append(tab);i+=1;continue
        if t.type in ('bullet_list_open','ordered_list_open'):
            list_depth+=1;ordered.append(int(t.attrGet('start') or 1) if t.type=='ordered_list_open' else None)
        elif t.type in ('bullet_list_close','ordered_list_close'):list_depth-=1;ordered.pop()
        elif t.type=='list_item_open':
            n=ordered[-1] if ordered else None;list_prefix=('・ ' if n is None else str(n)+'. ')
            if n is not None:ordered[-1]+=1
        elif t.type in ('fence','code_block'):
            body=escaped(t.content.rstrip(),'StudyMono').replace('\n','<br/>')
            story.append(KeepTogether([Paragraph(body,STYLES['code'])]))
        elif t.type=='hr':story.append(Spacer(1,10))
        elif t.type in ('blockquote_open','blockquote_close'):pass
        elif t.type=='html_block':story.append(Paragraph(escaped(t.content),STYLES['body']))
        else:warnings.append(t.type)
        i+=1
    doc=StudyDocument(str(destination),pagesize=A4,leftMargin=MARGIN,rightMargin=MARGIN,topMargin=18*mm,bottomMargin=21*mm,
        title='GeoSolverの構成・残差・目標精度を結ぶ機構分析',author='GeoSolver研究',allowSplitting=True)
    frame=Frame(MARGIN,21*mm,WIDTH,PAGE_H-39*mm,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
    def header(canvas,document):
        if document.page>2:
            canvas.saveState();canvas.setFont('IPAGothic',7.3);canvas.setFillColor(colors.HexColor('#607080'))
            canvas.drawString(MARGIN,PAGE_H-11*mm,'GeoSolver / 構成・残差・目標精度')
            canvas.setStrokeColor(colors.HexColor('#d8e0e7'));canvas.line(MARGIN,PAGE_H-13*mm,PAGE_W-MARGIN,PAGE_H-13*mm);canvas.restoreState()
    doc.addPageTemplates(PageTemplate(id='study',frames=frame,onPage=header))
    doc.multiBuild(story,canvasmaker=NumberedCanvas)
    reader=PdfReader(destination);extracted='\n'.join(p.extract_text() or '' for p in reader.pages)
    textpath=destination.with_suffix('.txt');textpath.write_text(extracted)
    receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'pdf':str(destination),'pdf_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'pages':len(reader.pages),
        'equations':len(equations),'figures':figures,'unhandled_token_types':sorted(set(warnings)),
        'text_characters':len(extracted),'embedded_fonts':[FONT_SERIF,FONT_SANS,FONT_MONO,FONT_FALLBACK],
        'missing_glyphs':sorted(MISSING_GLYPHS),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'visual_qa':'Rendering is not visual QA; inspect all final page PNGs separately.'}
    destination.with_suffix('.render.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:receipt[k] for k in ('pdf','pages','equations','text_characters','unhandled_token_types')},ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('markdown',type=Path);p.add_argument('pdf',type=Path);a=p.parse_args();render(a.markdown,a.pdf)
