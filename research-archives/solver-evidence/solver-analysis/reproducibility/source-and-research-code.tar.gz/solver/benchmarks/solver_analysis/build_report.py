"""Assemble an editable Japanese report from immutable measurements.

Draft mode explicitly marks unfinished analyses. Final mode refuses missing
evidence and unresolved placeholders. Human interpretation is stored in the
manuscript and versioned text fragments, not inferred from success counts.
"""
import argparse,hashlib,json,re
from datetime import datetime,timezone
from pathlib import Path
from report_figures import decode


def table(headers,rows):
    clean=lambda x:str(x).replace('|',' / ').replace('\n',' ')
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(clean(v) for v in row)+' |' for row in rows])
def fnum(x,places=2):return '未測定' if x is None else f'{float(x):,.{places}f}'
def reference_label(x):
    return re.sub(r'sqrt\(([^()]*)\)',r'√(\1)',str(x)).replace('**','^').replace('*','·').replace('pi','π')


class Report:
    def __init__(self,a,draft,review=False):self.a=a;self.draft=draft;self.review=review;self.inputs={};self.fragments={};self.missing=[]
    def read(self,name,lines=False,optional=False):
        p=self.a/name
        if not p.exists():
            if optional:return None
            raise FileNotFoundError(p)
        self.inputs[name]=hashlib.sha256(p.read_bytes()).hexdigest()
        if p.suffix=='.md':return p.read_text()
        return [decode(json.loads(v)) for v in p.read_text().splitlines()] if lines else decode(json.loads(p.read_text()))
    def fragment(self,key,fallback=None):
        text=self.read('report/fragments/'+key.lower()+'.md',optional=True)
        if text is not None:return text
        if fallback is not None:return fallback
        self.missing.append(key)
        return '**未完了：この節の結果と解釈は測定・監査後に挿入する。**'
    def run(self):
        data={};now=datetime.now(timezone.utc).isoformat()
        data['REPORT_VERSION']='作業草稿' if self.draft else '最終版 v1'
        data['COMPLETION_NOTICE']='**作業草稿。詳細測定、未知問題の評価、採否監査、最終査読が未完了のため、完成した研究結果として引用しない。**' if self.draft else self.fragment('COMPLETION_NOTICE','')
        if self.review:
            data['REPORT_VERSION']='最終査読用 v1'
            data['COMPLETION_NOTICE']='**最終査読用。測定・事前予測の採点・採否判断を含む本文。最終査読への回答と、それに伴う修正は配布版に反映する。**'
        pp=[['問題表現','構成・残差・目標・guard・bounds','評価不能点を条件違反と分ける'],
            ['初期点・探索','probeから多点探索、必要ならfallback','外部seedと内部seed、開始点、実評価費用'],
            ['候補保持','台帳、重複除去、順序と保持枠','保持群に条件付けた再実行と全探索比較を分離'],
            ['精密化','50/100/120桁LM、closure、rank経路','各段階80反復、減衰と停止イベントを保存'],
            ['元条件検証','guard、枝、非退化性、残差','修正前の検査と座標修正を伴う検証を別記'],
            ['値同定・出力','整数関係、候補不確かさ、descriptor','出力したrevisionだけを結果に対応付ける']]
        data['PIPELINE_TABLE']=table(['段階','入力・出力','今回の主な計測'],pp)+'\n\n詳細なソース対応は [実装対応表](../implementation-map.md) に示す。'
        history=[['F02・F26','構成依存と差分疎性の再利用','実時間内の評価量が変わる。反復の数学的改善とは別'],
            ['F05〜F07・F12','1変数の重複除去・枝走査','一値の成功と全値回収を分ける'],
            ['F08','極端な値だけ安全なノルム評価へ','探索器の目的関数と演算順の両方が変わり得る'],
            ['F14・F17','品質重み付き候補選択は不採用','無効果・悪化を残し、未知候補順位の万能則としない'],
            ['F20','早期の高精度安定判定を撤回','250桁通過でも500桁で境界棄却。偽の安定性'],
            ['F23','最終化の3秒予約を撤回','段階予算の変更が最終回収へ作用'],
            ['F25〜F29','限定されたキャッシュ・型検査の削減','同じ点・同じ精度等の成立条件を保つ'],
            ['F32・F33','数値backend変更を不採用','局所速度より互換性と小さい幾何量の保持を優先']]
        data['HISTORY_TABLE']=table(['変更','履歴の判断','今回の調査との関係'],history)
        hist=self.read('analysis/history-comparison-v1/summary.json')
        data['HISTORY_COMPARISON']=(f"照合済みの旧3 seedでは、solver-a1の完全一致が{hist['old_matched']}/{hist['runs']}、現行と同じsnapshotが{hist['new_matched']}/{hist['runs']}だった。"
            f"同じ問題・seedで不一致から一致へ変わったのは{hist['improved_pairs']}対、一致から不一致へ変わったのは{hist['worsened_pairs']}対である。"
            '改善はAIME-2018-II-14とJMO-2025-PRE-05、悪化はAIME-2016-I-15で、それぞれ1 seedだった。'
            'これは複数の変更を含む履歴上の差であり、個々の変更の因果効果とはみなさない。'
            '新しい5 seed実験と旧実験の時間を混ぜず、成功率のわずかな総差だけを高速化の証拠にしない。')
        gmb=self.read('analysis/history-comparison-v1/gmb-context.json')
        data['GMB_CONTEXT']=table(['既存36問・各3 seed','GeoSolver solver-a1','GMB'],[
            ['共通checkerで有効な一配置（許容値1e−6）',
             f"{gmb['configuration']['geosolver']['primary']['success_runs']}/108",f"{gmb['configuration']['gmb']['primary']['success_runs']}/108"],
            ['3 seed全てで有効な配置を得た問題',f"{gmb['configuration']['geosolver']['cases_succeeded_all_seeds']}/36",f"{gmb['configuration']['gmb']['cases_succeeded_all_seeds']}/36"],
            ['元GMBの結論評価だけに通過（評価可能出力が分母）','87/90','74/86'],
            ['最初の出力が配置検査と結論評価の両方を通過','83/108','29/108']])
        strata=self.read('analysis/baseline-v1/strata.json')
        labels={'zero':'自由変数なし','scalar':'1変数','multivariate':'多変数'}
        data['BASELINE_TABLE']=table(['集合','問題','実行','数値配置診断','一値の正答','完全一致','時間中央値（秒）'],[
            [labels[k],r['problems'],r['runs'],r['numeric_feasible_reported'],r['any_reference_answer'],r['matched'],fnum(r['median_wall'])] for k,r in strata.items()])
        detail=self.read('analysis/detail-v1/summary.json',optional=True)
        if detail:
            data['DETAIL_RESULTS']=(f"47問×30 seedの{detail['main_runs']:,}実行と、seed 0・1を反復した{detail['repeat_runs']}実行を解析した。"
                f"30回すべて完全一致した問題は{detail['stable30']}問、成否が分かれた問題は{detail['mixed']}問、全て不一致は{detail['never_matched']}問だった。"
                f"同じseedの反復で完全一致の判定が変わったのは{detail['same_seed_outcome_changes']}/{detail['repeat_runs']}対、出力集合が一致したのは{detail['same_seed_same_answers']}対だった。\n\n"
                f"内部seedの重なりがある外部seed対は{detail['pairs_with_internal_seed_overlap']:,}、保存された候補点が少なくとも一つ一致する対は{detail['pairs_with_identical_retained_point']:,}だった。"
                f"出力revisionとの照合不一致は{detail['emission_revision_conflicts']}件。問題別の成功率を再標本化した記述的95%区間は{fnum(100*detail['problem_bootstrap95'][0],1)}〜{fnum(100*detail['problem_bootstrap95'][1],1)}%である。"
                'これは結果に基づいて選んだ詳細集合内の不確かさで、自然問題母集団の信頼区間ではない。')
        else:data['DETAIL_RESULTS']=self.fragment('DETAIL_RESULTS')
        stage=self.read('analysis/stage-v3/summary.json',optional=self.draft)
        if stage is None:stage=self.read('analysis/stage-v2b/summary.json')
        chosen=['original__lm50','original__lm100','original__lm200','projection__lm50','projection__lm100','projection__lm200','projection_squared__lm200']
        rows=[]
        for name in chosen:
            r=next(v for v in stage if v['case_id']=='JMO-2013-PRE-05' and v['condition']==name)
            label=name.replace('original__lm','元残差 / ').replace('projection_squared__lm','再二乗 / ').replace('projection__lm','signed / ')
            rows.append([label,r['n'],fnum(r['median_pre_verifier_goal_digits']),r['pre_20digit_goal'],r['median_lm_steps'],fnum(r['median_numeric_seconds'],3)])
        data['JMO_INTERVENTION_TABLE']=table(['残差 / dps','開始数','目標精度中央値','20桁到達','LM反復中央値','数値時間中央値（秒）'],rows)
        if all('pre_independent_conditions_and_20digit_goal' in r for r in stage):
            checked=[r for r in stage if r['case_id']=='JMO-2013-PRE-05' and r['condition'] in ('projection__lm50','projection__lm100','projection__lm200')]
            data['JMO_INTERVENTION_TABLE']+=('\n\n別に導いた元の距離・接触条件とstrictな定義域を、verifierへ渡す前の座標で検査した。signed腕で元条件の数値検査と目標20桁の両方を満たしたのは、50/100/200桁でそれぞれ'+
                '、'.join(str(r['pre_independent_conditions_and_20digit_goal'])+'/'+str(r['n']) for r in sorted(checked,key=lambda r:int(r['condition'].split('lm')[1])))+'点だった。これは数値検査であり、各点への区間存在証明ではない。')
        hmmt_labels={'original__native_refine':'元残差・通常HP','signed_contact__native_refine':'接触のsigned一次化',
            'contact_squared__native_refine':'接触の再二乗','incidence_saturated__native_refine':'incidence因子除去','both_relative__native_refine':'両式の相対残差'}
        data['HMMT_RESULTS']=table(['介入','目標20桁 / 149','独立な元条件＋20桁 / 149','数値時間中央値（秒）'],[[hmmt_labels[name], r['pre_20digit_goal'],r.get('pre_independent_conditions_and_20digit_goal','未検査'),fnum(r['median_numeric_seconds'],3)]
            for name in ('original__native_refine','signed_contact__native_refine','contact_squared__native_refine','incidence_saturated__native_refine','both_relative__native_refine')
            for r in [next(v for v in stage if v['case_id']=='HMMT-2014-FEB-GEO-10' and v['condition']==name)]])+'\n\n![同じ保持点でのHMMT2014介入](figures/hmmt-paired.png)'
        pred=self.read('unknown-intake/individual-predictions-v1.json')
        data['UNKNOWN_DESIGN_TABLE']=table(['集合','役割','数え方'],[
            ['元の自然30＋30問','途中・最終の大域測定と被覆率','各集合CEMC/UKMT/HMMT各10問'],
            ['General6 / Guts17 / Euclid2024-8Aの構成表現','規則構築に関与した自然入力の局所予測','新しい独立自然問題へ重複計上しない'],
            ['観測点オフセットの生成接触族','途中確認で目標次数と相殺を検査','1幾何族、3目標は同じ軌道'],
            ['規則固定後の自然追加4問','機構で選んだ正例・負例の移転','元60問と別の選定母集団'],
            ['放物線法線写像と高さ±.01','別DAGのfold・2根・0根対照','1生成構造族の3条件']])
        comparisons=self.read('literature/comparison-v1.md')
        data['LITERATURE_TABLE']=comparisons[comparisons.index('| 論点'):comparisons.index('## 採用しない')].strip()
        problem=self.read('analysis/baseline-v1/problem-results.json')
        data['PROBLEM_APPENDIX']=('全323問のseed 0〜4の結果。ここでの完全一致は、採用DSLに対する採点用参照集合との一致である。原問題とDSLの全ての意味同値性や、全解の数学的認証とは別である。完全一致と一値は5実行中の件数。時間は失敗を含む中央値。詳細なrun単位の段階・候補情報は [run索引](../analysis/baseline-v1/run-index.jsonl) にある。\n\n'+
            table(['問題ID','変数','完全一致 / 5','一値 / 5','時間中央値（秒）'],[[i,r['variables'],r['matched'],r['any_reference_answer'],fnum(r['median_wall'])] for i,r in sorted(problem.items())]))
        if detail:
            d=self.read('analysis/detail-v1/problem-results.json')
            data['PROBLEM_APPENDIX']+='\n\n### 詳細47問の30 seed結果\n\n'+table(['問題ID','完全一致 / 30','一値 / 30','時間中央値（秒）','fallback'],[
                [r['case_id'],r['matched'],r['any_reference_value'],fnum(r['median_wall']),r['staged_fallback_triggered']] for r in d])
        for split in ('mid','final'):
            refs=self.read(f'unknown-references/assessment-v1/{split}-assessment-cases.jsonl',lines=True)
            ref_by_id={r['id']:r for r in refs}
            q=self.read(f'analysis/unknown-{split}-global-v1/problem-results.json',optional=True)
            if q:data['PROBLEM_APPENDIX']+='\n\n### '+('途中' if split=='mid' else '最終')+'自然30問\n\n問題IDのリンクは独立参照の公式解答。完全一致・一値は3実行中の件数。\n\n'+table(['問題ID','参照値集合','変数','完全一致 / 3','一値 / 3','時間中央値（秒）'],[
                [f"[{r['case_id']}]({ref_by_id[r['case_id']]['reference_provenance']['url']})",', '.join(reference_label(v) for v in ref_by_id[r['case_id']]['answer']),r['variables'],r['matched'],r['any_reference_value'],fnum(r['median_wall'])] for r in q])
        rejected=[['低残差なら目標も同じ桁数で正しい','棄却','接触二乗と一次目標、禁止境界、目標だけの相殺が反例'],
            ['作業精度を上げれば同じ反復数で必ず目標精度が改善','棄却','JMOの50/100/200桁固定反復で元残差の精度が変わらない'],
            ['平方根の差の相殺が主原因','中心説明として棄却','内部平滑化と再二乗が停滞を保つ。安定評価と一次化は別'],
            ['λfloorの大小だけで100桁段階の停止が決まる','改訂','段階再初期化後の最初の5回では今回のfloorは作用しない'],
            ['最小特異値だけでLM改善率を予測できる','棄却','残差の左特異方向成分と非線形余項が必要。σ_eff²も単独では十分でない'],
            ['小さいJacobian行は恒等式','棄却','1e−30 z=0は正則制約。証明した恒等行だけ除く'],
            ['有限点の勾配で根のqを判定','棄却','G=w²の非零点は勾配が非零。静的証明か保留を用いる'],
            ['q=2なら一次化による桁数の利益が常に小さい','不採用','必要な精度と実現した桁数増分は異なる'],
            ['構成DAGだけで問題全体に一つのmが付く','棄却','枝・guardと残差の選択が必要。法線写像のguard外に単純根がある'],
            ['HMMT2013の退化除外は原問題で明瞭','採用保留','DSLの除外と原文の意味を分ける'],
            ['AIME2003の第三値未回収は境界候補が主因','棄却','二つの正答後の列挙経路と遠方根の回収が別問題'],
            ['JMO未出力は精密化だけが原因','棄却','同じ高精度候補から値提案の継続だけで正答を得る場合がある']]
        data['REJECTED_APPENDIX']=table(['仮説','判断','根拠・限定'],rejected)+'\n\n旧変更34件の採否を保存した [変更・判断索引](../history/reuse-integrity-v1/changes-and-decisions.md) も参照されたい。'
        audits=[['第1回 GPT-6 Pro','主要仮説と介入の固定前','半径発散・二次消失・相殺を分離。AIMEの因果帰属と原文曖昧性を訂正','01-hypothesis-audit.md'],
            ['第2回 GPT-6 Pro','未知予測の前','有限点からqを認証しない。恒等行の証明、全横特異値、元条件の非修正検査を追加','02-prediction-audit.md'],
            ['Sol-01〜04','導出・写像・移転の通常点検','目標の解外拡張、二次形式の相殺、別DAGの限界を独立式で確認','sol-04-transfer-review.md'],
            ['Sol-05','段階再初期化と5回停止','係数4を含む十分条件、残差で重み付けした感度、既知理論との境界','sol-05-response-and-disposition.md']]
        data['AUDIT_APPENDIX']=table(['監査','時点','主な対応','記録'],[[x,y,z,f'[{Path(p).stem}](../audits/{p})'] for x,y,z,p in audits])+'\n\n'+self.fragment('LATE_AUDITS')
        data['REPRO_APPENDIX']=self.fragment('REPRO_APPENDIX')
        data['MATH_APPENDIX']=self.fragment('MATH_APPENDIX')
        data['CLAIM_APPENDIX']=self.fragment('CLAIM_APPENDIX')
        for key in ('ABSTRACT_PROSPECTIVE','DAMPING_RESULTS','EXACTIFICATION_RESULTS','SELECTION_AND_COMPARATORS',
            'MID_RESULTS','MID_ADOPTION','FINAL_RESULTS','ROOTFREE_RESULTS','PREDICTION_SCORECARD','NOVELTY_ASSESSMENT','CONCLUSIONS'):
            data[key]=self.fragment(key)
        source=self.read('report/manuscript.md')
        needed=set(re.findall(r'\{\{([A-Z_]+)\}\}',source));assert needed<=set(data),needed-set(data)
        if (not self.draft or self.review) and self.missing:raise ValueError('Unfinished report: '+','.join(self.missing))
        result=re.sub(r'\{\{([A-Z_]+)\}\}',lambda m:data[m[1]],source)
        assert not re.search(r'\{\{[A-Z_]+\}\}',result)
        if not self.draft or self.review:
            required=['audits/03-adoption-decision.json','analysis/prediction-final-v1/summary.json','analysis/stage-v3/summary.json']
            if not self.review:required.append('audits/04-final-review-response.md')
            for name in required:
                self.read(name)
            assert '未完了：この節' not in result
        out=self.a/'report'/('research-report-ja-review-v1.md' if self.review else 'research-report-ja-draft.md' if self.draft else 'research-report-ja.md')
        out.write_text(result)
        manifest={'created_utc':now,'draft':self.draft,'review':self.review,'missing_interpretation_fragments':self.missing,
            'source_files':self.inputs,'output':str(out),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        mpth=out.with_suffix('.manifest.json');mpth.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
        print(json.dumps({'output':str(out),'characters':len(result),'missing':self.missing},ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path)
    mode=p.add_mutually_exclusive_group();mode.add_argument('--draft',action='store_true');mode.add_argument('--review',action='store_true')
    a=p.parse_args();Report(a.archive,a.draft or a.review,a.review).run()
