"""Source-equivalent contact constructions authored before unknown outcomes.

These are additional representations of already selected problems, not additional
independent problems. The manifest distinguishes target extensions off the
solution set and records the branch restrictions of physical-start matching.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from unknown_authoring import c,eq,gt,lt,pred,segment
from contact_detector import detect,transform


def general6(original):
    d={'id':original['id'],'variables':['x','t'],'constructions':[
        c('A','Point(0,0)'),c('B','Point(5,0)'),c('C','Point(5,5)'),c('D','Point(0,5)'),
        c('X','Point(x,0)'),c('T','Point(t,5)'),c('omega','Circumcircle(A,X,T)'),
        c('O','Center(omega)'),c('r','Radius(omega)'),
        c('Y','Intersect(omega,Line(A,D),exclude=A)'),c('Tf','ClosestPoint(O,Line(C,D))')],
        'conditions':[eq('IsTangent(Line(C,D),omega)'),eq('Distance(X,Y)',6)]+segment('T','C','D'),
        'target':'Distance(A,T)'}
    physical=copy.deepcopy(d);physical['target']='Distance(A,Tf)'
    return {'constructed_aux_target':d,'constructed_physical_target':physical}, {
        'solution_correspondence':'On the source solution set the top-line contact is unique, T=Tf. The second x-axis intersection X is nonzero: x=0 would force the circle tangent to both axes/top with XY=5, contradicting XY=6. Reflection is not discarded; T in CD selects the right half.',
        'circle_map':'u=x/2, v=(t^2-t*x+25)/10, R=sqrt(u^2+v^2)',
        'fold':'h=u-t; v=(h^2+25-u^2)/10. Rank drops in the h direction at h=0. Each physical circle crossing CD has two preimages t=u +/- sqrt(10*v+u^2-25); the discriminant-negative side has none.',
        'common_start_scope':'Only circles through A and crossing CD can be matched to this construction, retaining both top intersections. This is a conditional physical-start comparison, distinct from each representation native initialization.',
        'target_extension_warning':'sqrt(t^2+25) and sqrt(u^2+25) agree on roots but differ off roots. Along the fold kernel, the auxiliary target has a nonzero first derivative when t!=0; the physical foot target has zero first derivative. Compare both targets on exactly the same numerical trajectory.',
        'no_uniform_lower_bound':'Goal-error lower bounds require a specified non-cancelling direction. The local upper bound is the principal prediction.'}


def guts17(original):
    d=copy.deepcopy(original);d['variables']=['t0','t1','t2']
    d['constructions']=[v for v in d['constructions'] if v['name'] in ('A','B','C','Ab','Ac','Ba','Bc','Ca','Cb')]
    sides=[('Ab','Ac'),('Ba','Bc'),('Ca','Cb')]
    for i,(a,b) in enumerate(sides):d['constructions'].append(c(f'T{i}',f'Point({a}.x+t{i}*({b}.x-{a}.x),{a}.y+t{i}*({b}.y-{a}.y))'))
    d['constructions'] += [c('omega','Circumcircle(T0,T1,T2)'),c('O','Center(omega)'),c('r','Radius(omega)')]
    d['conditions']=sum(([eq(f'IsTangent(Line({a},{b}),omega)')]+segment(f'T{i}',a,b) for i,(a,b) in enumerate(sides)),[])
    d['target']='r'
    return {'constructed':d},{
        'solution_correspondence':'A circle tangent to three nonparallel segments has three distinct noncollinear tangent points. Each lies on its segment and is a construction parameter. Conversely a circumcircle tangent to each line through its defining point has that point as its unique contact, so segment tangency is preserved.',
        'circle_map_derivative':'Let n_i=(T_i-O)/R. Differentiating |T_i-O|^2=R^2 gives n_i.dO+dR=n_i.dT_i=0 at contact. If rows [n_i.x,n_i.y,1] have full rank, dO=dR=0.',
        'second_order_goal':'For T_i=T_i*+epsilon*a_i*e_i, n_i.e_i=0, the quadratic coefficients satisfy n_i.O2+R2=a_i^2/(2R). Thus R2 is a linear combination of a_i^2. Positive weights give a uniform q=2 lower bound; without that condition only q>=2 upper order is claimed.',
        'common_start_scope':'A source physical circle must intersect all three cut lines; select and retain every branch whose intersection lies on the corresponding segment, then form the circumcircle. Circles missing a line have no real matched constructed start.',
        'target_extension':'Both targets are the radius of the same physical circle, including off-solution states. No auxiliary-target substitution.'}


def cemc8(original):
    d={'id':original['id'],'variables':['d','e','f','g'],'constructions':[
        c('A','Point(0,0)'),c('B','Point(0,3)'),c('omegaA','Circle(A,4)'),c('omegaB','Circle(B,3)'),
        c('D','Point(4*cos(d),4*sin(d))'),c('E','Point(3*cos(e),3+3*sin(e))'),
        c('F','Point(4*cos(f),4*sin(f))'),c('G','Point(3*cos(g),3+3*sin(g))'),
        c('L','Line(D,E)'),c('R','Line(F,G)'),c('bottom','Line(Point(0,-4),Point(1,-4))'),
        c('C','Intersect(L,R)'),c('M','Intersect(L,bottom)'),c('N','Intersect(R,bottom)')],
        'conditions':[eq(f'IsTangent({line},{circle})') for line in ('L','R') for circle in ('omegaA','omegaB')]
            +[lt('M.x',0),gt('N.x'),gt('C.y',6)]
            +sum((segment(p,'C',end,True) for p,end in [('D','M'),('E','M'),('F','N'),('G','N')]),[]),
        'target':'Area(M,N,C)'}
    return {'constructed':d},{
        'solution_correspondence':'Each common external tangent has one contact on each fixed circle. Four angle parameters cover those contacts. M<0<N, C.y>6 and strict foot segment membership retain the source diagram branch. At a solution D!=E and F!=G because the distinct circles have center separation3 and radii4,3, so external contact points are distinct.',
        'circle_membership':'The generic detector certifies the four point-circle incidences by exact coordinate algebra and sin^2+cos^2=1; circle radii remain the original constants4,3.',
        'map_derivative':'At common tangency, D_prime and E_prime are parallel to their shared tangent line. Hence the line through D,E has zero first variation for arbitrary infinitesimal angle changes. The same holds for F,G; therefore C,M,N and their area have zero first variations away from parallel-line and intersection degeneracies.',
        'orders':'Each signed contact coordinate has a nonzero derivative in its own contact angle at the root. Their joint Jacobian is diagonal up to orientation and positive circle radii. Raw tangency residuals have order2 while the common physical triangle area has order at least2. Only an upper goal-error bound O(residual norm) is claimed unless its quadratic form is separately definite.',
        'common_start_scope':'Match only physical left/right lines meeting both circles in real distinct points and giving the required triangle orientation. Retain all available intersection choices; native-angle starts are a separate comparison.'}


def build(intake,destination):
    if destination.exists():raise FileExistsError(destination)
    destination.mkdir(parents=True);manifest=[]
    for directory,ident,fn in [('authored-hmmt-v1','HMMT-NOV-2023-GEN-06',general6),('authored-hmmt-v1','HMMT-NOV-2023-GUTS-17',guts17),('authored-cemc-v0','CEMC-EUCLID-2024-08A',cemc8)]:
        original_path=intake/directory/'dsl'/(ident+'.json');original=json.loads(original_path.read_text())
        variants,proof=fn(original);variants={'original':original,**variants}
        base_variants=list(variants.items())
        for name,dsl in base_variants:
            detection=detect(dsl)
            if detection['positive']:
                for mode in ('signed','squared','stable_gap'):variants[name+'__'+mode]=transform(dsl,detection,mode)
        files={}
        for name,dsl in variants.items():
            from geosolver.problem.models import GeometryProblem
            from geosolver.problem.validation import validate
            report=validate(GeometryProblem.model_validate(dsl))
            if not report.valid:raise ValueError((ident,name,report))
            path=destination/ident/(name+'.json');path.parent.mkdir(exist_ok=True)
            path.write_text(json.dumps(dsl,indent=2)+'\n');files[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'detected_contacts':len(detect(dsl)['contacts'])}
        manifest.append({'case_id':ident,'source_input':str(original_path),'proof_obligations':proof,'variants':files,'solver_outcomes_seen':False})
    (destination/'manifest.json').write_text(json.dumps({'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'problems':manifest},indent=2)+'\n')
    print(json.dumps({'problems':len(manifest),'representations':sum(len(r['variants']) for r in manifest)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('intake',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();build(a.intake,a.destination)
