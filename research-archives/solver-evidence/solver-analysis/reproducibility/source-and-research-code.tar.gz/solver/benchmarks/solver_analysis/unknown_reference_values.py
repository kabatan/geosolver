"""Independent reference values, recorded only after forecasts were frozen.

This module is assessment-only and is never imported by solver/pilot runners.
Values are taken from the archived official derivations or explicitly adapted
from their fully enumerated branches. All-source coverage is checked at build.
"""
import argparse
import hashlib
import json
from pathlib import Path

VALUES={
 'HMMT-NOV-2022-GEN-06':['(2+sqrt(3))*pi'],
 'HMMT-NOV-2022-THM-04':['7','15'],
 'HMMT-NOV-2023-GEN-02':['630'],
 'HMMT-NOV-2023-GEN-04':['61'],
 'HMMT-NOV-2023-GEN-06':['sqrt(30)'],
 'HMMT-NOV-2023-THM-02':['36-21*sqrt(2)','36+21*sqrt(2)'],
 'HMMT-NOV-2023-THM-04':['23'],
 'HMMT-NOV-2023-THM-09':['3*sqrt(610)/5'],
 'HMMT-NOV-2023-TEAM-01':['sqrt(5)'],
 'HMMT-NOV-2023-TEAM-03':['sqrt(15)'],
 'HMMT-NOV-2023-TEAM-07':['143/5'],
 'HMMT-NOV-2023-GUTS-03':['575'],
 'HMMT-NOV-2023-GUTS-05':['36'],
 'HMMT-NOV-2023-GUTS-11':['1+sqrt(2)'],
 'HMMT-NOV-2023-GUTS-14':['60/11'],
 'HMMT-NOV-2023-GUTS-17':['3*sqrt(3)'],
 'HMMT-NOV-2023-GUTS-20':['100'],
 'HMMT-NOV-2023-GUTS-23':['sqrt(401/5)'],
 'HMMT-NOV-2023-GUTS-25':['192'],
 'HMMT-NOV-2023-GUTS-29':['3*sqrt(3)'],
 'CEMC-EG-01':['36'],
 'CEMC-EG-03':['15'],
 'CEMC-EG-04':['1/2'],
 'CEMC-EG-05':['19'],
 'CEMC-EG-08':['65/2'],
 'CEMC-EG-10':['302*sqrt(2)'],
 'CEMC-EG-13':['32'],
 'CEMC-EUCLID-2024-01B':['25'],
 'CEMC-EUCLID-2024-04A':['9'],
 'CEMC-EUCLID-2024-04B':['4/5'],
 'CEMC-EUCLID-2024-05A':['1','4','9'],
 'CEMC-EUCLID-2024-08A':['64*sqrt(2)'],
 'CEMC-EUCLID-2024-10A':['-1/2'],
 'CEMC-EUCLID-2023-02B':['8'],
 'CEMC-EUCLID-2023-05B':['39'],
 'CEMC-EUCLID-2023-06B':['9/10'],
 'CEMC-EUCLID-2022-04A':['29'],
 'CEMC-EUCLID-2022-04B':['22','46'],
 'CEMC-EUCLID-2022-07B':['13/7'],
 'CEMC-EUCLID-2022-08A':['5/2'],
 'UKMT-SMC-2024-04':['100'],
 'UKMT-SMC-2024-15':['sqrt(19)'],
 'UKMT-SMC-2024-18':['sqrt(14)/2-1'],
 'UKMT-SMC-2024-22':['4'],
 'UKMT-SMC-2024-25':['12'],
 'UKMT-SMC-2023-03':['2'],
 'UKMT-SMC-2023-05':['12'],
 'UKMT-SMC-2023-13':['1/2'],
 'UKMT-SMC-2023-14':['6','10'],
 'UKMT-SMC-2023-21':['1+sqrt(3)'],
 'UKMT-SMC-2023-23':['13/18'],
 'UKMT-SMC-2023-24':['3-sqrt(3)'],
 'UKMT-SMC-2022-04':['8/21'],
 'UKMT-SMC-2022-08':['72'],
 'UKMT-SMC-2022-13':['9'],
 'UKMT-SMC-2022-14':['25/81'],
 'UKMT-SMC-2022-17':['2+2*sqrt(2)-sqrt(3)'],
 'UKMT-SMC-2022-20':['40'],
 'UKMT-SMC-2022-21':['4+pi'],
 'UKMT-SMC-2022-23':['441/2'],
}

ADAPTATIONS={
 'HMMT-NOV-2023-THM-02':'Official derivation enumerates two areas 3sqrt(2)*(6sqrt(2)±7); benchmark returns both, rather than their product414.',
 'HMMT-NOV-2022-THM-04':'Both integer tower heights7 and15 explicitly enumerated; positive horizontal separation excludes the other divisor pairs of105.',
 'CEMC-EUCLID-2024-04B':'The benchmark returns only the x coordinate of the source point (4/5,18/5).',
 'CEMC-EUCLID-2024-05A':'For three given rectangle areas2,3,6, the fourth is the product of two divided by the third. The six permutations give exactly1,4,9.',
 'CEMC-EUCLID-2024-10A':'The benchmark returns only P.x from the independently derived source point(-1/2,2).',
 'CEMC-EUCLID-2023-05B':'Source pair(a,b)=(24,15) maps to benchmark scalar a+b=39; this is not recovery of the ordered pair.',
 'UKMT-SMC-2023-13':'Source angles(TPU,PUT,UTP)=(18,54,108) give benchmark PUT/PTU=54/108=1/2.',
 'UKMT-SMC-2023-14':'Source derivation gives d=6 or10. Benchmark returns both individually, not their sum16.',
}


def build(archive,destination):
    if destination.exists():raise FileExistsError(destination)
    intake=archive/'unknown-intake';root=archive/'unknown-references'
    sources=json.loads((root/'official-source-manifest-v1.json').read_text());receipts=json.loads((root/'sources/official-source-manifest-v1-receipt.json').read_text())
    hashes={r['name']:r['sha256'] for r in receipts};destination.mkdir(parents=True)
    all_ids=[]
    for split in ('mid','final'):
        rows=[]
        for line in (intake/'corpus-v1'/split/'cases.jsonl').read_text().splitlines():
            row=json.loads(line);ident=row['id'];all_ids.append(ident)
            if ident not in VALUES:raise ValueError('missing independent reference: '+ident)
            prefix=ident.rsplit('-',1)[0]
            if ident.startswith('CEMC-EUCLID'):prefix='-'.join(ident.split('-')[:3])
            name=prefix+'-solutions.pdf'
            row.update(answer=VALUES[ident],truth_status='verified',dsl_path=str(intake/'corpus-v1'/split/row['dsl_path']),
                reference_provenance={'kind':'official mathematical solution and branch enumeration',
                    'url':sources[name],'archived_source_sha256':hashes[name],
                    'adaptation':ADAPTATIONS.get(ident),'solver_outputs_used':False})
            rows.append(row)
        p=destination/(split+'-assessment-cases.jsonl');p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    assert len(all_ids)==60 and set(all_ids)<=VALUES.keys()
    manifest={'count':len(all_ids),'complete_value_sets':len(all_ids),'source':'official derivations and documented scalar adaptations',
        'assessment_only':True,'predictor_and_solver_corpus_unchanged':True,
        'forecast_sha256':hashlib.sha256((intake/'individual-predictions-v1.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('destination',type=Path)
    a=p.parse_args();build(a.archive,a.destination)
