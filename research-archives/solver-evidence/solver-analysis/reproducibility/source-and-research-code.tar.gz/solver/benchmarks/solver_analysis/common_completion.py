"""Shared production finalization after fixed-work common-start frontends.

Optional HP replays cross the saved selected frontend points with another
residual. The frontend is never rerun and no reference is read here.
"""
import argparse,dataclasses,hashlib,json,time
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from paired_stages import run_point,bundle_of
from stage_replay import ensure_source
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.orchestration.assemble_exact_results import assemble_exact_results
from geosolver.runtime.deadline import runtime_session


def run(source,out,hp_dsl=None):
    if out.exists():raise FileExistsError(out)
    r={'source':str(source),'source_hash':ensure_source(),'finalization_budget_seconds':10,
        'scope':'Fixed-work frontend plus native HP and native Phase C; not the ordinary full 180-second pipeline.',
        'reference_access':False}
    out.parent.mkdir(parents=True,exist_ok=True)
    if not source.exists():
        r['gate']='missing_frontend_output';out.write_text(dumps(r)+'\n');return
    old=loads(source.read_text());original=old['common_pool']['dsl'];r['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    r.update(case_id=original['id'],frontend_backend=old['backend'],frontend_dsl_id=old['intervention_dsl']['id'],
        selected_hp_input_count=len(old['selected_hp_inputs']),frontend_censored=old['search_safety_censored'])
    if hp_dsl is None:
        hp=old['hp_results'];r['hp_source']='reuse frozen native HP result'
    else:
        dsl=json.loads(hp_dsl.read_text());hp=[];r['hp_source']='fresh paired HP restart';r['hp_dsl_path']=str(hp_dsl)
        r['hp_dsl_sha256']=hashlib.sha256(hp_dsl.read_bytes()).hexdigest()
        for j,row in enumerate(old['selected_hp_inputs']):
            point={'x':row['x'],'uid':f'cross/{old["backend"]}/{row["start_index"]}/{j}',
                'external_seed':old['config']['seed'],'source_revision':0,'origin_start_index':row['start_index']}
            hp.append(run_point(dsl=dsl,original=original,point=point,engine='native_refine',dps=120,
                iterations=80,seconds=30,damping=None,rank_cap=None,verify=False))
    r['hp_results']=hp;candidates=[];unavailable=[]
    for j,item in enumerate(hp):
        batch=item.get('output')
        if hasattr(batch,'candidates'):candidates.extend(batch.candidates)
        else:unavailable.append({'selected_hp_index':j,'status':item.get('status'),'error':item.get('error')})
    r.update(refined_candidate_count=len(candidates),hp_unavailable=unavailable,
        hp_numeric_seconds=sum(v.get('numeric_seconds',0) for v in hp),
        hp_censored=sum(v.get('safety_deadline_hit',False) for v in hp))
    started=time.monotonic();evaluator=build_ir_evaluator(bundle_of(original))
    try:
        with mp.workdps(180),runtime_session(started+10) as timing:
            result=assemble_exact_results(refined_candidates=tuple(candidates),evaluator=evaluator,
                input_precision_dps=120,deadline_monotonic=started+10)
        r.update(gate='completed',assembly=dataclasses.asdict(result),finalization_counters=timing.counters,
            finalization_phase_seconds=dict(timing),answer_values=list(result.answer_values))
    except Exception as ex:r.update(gate='error',error=type(ex).__name__+': '+str(ex))
    r.update(finalization_seconds=time.monotonic()-started,finalization_censored=time.monotonic()>=started+10,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    out.write_text(dumps(r)+'\n');print(json.dumps({k:r.get(k) for k in ('case_id','gate','refined_candidate_count','answer_values','finalization_seconds')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--hp-dsl',type=Path)
    a=p.parse_args();run(a.source,a.output,a.hp_dsl)
