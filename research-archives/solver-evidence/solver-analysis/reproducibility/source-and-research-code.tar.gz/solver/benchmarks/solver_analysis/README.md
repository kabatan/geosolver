# GeoSolver mechanism study

Fixed product baseline: `e703e2d99484793f162f961bc50126ae65e4069f`.
Product source hash: `6d59d43c8bcbe882e0cf35457e1671ed7ef94a421b6c67c8c98268308f2fe758`.

This directory contains reusable research code. Do not change `src/geosolver`
for this study. Results and reports belong under
`/home/kabatan/work/solver-experiment/research-archives/solver-analysis/`.
No new worktrees are needed.

## Evidence boundaries

* The existing 323 cases and all previous synthetic cases are development data.
* Archived outcomes are discovery evidence; their 16-worker wall times must not
  be pooled with the new 8-worker campaign as if execution conditions matched.
* The initial detailed cohort is the 19 historically fragile cases plus 21
  deterministic matched successful controls. Selection uses outcomes explicitly.
* Performance runs use the uninstrumented fixed solver, 180 seconds, one physical
  core per process, one numerical-library thread, eight concurrent processes.
* Instrumented and fixed-work stage experiments have distinct labels. A changed
  deadline outcome is not evidence that a numerical operation changed.
* Stage replays preserve candidate provenance, revision, binary float values,
  and exact mpmath mantissa/exponent tuples. A 500-digit working precision is not
  a claim of 500 correct digits.
* References are unavailable to solve/replay functions. Assessment is separate.
* Seed repetitions are dependent within a case. Fallback internal seed sets
  overlap. Uncertainty is clustered by problem or structural family.
* New natural mid-study and final sets each contain 30 cases, selected without
  using solver outcomes; predictions and applicability freeze before execution.
  Revised theories require fresh confirmation cases.
* GPT-6-Pro audits occur before mechanism selection, before unknown predictions,
  after unknown outcomes, and during final review. GPT-5.6-Sol-Pro is a routine
  adversarial mathematical advisor. Reviews are not experimental evidence.

## Programs

`archive_audit.py ARCHIVE OUTPUT` streams the historical archive, validates every
member against its saved hash, selects the 40-case discovery cohort, and saves
the raw selected runs and compact index. No solver is executed.

## Acceptance of a mechanism

A primary claim needs a natural phenomenon, competing explanations, a causal
intervention on comparable states, a derivation from geometric structure,
preregistered unused-case predictions, and counterexamples. Generic sensitivity,
initial-value dependence, fitted power laws, and bugs alone do not meet this bar.
The study aims for two or three substantial explanations with at least one deep
enough to support the central research claim. Unfinished gates stay unfinished.
