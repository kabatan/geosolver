"""Independent analytic charts and geometry for the frozen local forecasts.

No GeoSolver residual, target, reference file or optimizer is imported. The
HMMT2025 chart uses mpmath only to solve the two *other* distance equations on
the input-proved local implicit manifold, never to optimize the tangencies.
"""
import random
from mpmath import mp
from physical_maps import (add,sub,mul,dot,cross,norm,circle,line,meet,
    constructed_to_physical,all_lifts,cuts,segment_parameter,intersections)

GEN='HMMT-NOV-2023-GEN-06';GUTS='HMMT-NOV-2023-GUTS-17'
CEMC='CEMC-EUCLID-2024-08A';CEMC26='CEMC-EUCLID-2026-08A'
H25='HMMT-NOV-2025-GEN-08';G25='HMMT-NOV-2025-GUTS-12'
UK25='UKMT-SMC-2025-16';PARA='GENERATED-PARABOLA-NORMAL-FOLD'
DIMENSIONS={GEN:1,GUTS:3,CEMC:4,CEMC26:1,H25:4,G25:1,UK25:3,PARA:1}


def polygon(points):return abs(sum(cross(p,points[(i+1)%len(points)]) for i,p in enumerate(points)))/2
def foot(O,L):
    n,p=L[:2];return add(O,mul(n,p-dot(n,O)))
def gap(O,R,L):return R-abs(dot(L[0],O)-L[1])
def positive_offset(L):
    n,p=L[:2];return (mul(n,-1),-p,L[2]) if p<0 else L


def h25_geometry(values):
    a,b,d,e,f,g=values;os=[(a,mp.mpf(5)),(b,mp.mpf(5))]
    rs=[mp.sqrt(a*a+25),mp.sqrt(b*b+25)]
    pts=[add(os[j],mul((mp.cos(t),mp.sin(t)),rs[j])) for j,t in zip((0,1,0,1),(d,e,f,g))]
    ls=[positive_offset(line(*pts[:2])),positive_offset(line(*pts[2:]))]
    feet=[foot(o,l) for l in ls for o in os]
    aux=polygon([pts[i] for i in (0,2,3,1)]);phys=polygon([feet[i] for i in (0,2,3,1)])
    original=(a,b,mp.atan2(ls[0][0][1],ls[0][0][0]),mp.atan2(ls[1][0][1],ls[1][0][0]))
    side_margins=[l[1]-dot(l[0],o) for l in ls for o in os]
    return {'original_coordinates':original,'lines':ls,'centres':os,'radii':rs,'points':pts,
        'goals':{'auxiliary':aux,'physical':phys},
        'residuals':[gap(o,r,l) for l in ls for o,r in zip(os,rs)]+[ls[0][1]-3,ls[1][1]-12],
        'guard':bool(a<b and min(side_margins)>0 and all(-mp.pi<t<mp.pi for t in (d,e,f,g))),
        'guard_margins':side_margins+[b-a],
        'construction_margins':[ls[0][2],ls[1][2]]}


def roots(ident,mirror=False):
    if ident==GEN:return (2*mp.sqrt(5),mp.sqrt(5))
    if ident==GUTS:return (mp.mpf(1)/3,mp.mpf(1)/4,mp.mpf(2)/5)
    if ident==CEMC:
        l=mp.atan2(1,-2*mp.sqrt(2));r=mp.atan2(1,2*mp.sqrt(2));return (l,l,r,r)
    if ident==CEMC26:return (mp.mpf(2),2*mp.sqrt(2))
    if ident==H25:
        q=mp.sqrt(19);a=(-25*q-200)/27;b=(-25*q+200)/27
        alpha=-mp.asin(mp.mpf(9)/10);beta=-alpha
        if mirror:a,b=-b,-a;alpha=-mp.pi-alpha;beta=mp.pi-beta
        return (a,b,alpha,alpha,beta,beta)
    if ident==G25:return (mp.mpf(16)/7,)
    if ident==UK25:return (mp.mpf(2),mp.mpf(2),4+2*mp.sqrt(2))
    if ident==PARA:return (mp.mpf(1),mp.mpf(2))
    raise ValueError(ident)


def chart(ident,w,mirror=False):
    root=roots(ident,mirror)
    if ident==GEN:
        h=w[0];u=mp.sqrt(h*h-25+10*mp.sqrt(9-h*h));return (2*u,u-h)
    if ident in (GUTS,CEMC,G25,UK25):return tuple(a+b for a,b in zip(root,w))
    if ident==CEMC26:
        x=2+w[0];return (x,mp.sqrt(9-(x-1)**2))
    if ident==H25:
        angles=tuple(a+b for a,b in zip(root[2:],w))
        def others(a,b):
            z=h25_geometry((a,b,*angles));return tuple(z['residuals'][-2:])
        a,b=mp.findroot(others,root[:2],tol=mp.eps*1024,maxsteps=30)
        return (a,b,*angles)
    if ident==PARA:
        t=1+w[0];return (t,1+1/t)
    raise ValueError(ident)


def evaluate(ident,values):
    if ident in (GEN,GUTS,CEMC):
        z=constructed_to_physical(ident,values)
        if ident==GEN:
            u,v,r=z['original_coordinates'];rs=[r-abs(5-v),2*r-6]
            goals={'physical':z['physical_goal'],'auxiliary':z['auxiliary_goal']}
            margins=[z['constructed_segment_margin'],z['original_segment_margin'],z['circle_construction_margin']]
        elif ident==GUTS:
            O,R=z['center'],z['radius'];rs=[gap(O,R,line(a,b)) for a,b in cuts()]
            goals={'physical':R};margins=z['constructed_segment_margins']+z['original_segment_margins']+[z['circle_construction_margin']]
        else:
            rs=[gap(O,R,L) for L in (z['left_line'],z['right_line']) for O,R in (((0,0),4),((0,3),3))]
            goals={'physical':z['physical_goal']};margins=z['segment_margins']+[z['line_pair_margin'],z['bottom_intersection_margin']]
        return {**z,'goals':goals,'residuals':rs,'guard':min(margins)>0,'guard_margins':margins}
    if ident==CEMC26:
        x,y=values;A=(mp.mpf(2),mp.mpf(0));B=(-mp.mpf(2),mp.mpf(0));C=(x,y)
        v=sub(C,B);t=4*(x+2)/dot(v,v);U=add(B,mul(v,t));V=mul(U,-1)
        rs=[gap((0,0),2,line(A,C)),norm(sub(B,U))-2*norm(sub(U,C))]
        margins=[y,norm(C)-2,t,1-t,norm(sub(A,C))]
        return {'original_coordinates':tuple(values),'goals':{'physical':polygon((C,U,V))},'residuals':rs,
            'guard':min(margins)>0,'guard_margins':margins}
    if ident==H25:return h25_geometry(values)
    if ident==G25:
        d=values[0];O=(-(7+d)/2,mp.mpf(4));R=mp.sqrt((7-d)**2+64)/2
        return {'original_coordinates':tuple(values),'goals':{'physical':d},'residuals':[R-abs(O[0])],
            'guard':d>0,'guard_margins':[d]}
    if ident==UK25:
        x,y,z=values;margins=[x,y,z-x,z-y,z-x-y]
        return {'original_coordinates':tuple(values),'goals':{'physical':z},
            'residuals':[x-2,y-2,(z-x-y)/mp.sqrt(2)-2],'guard':min(margins)>0,'guard_margins':margins}
    if ident==PARA:
        t,lam=values;rs=[t*(1-lam)+1,t*t/2+lam-mp.mpf('2.5')]
        margins=[t-mp.mpf('.5'),mp.mpf('1.5')-t,lam-1,3-lam]
        return {'original_coordinates':tuple(values),'goals':{'physical':(t*t+1)/2},
            'residuals':rs,'guard':min(margins)>0,'guard_margins':margins}
    raise ValueError(ident)


def lifts(ident,physical):
    if ident!=H25:return all_lifts(ident,physical)
    a,b,alpha,beta=physical;os=[(a,mp.mpf(5)),(b,mp.mpf(5))];rs=[mp.sqrt(a*a+25),mp.sqrt(b*b+25)]
    sets=[];receipts=[]
    for angle,p in ((alpha,3),(beta,12)):
        n=(mp.cos(angle),mp.sin(angle));v=(-n[1],n[0]);start=mul(n,p)
        for o,r in zip(os,rs):
            ps,receipt=intersections(o,r,start,add(start,v));receipts.append(receipt)
            sets.append([{'angle':mp.atan2(z['point'][1]-o[1],z['point'][0]-o[0]),'sign':z['sheet_sign']} for z in ps])
    import itertools
    sheets=[{'values':(a,b,*[p['angle'] for p in row]),'sheet':tuple(p['sign'] for p in row),
        'segment_feasible':True} for row in itertools.product(*sets)]
    return {'status':'real_lifts' if sheets else 'no_real_lift','sheets':sheets,'receipts':receipts,
        'note':'No source segment restriction for this quadrilateral. Original offsets exactly 3/12 required.'}


def directions(n):
    rows=[]
    for j in range(n):
        for sign in (-1,1):rows.append((f'axis{j}_{sign}',tuple(mp.mpf(sign if i==j else 0) for i in range(n)),'axis',j))
    if n>1:
        integers=list(range(1,n+1));length=mp.sqrt(sum(v*v for v in integers))
        for sign in (-1,1):rows.append((f'principal_{sign}',tuple(sign*v/length for v in integers),'mixed',None))
        rng=random.Random(260911);integers=[rng.randint(-5,5) for _ in range(n)]
        if not any(integers):integers[0]=1
        length=mp.sqrt(sum(v*v for v in integers));rows.append(('seed260911',tuple(v/length for v in integers),'mixed',None))
    return rows
