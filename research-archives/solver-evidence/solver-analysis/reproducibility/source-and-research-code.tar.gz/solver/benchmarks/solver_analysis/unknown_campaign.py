"""Run a fixed prospective source cohort and its separate finite-point pilot.

Heavy campaigns are sequential. Final execution requires the recorded audit3
decision. References remain absent from all solver and predictor inputs.
"""
import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]


def main(archive,split):
    intake=archive/'unknown-intake';forecast=intake/'individual-predictions-v1.json'
    f=json.loads(forecast.read_text());source_hash=ensure_source()
    assert f['source_hash']==source_hash
    cases=intake/'corpus-v1'/split/'cases.jsonl'
    dest=archive/'unknown-results'/split;dest.mkdir(parents=True,exist_ok=True)
    receipt=dest/'sequence.json'
    if receipt.exists():raise FileExistsError(receipt)
    prerequisite=(archive/'development/comparison-batch-v1/completion.json' if split=='mid'
                  else archive/'audits/03-adoption-decision.json')
    r={'status':'waiting','prerequisite':str(prerequisite),'forecast_sha256':hashlib.sha256(forecast.read_bytes()).hexdigest(),
       'source_hash':source_hash,'cases_sha256':hashlib.sha256(cases.read_bytes()).hexdigest(),'split':split,
       'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'completed':[]}
    receipt.write_text(json.dumps(r,indent=2)+'\n')
    while True:
        if prerequisite.exists():
            p=json.loads(prerequisite.read_text())
            if split=='mid' and p.get('status')=='complete':break
            if split=='final' and p.get('authorize_final_v1') is True:break
        time.sleep(10)
    # Read again at dispatch: no opportunity to change predictions silently.
    assert hashlib.sha256(forecast.read_bytes()).hexdigest()==r['forecast_sha256']
    commands=[[sys.executable,'-B',str(ROOT/'benchmarks/research_runner.py'),'run',str(dest/'global-3seed'),
        '--cases',str(cases),'--jobs','8','--seeds','0,1,2','--allow-dirty']]
    if split=='final':
        extra=intake/'final-extension-corpus-v1/cases.jsonl'
        commands.append([sys.executable,'-B',str(ROOT/'benchmarks/research_runner.py'),'run',str(dest/'extension-3seed'),
            '--cases',str(extra),'--jobs','8','--seeds','0,1,2','--allow-dirty'])
    groups=[]
    for row in (json.loads(v) for v in cases.read_text().splitlines()):
        path=cases.parent/row['dsl_path'];output=dest/'pilot-v3'/(row['id']+'.json')
        assert row['answer']==[]
        groups.append({'id':row['id'],'jobs':[{'command':[sys.executable,'-B',str(Path(__file__).with_name('contact_pilot.py')),
            str(path),str(output)],'process_timeout':90}]})
    if split=='final':
        for row in (json.loads(v) for v in extra.read_text().splitlines()):
            path=extra.parent/row['dsl_path'];output=dest/'pilot-v3'/(row['id']+'.json')
            assert row['answer']==[]
            groups.append({'id':row['id'],'jobs':[{'command':[sys.executable,'-B',str(Path(__file__).with_name('contact_pilot.py')),
                str(path),str(output)],'process_timeout':90}]})
    plan=dest/'pilot-plan.json';plan.write_text(json.dumps({'source_hash':source_hash,'jobs':8,'groups':groups,
        'forecast_sha256':r['forecast_sha256']},indent=2)+'\n')
    commands.append([sys.executable,'-B',str(Path(__file__).with_name('task_batch.py')),str(plan),str(dest/'pilot-batch')])
    for cmd in commands:
        if ensure_source()!=source_hash:raise ValueError('product changed')
        r.update(status='running',active_command=cmd);receipt.write_text(json.dumps(r,indent=2)+'\n')
        subprocess.run(cmd,cwd=ROOT,check=True);r['completed'].append(cmd)
    r.update(status='complete',source_hash_after=ensure_source());receipt.write_text(json.dumps(r,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('split',choices=['mid','final'])
    a=p.parse_args();main(a.archive,a.split)
