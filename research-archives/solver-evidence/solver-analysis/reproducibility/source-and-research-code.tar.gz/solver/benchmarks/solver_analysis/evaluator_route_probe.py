"""Record actual construction implementations, not similarly named legacy code."""
import json
import sys
from collections import Counter
from pathlib import Path
from mpmath import mp
from stage_replay import ensure_source
from geosolver.problem.models import GeometryProblem
from geosolver.engine.standard.problem.load_problem_bundle import load_problem_bundle
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode


def run():
    calls=Counter()
    def profiler(frame,event,arg):
        if event=='call' and 'circumcircle' in frame.f_code.co_name.lower():
            calls[(frame.f_code.co_filename,frame.f_code.co_name,mp.dps)]+=1
    dsl=json.loads(Path('benchmarks/dsl/JMO-2013-PRE-05.json').read_text())
    b=load_problem_bundle(GeometryProblem.model_validate(dsl).engine_document())
    e=build_ir_evaluator(b)
    values={'theta':'1.5','p':'3.3','q':'5.4'}
    sys.setprofile(profiler)
    try:
        with mp.workdps(100):
            f=e.evaluate_float_residual([float(values[v]) for v in b.var_names])
        with mp.workdps(100),high_precision_mode():
            h=e.evaluate_hp_residual([mp.mpf(values[v]) for v in b.var_names],precision=100)
            a=e.evaluate_answer_hp([mp.mpf(values[v]) for v in b.var_names],precision=100)
    finally:sys.setprofile(None)
    return {'source_hash':ensure_source(),'var_names':b.var_names,'calls':[
        {'file':k[0],'function':k[1],'dps':k[2],'count':v} for k,v in calls.items()],
        'float_status':f.evaluation_status.value,'hp_status':h.evaluation_status.value,
        'legacy_softcap_called':any('operations' in k[0] for k in calls),
        'answer':str(a)}

if __name__=='__main__':
    out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():raise FileExistsError(out)
    r=run();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
