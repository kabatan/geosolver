"""Verify reused historical report/provenance/raw seals without rerunning solvers."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def verify_seal(path):
    rows=[]
    for line in path.read_text().splitlines():
        if not line.strip():continue
        expected,name=line.split(maxsplit=1);name=name.lstrip('*')
        p=path.parent/name
        rows.append({'path':str(p),'expected':expected,'actual':digest(p) if p.exists() else None})
    return {'seal':str(path),'seal_sha256':digest(path),'files':len(rows),
            'matched':sum(r['expected']==r['actual'] for r in rows),'mismatches':[r for r in rows if r['expected']!=r['actual']]}


def main(base,out):
    if out.exists():raise FileExistsError(out)
    snapshot=base/'snapshot/benchmarks';local=base/'local';seals=[];provenance=[]
    report_dirs=[snapshot/'gmb_comparison/results'/s for s in ['solver-a1-20260901','solver-a1-official-goals-20260901']]
    for d in report_dirs:seals.append(verify_seal(d/'SHA256SUMS'))
    p=report_dirs[0]/'provenance.json';record=json.loads(p.read_text())
    for name,expected in record['artifact_sha256'].items():
        f=local/name;provenance.append({'path':str(f),'expected':expected,'actual':digest(f) if f.exists() else None})
    for relative in ['gmb-geosolver-imo36-solver-a1-20260901/RAW_SHA256SUMS',
                     'gmb-geosolver-imo36-solver-a1-20260901/assessment/SHA256SUMS',
                     'gmb-official-goals-solver-a1-20260901-validated/SHA256SUMS']:
        seals.append(verify_seal(local/'benchmarks/local-evaluation'/relative))
    review=snapshot/'solver-improvement-results-20260907/review.json'
    items=json.loads(review.read_text())['items']
    mapping={
        'F01':'scalar/deadline','F02':'construction evaluation/cache','F03':'precision/rank chart','F04':'candidate identity',
        'F05':'scalar deduplication','F06':'boundary sampling','F07':'scalar bracket/candidate diversity','F08':'residual/score arithmetic',
        'F09':'domain-aware derivative','F10':'rank scaling','F11':'measurement','F12':'scalar search','F13':'bounds',
        'F14':'candidate selection/score','F15':'optimizer','F16':'invalid domain','F17':'candidate selection',
        'F18':'budget/resume','F19':'ledger/resume','F20':'verification/boundary','F21':'intermediate retention',
        'F22':'discrete enumeration','F23':'finalization budget','F24':'guard precision','F25':'Jacobian/cache/closure order',
        'F26':'derivative sparsity','F27':'verification cache','F28':'value identification','F29':'precision guard overhead',
        'F30':'batch/cache','F31':'serialization','F32':'arithmetic backend','F33':'arithmetic backend','F34':'measurement'}
    for name,v in items.items():v['pipeline_role']=mapping[name]
    out.mkdir(parents=True)
    result={'mode':'read-only historical integrity and hypothesis index; not new causal evidence',
        'seals':seals,'provenance_files':provenance,'engine_identity':record['engine_identity'],
        'baseline_tag':record['solver_tag'],'baseline_commit':record['solver_commit'],
        'historical_review_path':str(review),'historical_review_sha256':digest(review),'items':items,
        'mismatch_count':sum(len(s['mismatches']) for s in seals)+sum(r['expected']!=r['actual'] for r in provenance),
        'comparison_limits':[
            'September7 full 323x3 comparison used 16 parallel runs; current measurement uses 8. Do not compare wall time directly across those campaigns.',
            'GMB 36x3 is K1 placement recovery, not exhaustive target-value recovery or all 39 paper inputs.',
            'The official-goal comparison uses all 96 input goal evaluations as the unconditional denominator; emitted/evaluated subsets are separate.',
            'Representation and backend both differ in the GMB historical comparison.',
            'F08 changes residual norm/score arithmetic. Rank preservation does not imply NOMAD surrogate/trajectory preservation; a rounding-only cause remains unproved.']}
    (out/'integrity-and-history.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    table=['# 旧実験の変更・判断・現行パイプライン対応','',
           '旧報告の採否と理由を保持した仮説形成用索引。各変更の因果効果はこの表だけで独立に再証明したものではない。','',
           '| ID | 段階 | 採否 | 変更・観測 |','|---|---|---|---|']
    for ident,v in items.items():
        reason=v.get('final_reason',v.get('change',v.get('reason',''))).replace('|','/').replace('\n',' ')
        table.append(f'| {ident} | {v["pipeline_role"]} | {v["final_decision"]} | {reason} |')
    table += ['',f'再利用ファイルのsealは計{sum(s["files"] for s in seals)}件、provenanceの個別照合は{len(provenance)}件。不一致{result["mismatch_count"]}件。詳細は integrity-and-history.json。']
    (out/'changes-and-decisions.md').write_text('\n'.join(table)+'\n')
    print(json.dumps({'seals':[{k:v for k,v in r.items() if k!='mismatches'} for r in seals],
                      'mismatch_count':result['mismatch_count'],'changes':len(items)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('base',type=Path);p.add_argument('output',type=Path);a=p.parse_args();main(a.base,a.output)
