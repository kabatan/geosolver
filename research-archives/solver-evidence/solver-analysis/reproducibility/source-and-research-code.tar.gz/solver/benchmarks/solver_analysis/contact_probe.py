"""Analytic development probes for incidence-induced tangency multiplicity.

This program evaluates explicit geometry, not the product search algorithm.
It deliberately separates reference geometry from any solver-facing input.
The report must distinguish these algebraic probes from causal solver runs.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from mpmath import mp


def geometry(theta,p,q):
    c,s=mp.cos(theta),mp.sin(theta)
    u1=(p*p+2*q)/(2*p)
    v1=((q+2)/2-u1*c)/s
    a1=u1-p
    radius1=mp.sqrt(a1*a1+v1*v1)
    u2=(p+9)/2
    along2=(q*q+9*p)/(2*q)
    v2=(along2-u2*c)/s
    normal2=-u2*s+v2*c
    a2=along2-q
    radius2=mp.sqrt(a2*a2+normal2*normal2)
    return {'gap1':abs(radius1-abs(v1)),'gap2':abs(radius2-abs(normal2)),
            'stable1':a1*a1/(radius1+abs(v1)),
            'stable2':a2*a2/(radius2+abs(normal2)),
            'projection1':a1,'projection2':a2,
            'goal':radius1/radius2,'radius1':radius1,
            'normal1':v1,'normal2':normal2}


def run(destination):
    if destination.exists() and any(destination.iterdir()):raise FileExistsError(destination)
    destination.mkdir(parents=True,exist_ok=True)
    rows=[]
    with mp.workdps(1100):
        p0=mp.root(36,3);q0=mp.root(162,3);goal0=mp.root(mp.mpf(2)/9,3)
        # Compact interior slices plus approaching-degeneracy controls.
        angles=[('interior_halfpi',mp.pi/2),('interior_thirdpi',mp.pi/3),
                ('small_angle',mp.mpf('1e-4')),('near_pi',mp.pi-mp.mpf('1e-4'))]
        truth={name:geometry(theta,p0,q0) for name,theta in angles}
        for name,theta in angles:
            for direction in ('p','q','theta'):
                for exponent in (2,4,8,12,20,30,40,60,80,120,160):
                    delta=mp.power(10,-exponent)
                    point=(theta+delta*(direction=='theta'),p0+delta*(direction=='p'),q0+delta*(direction=='q'))
                    high=geometry(*point)
                    for precision in (50,100,200,400):
                        with mp.workdps(precision):
                            observed=geometry(*point)
                        row={'theta_class':name,'direction':direction,'perturbation_digits':exponent,
                             'working_dps':precision,'goal_error':mp.nstr(high['goal']-goal0,25),
                             'radius1_error':mp.nstr(high['radius1']-truth[name]['radius1'],25),
                             'true_gap_norm':mp.nstr(mp.sqrt(high['gap1']**2+high['gap2']**2),25)}
                        row.update({k:mp.nstr(v,25) for k,v in observed.items()})
                        rows.append(row)
    with (destination/'precision-contact.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # Scalar normal form predicts the fixed positive damping floor's regime.
    with mp.workdps(200):
        newton=[]
        for multiplicity in (1,2,4):
            for damping in ('0','1e-12'):
                x=mp.mpf('1e-5');lam=mp.mpf(damping)
                for iteration in range(161):
                    if iteration in (0,1,2,4,8,16,32,64,80,160):
                        newton.append({'multiplicity':multiplicity,'damping':damping,
                                       'iteration':iteration,'error':mp.nstr(abs(x),35),
                                       'residual':mp.nstr(abs(x)**multiplicity,35)})
                    if x==0:continue
                    f=x**multiplicity;j=multiplicity*x**(multiplicity-1)
                    x-=j*f/(j*j+lam)
    (destination/'normal-form-iterations.json').write_text(json.dumps(newton,indent=2)+'\n')
    receipt={'status':'development analytic probe; not an unknown prediction',
             'rows':len(rows),'reference_dps':1100,'coordinate_construction':'exact symbolic roots approximated at 1100 dps, reused without input rounding',
             'directions':'p,q are transverse; theta is a genuine solution-manifold coordinate',
             'negative_control':'Radius(C1) varies along theta while Radius(C1)/Radius(C2) is constant.',
             'interpretation_limit':'Normal-form damping is illustrative until actual refiner iterates and damping are recorded. No global convergence or required precision guarantee follows from one directional curve.'}
    (destination/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);run(p.parse_args().destination)
