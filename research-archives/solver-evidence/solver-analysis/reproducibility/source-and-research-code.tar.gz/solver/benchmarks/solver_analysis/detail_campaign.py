"""Run the prerequired detailed cohort after the active paired campaign ends.

Heavy campaigns are sequential. Existing destinations are never overwritten.
Seeds 0..4 come from the completed full baseline; this adds 5..29 and a separate
repeat of seeds 0 and 1. Research-only files may be dirty; product hashes remain
those of the fixed baseline and are recorded independently before and after.
"""
import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]


def main(archive):
    cohort_path=archive/'analysis/baseline-v1/cohort.json'
    cohort=json.loads(cohort_path.read_text())
    wait_for=archive/'development/stage-campaign-v2/completion.json'
    directory=archive/'campaigns/detail-30seed-20260911'
    repeat=archive/'campaigns/detail-repeat01-20260911'
    receipt=archive/'campaigns/detail-sequence-receipt.json'
    if directory.exists() or repeat.exists() or receipt.exists():raise FileExistsError('detail campaign already exists')
    before=ensure_source()
    frozen={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [ROOT/'uv.lock',ROOT/'benchmarks/cases.jsonl',*sorted((ROOT/'benchmarks/dsl').glob('*.json'))]}
    note={'status':'waiting_for_paired_campaign','source_hash':before,'input_hashes':frozen,
        'cohort_sha256':hashlib.sha256(cohort_path.read_bytes()).hexdigest(),'cohort':cohort['cases'],
        'reuse_base_campaign':str(archive/'campaigns/baseline-5seed-20260911'),
        'new_seeds':list(range(5,30)),'repeat_seeds':[0,1],'jobs':8,
        'allow_dirty_reason':'Only research harness files are untracked; product source, corpus and dependency lock are checked separately.',
        'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    receipt.write_text(json.dumps(note,indent=2)+'\n')
    while not wait_for.exists():time.sleep(10)
    completed=json.loads(wait_for.read_text())
    if completed['completed']!=completed['planned']:raise ValueError('incomplete prerequisite')
    if ensure_source()!=before:raise ValueError('product changed while waiting')
    script=ROOT/'benchmarks/research_runner.py'
    for dest,seeds in ((directory,list(range(5,30))),(repeat,[0,1])):
        for name,h in frozen.items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h:raise ValueError('input or dependency changed: '+name)
        note.update(status='running',active_destination=str(dest),active_seeds=seeds)
        receipt.write_text(json.dumps(note,indent=2)+'\n')
        cmd=[sys.executable,'-B',str(script),'run',str(dest),'--jobs','8','--seeds',','.join(map(str,seeds)),'--allow-dirty']
        for ident in cohort['cases']:cmd.extend(['--case-id',ident])
        subprocess.run(cmd,cwd=ROOT,check=True)
        for operation in ('assess','summarize'):
            subprocess.run([sys.executable,'-B',str(script),operation,str(dest)],cwd=ROOT,check=True)
        note.setdefault('completed_destinations',[]).append(str(dest))
    note.update(status='complete',source_hash_after=ensure_source())
    receipt.write_text(json.dumps(note,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);main(p.parse_args().archive)
