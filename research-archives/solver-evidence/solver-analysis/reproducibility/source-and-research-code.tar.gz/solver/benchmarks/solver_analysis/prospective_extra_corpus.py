"""Prepare the frozen final extension and independent references separately."""
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s


def build(archive):
    intake=archive/'unknown-intake';dest=intake/'final-extension-corpus-v1'
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir();(dest/'dsl').mkdir();rows=[];references=[]
    values={'CEMC-EUCLID-2026-08A':['4*sqrt(2)/3'],'HMMT-NOV-2025-GUTS-12':['16/7'],
        'UKMT-SMC-2025-16':['4+2*sqrt(2)'],'HMMT-NOV-2025-GEN-08':['200'],
        'GENERATED-PARABOLA-NORMAL-FOLD':['1'],
        'GENERATED-PARABOLA-NORMAL-SPLIT':['CRootOf(20000*x**3-90400*x**2+121002*x-50401,0)',
                                          'CRootOf(20000*x**3-90400*x**2+121002*x-50401,1)'],
        'GENERATED-PARABOLA-NORMAL-NO_ROOT':[]}
    paths=list((intake/'enriched-v2/dsl').glob('*.json'))+[
        intake/'parabola-transfer-v1'/(name+'_original.json') for name in ('fold','split','no_root')]
    t=s.symbols('t');cert=[]
    for epsilon in (s.Rational(0),s.Rational(1,100),-s.Rational(1,100)):
        p=s.Poly(t**3-(3+2*epsilon)*t+2,t)
        count=p.count_roots(s.Rational(1,2),s.Rational(3,2))
        assert count=={s.Rational(0):1,s.Rational(1,100):2,-s.Rational(1,100):0}[epsilon]
        cert.append({'height_perturbation':str(epsilon),'eliminated_polynomial':str(p.as_expr()),
            'distinct_roots_in_guard_by_sturm':int(count),'rational_isolations':str(p.intervals(eps=s.Rational(1,10**12)))})
    for p in paths:
        d=json.loads(p.read_text());ident=d['id'];q=dest/'dsl'/(ident+'.json');q.write_bytes(p.read_bytes())
        row={'id':ident,'dsl_path':'dsl/'+q.name,'dsl':d,'answer':[],'truth_status':'unverified',
            'authoring_status':'runnable','dedupe_key':'GENERATED-PARABOLA-NORMAL' if ident.startswith('GENERATED') else ident,
            'source':'post-freeze generated normal-map transfer' if ident.startswith('GENERATED') else 'official source question; enriched selection-v2',
            'source_family':'parabola_normal_fold' if ident.startswith('GENERATED') else ident.rsplit('-',1)[0]}
        rows.append(row)
        references.append({**row,'dsl_path':str(q),'answer':values[ident],'truth_status':'verified',
            'reference_provenance':'input-only analytic elimination, exact root-count and source guards; no solver output',
            'expected_no_feasible_configuration':ident.endswith('NO_ROOT')})
    (dest/'cases.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    ref=archive/'unknown-references/final-extension-v1';ref.mkdir()
    (ref/'assessment-cases.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in references))
    result={'source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'forecast_sha256':hashlib.sha256((intake/'individual-predictions-v1.json').read_bytes()).hexdigest(),
        'parabola_root_count_certificates':cert,'natural_sources':4,'generated_instances':3,'generated_structural_families':1,
        'complete_natural_reference_derivations':{
            'CEMC-EUCLID-2026-08A':'Tangency at A forces x=2; B-U-C ratio gives y^2=8; y>0. Area=2y/3.',
            'HMMT-NOV-2025-GUTS-12':'Squared radius minus centre-to-BC distance squared=16-7d. Positive d gives16/7.',
            'UKMT-SMC-2025-16':'Interior-triangle distance equations give x=y=2,s=x+y+2sqrt(2).',
            'HMMT-NOV-2025-GEN-08':'For two distinct centres on y=5, the same two x-coordinates solve each common-tangent equation. Their normal x-components must agree. Distances3 and12 force normal y-components∓9/10, with x-components±sqrt(19)/10. Each choice gives the explicit two-centre roots in exact-jets.json. The reflected solutions have identical area200.'},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ref/'derivations.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':len(rows),'roots':cert}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);build(p.parse_args().archive)
