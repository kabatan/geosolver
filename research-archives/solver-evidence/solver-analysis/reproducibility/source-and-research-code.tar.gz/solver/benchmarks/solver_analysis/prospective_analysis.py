"""Assess frozen local runs without feeding outcome information into solving.

The first saved point and final pre-verifier point retain their own coordinates.
Independent physical equations, the production equation sampler, and a separate
coordinate-correcting verifier have separate fields. All planned jobs, including
missing outputs and failures, remain in the denominator.
"""
import argparse
import hashlib
import json
import statistics
import time
from collections import Counter,defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import dumps,loads
from prospective_geometry import *
from physical_evaluation import evaluate_physical
from paired_stages import bundle_of
from stationary_check import check
from lm_event_analysis import weighted_metrics
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.evaluation.final_verifier import verify_final_candidate
from geosolver.runtime.deadline import runtime_session


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def number(x):return mp.nstr(x,40) if x is not None else None
def digits(error):return float(min(280,-mp.log10(max(abs(error),mp.mpf('1e-280')))))


def independent(ident,x,coordinate_kind,mirror=False):
    x=tuple(x)
    if coordinate_kind=='reduced':x=(x[0],1+1/x[0])
    z=evaluate_physical(ident,x) if coordinate_kind=='physical' else evaluate(ident,x)
    root=evaluate(ident,roots(ident,mirror))
    # Physical and auxiliary observables are intentionally evaluated at one
    # trajectory; no extra optimization or hidden target-dependent selection.
    goals={k:{'value':v,'root':root['goals'][k],
        'relative_error':abs(v-root['goals'][k])/max(1,abs(root['goals'][k]))}
        for k,v in z['goals'].items()}
    for v in goals.values():v.update(digits=digits(v['relative_error']),twenty_digits=v['relative_error']<=mp.mpf('1e-20'))
    scale=max([mp.mpf(1)]+[abs(v) for v in z['original_coordinates']])
    # Diagnostic normalization only, not an existence certificate or a
    # replacement for the input equation sampler's term scales.
    fraction=mp.norm(z['residuals'])/scale
    other=[]
    if coordinate_kind!='physical':
        if ident==GEN:other=z['residuals'][1:]
        if ident==H25:other=z['residuals'][-2:]
        if ident==CEMC26:other=z['residuals'][1:]
        if ident==PARA:other=z['residuals'][:1]
    return {'geometry':z,'goals':goals,'normalized_independent_gap':fraction,
        'independent_numeric_conditions':bool(z['guard'] and fraction<=mp.mpf('1e-20')),
        'other_equation_error_eta':mp.norm(other) if other else None,
        'meaning':'numeric pointwise check, no exact-solution existence claim'}


def steps_of(r,ident,coordinate_kind,mirror):
    output=[];pending=None
    for event in r['trace']:
        if event['kind']=='lm_step':
            pending=event
        elif event['kind']=='line_search':
            row={'index':len(output),'dps':event['input']['dps'],
                'point':event['input']['point'],'step':event['input']['step'],
                'start_residual':event['input']['current_norm']}
            if pending:
                data=pending['input'];J=mp.matrix(data['jacobian']);lam=data['damping']
                with mp.workdps(max(80,r['dps']+30)):
                    singular=list(mp.svd(J,compute_uv=False));nonzero=[s for s in singular if s>0]
                    row.update(damping=lam,singular_values=singular,
                        lambda_over_sigma_max_squared=lam/nonzero[0]**2 if nonzero else None,
                        lambda_over_sigma_min_squared=lam/nonzero[-1]**2 if nonzero else None,
                        positive_singular_condition=nonzero[0]/nonzero[-1] if nonzero else None,
                        condition_caveat='No mathematical rank inferred; tiny positive finite-difference values are retained.')
                    row.update(weighted_metrics(data,event['input']['step']))
            if 'output' in event:
                point,residual,improved=event['output']
                row.update(accepted=improved,end_residual=mp.norm(residual) if residual is not None else None,
                    accepted_point=point if improved else event['input']['point'])
                if improved and residual is not None:
                    row['relative_residual_improvement']=(row['start_residual']-mp.norm(residual))/max(abs(row['start_residual']),mp.mpf('1e-300'))
                    row['product_residual_improvement']=(row['start_residual']-mp.norm(residual))/max(abs(row['start_residual']),mp.mpf('1e-30'))
                    if 'linearized_product_improvement' in row:
                        row['nonlinear_or_linesearch_improvement_difference']=row['product_residual_improvement']-row['linearized_product_improvement']
                try:row['independent']=independent(ident,row['accepted_point'],coordinate_kind,mirror)
                except Exception as ex:row['independent_error']=type(ex).__name__+': '+str(ex)
            else:row['interrupted']=True
            output.append(row);pending=None
    if pending:output.append({'index':len(output),'interrupted_lm_before_line_search':True,'lm':pending})
    return output


def analyze(archive,split,out,verify_representatives=True):
    if out.exists():raise FileExistsError(out)
    local=archive/'unknown-local-v1';plan=loads((local/(split+'-plan.json')).read_text())
    manifest=loads((local/'manifest.json').read_text());cases={r['case_id']:r for r in manifest['cases']}
    receipt=local/(split+'-batch/completion.json')
    state=json.loads(receipt.read_text())
    if state.get('status')!='complete':raise ValueError('Local jobs still running')
    out.mkdir(parents=True);rows=[];verifications=[];begun=time.monotonic()
    expected=[(g['id'],j) for g in plan['groups'] for j in g['jobs']]
    for group,job in expected:
        cmd=job['command'];p=Path(cmd[8]);ident=group.split('__')[0];meta=cases[ident]
        name=p.stem.split('__');matched=p.parent.name=='matched-runs'
        variant=name[2];kind='physical' if matched and len(name)==4 else ('reduced' if variant.startswith('reduced') else 'constructed')
        row={'case_id':ident,'group':group,'file':str(p),'matched_physical':matched,
            'variant':variant,'coordinate_kind':kind,'planned_iterations':int(cmd[cmd.index('--iterations')+1]),
            'dps':int(cmd[cmd.index('--dps')+1]),'start_index':int(name[1].replace('physical','').replace('start','')),
            'lift':int(name[3][4:]) if matched and len(name)>4 else None,'available':p.exists()}
        if not p.exists():row['failure']='missing raw output';rows.append(row);continue
        try:
            r=loads(p.read_text());x=tuple(r['pre_verifier_point']);mirror=r['point'].get('branch_mirror',False)
            if ident==H25 and matched:mirror=row['start_index']>=4
            row.update(raw_sha256=sha(p),status=r['status'],error=r['error'],numeric_seconds=r['numeric_seconds'],
                calls=r['numeric_calls'],censored=r['safety_deadline_hit'],point_uid=r['point']['uid'],
                pre_verifier_point=x,initial_point=r['point']['x'],iteration_cap=r['iteration_or_actual_float_call_cap'])
            with mp.workdps(max(280,r['dps']+60)):
                for label,point in [('initial',r['point']['x']),('final',x)]:
                    try:row[label]=independent(ident,point,kind,mirror)
                    except Exception as ex:row[label]={'error':type(ex).__name__+': '+str(ex)}
                evaluator=build_ir_evaluator(bundle_of(r['original_dsl']))
                row['stationary_original']=check(evaluator,x,precision=max(120,r['dps']+30))
                trace=steps_of(r,ident,kind,mirror)
                tp=out/'trajectories'/p.name;tp.parent.mkdir(exist_ok=True)
                tp.write_text(dumps({'source':str(p),'source_sha256':row['raw_sha256'],'steps':trace})+'\n')
                row.update(trace_file=str(tp),lm_steps=len([t for t in r['trace'] if t['kind']=='lm_step']),
                    accepted_steps=sum(bool(t.get('accepted')) for t in trace),
                    final_damping=next((t.get('damping') for t in reversed(trace) if 'damping' in t),None))
                # A single fixed start per residual arm/case at100dps. This is
                # separate and cannot retroactively replace the final point.
                if verify_representatives and not matched and row['start_index']==0 and r['dps']==100:
                    v={'source':str(p),'input_revision':'pre_verifier','input_point':x,
                       'selection':'first preregistered local start, each arm,100dps','safety_seconds':10}
                    started=time.monotonic()
                    try:
                        with runtime_session(started+10):v['result']=verify_final_candidate(evaluator=evaluator,values=list(x))
                    except Exception as ex:v['error']=type(ex).__name__+': '+str(ex)
                    v['seconds']=time.monotonic()-started;verifications.append(v)
            rows.append(row)
        except Exception as ex:row['analysis_error']=type(ex).__name__+': '+str(ex);rows.append(row)
    (out/'runs.jsonl').write_text(''.join(dumps(r)+'\n' for r in rows))
    (out/'separate-verifier.json').write_text(dumps(verifications)+'\n')
    pairs=[]
    for row in rows:
        if row['matched_physical'] or row['variant']=='original':continue
        base=next((v for v in rows if v['group']==row['group'] and v['dps']==row['dps'] and v['variant']=='original'),None)
        pair={'case_id':row['case_id'],'group':row['group'],'dps':row['dps'],'variant':row['variant'],
            'baseline_file':base['file'] if base else None,'intervention_file':row['file']}
        for goal in ('physical','auxiliary'):
            a=(base or {}).get('final',{}).get('goals',{}).get(goal);b=row.get('final',{}).get('goals',{}).get(goal)
            pair[goal]={'baseline_digits':a['digits'],'intervention_digits':b['digits'],'gain':b['digits']-a['digits'],
                'baseline20':a['twenty_digits'],'intervention20':b['twenty_digits']} if a and b else {'not_comparable':True}
        pairs.append(pair)
    (out/'local-pairs.jsonl').write_text(''.join(dumps(r)+'\n' for r in pairs))
    clusters=[]
    for group in sorted({r['group'] for r in rows if r['matched_physical']}):
        rr=[r for r in rows if r['group']==group]
        for variant in sorted({r['variant'] for r in rr}):
            # The physical original and constructed original are distinct arms.
            for coordinate in sorted({r['coordinate_kind'] for r in rr if r['variant']==variant}):
                arm=[r for r in rr if r['variant']==variant and r['coordinate_kind']==coordinate]
                successful=[r for r in arm if r.get('final',{}).get('independent_numeric_conditions') and
                    r.get('final',{}).get('goals',{}).get('physical',{}).get('twenty_digits')]
                clusters.append({'group':group,'case_id':arm[0]['case_id'],'variant':variant,'coordinate_kind':coordinate,
                    'planned_starts':len(arm),'available':sum(r['available'] for r in arm),
                    'planned_total_iterations':sum(r['planned_iterations'] for r in arm),
                    'numeric_seconds':sum(r.get('numeric_seconds',0) for r in arm),
                    'censored':sum(r.get('censored',False) for r in arm),'successful_physical_cluster':bool(successful),
                    'physical20_count':len(successful),'all_files':[r['file'] for r in arm]})
    (out/'matched-clusters.jsonl').write_text(''.join(dumps(r)+'\n' for r in clusters))
    aggregate=[]
    for ident in sorted({r['case_id'] for r in rows}):
        for variant,dps in sorted({(r['variant'],r['dps']) for r in rows if r['case_id']==ident and not r['matched_physical']}):
            rr=[r for r in rows if r['case_id']==ident and r['variant']==variant and r['dps']==dps and not r['matched_physical']]
            aggregate.append({'case_id':ident,'variant':variant,'dps':dps,'planned':len(rr),'available':sum(r['available'] for r in rr),
                'statuses':dict(Counter(str(r.get('status','missing')) for r in rr)),
                'stationary_original_passed':sum(r.get('stationary_original',{}).get('numeric_conditions_passed',False) for r in rr),
                'independent_numeric_passed':sum(r.get('final',{}).get('independent_numeric_conditions',False) for r in rr),
                'goals':{goal:{'measured':len(vv),'median_digits':statistics.median(vv) if vv else None,
                    'twenty_digits':sum(v>=20 for v in vv)} for goal in ('physical','auxiliary')
                    for vv in [[r['final']['goals'][goal]['digits'] for r in rr if goal in r.get('final',{}).get('goals',{})]]}})
    summary={'split':split,'planned':len(expected),'rows':len(rows),'available':sum(r['available'] for r in rows),
        'analysis_errors':sum('analysis_error' in r for r in rows),'groups':aggregate,
        'plan_sha256':sha(local/(split+'-plan.json')),'forecast_sha256':manifest['forecast_sha256'],
        'script_sha256':sha(Path(__file__)),'seconds':time.monotonic()-begun,
        'observational_limit':'Root-centred diagnostic starts; neither global initialization quality nor full-pipeline exact identification is scored here.',
        'reporting_threshold':'20 relative goal digits and 1e-20 numeric equation scale, fixed in this analyzer before mid outcomes.',
        'cluster_note':'Seeds, physical sheets, and residual arms are paired observations, not additional independent problems.'}
    (out/'summary.json').write_text(dumps(summary)+'\n');print(json.dumps({k:summary[k] for k in ('split','planned','rows','available','analysis_errors','seconds')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('split',choices=['mid','final']);p.add_argument('output',type=Path)
    p.add_argument('--no-verify',action='store_true');a=p.parse_args();analyze(a.archive,a.split,a.output,not a.no_verify)
