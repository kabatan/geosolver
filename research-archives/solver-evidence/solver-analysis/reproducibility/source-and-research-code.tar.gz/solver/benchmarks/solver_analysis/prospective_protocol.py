"""Freeze individual claims and budgets before unknown solver outcomes.

This file reads authored input and mathematical proof receipts only. Predictions
about roots are explicitly manual analytic certificates, not pilot labels.
"""
import argparse
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
from contact_detector import detect
from stage_replay import ensure_source


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def freeze(intake,destination):
    if destination.exists():raise FileExistsError(destination)
    rules=intake/'local-prediction-protocol-v1.freeze.json';assert rules.exists()
    rows=[]
    for split in ('mid','final'):
        for line in (intake/'corpus-v1'/split/'cases.jsonl').read_text().splitlines():
            r=json.loads(line);d=r['dsl'];detection=detect(d)
            assert not detection['positive']
            rows.append({'case_id':r['id'],'split':split,'variables':len(d['variables']),
                'source':r['source'],'family':r['source_family'],'input_detection':detection,
                'input_prediction':'abstain: no certified contact factor in the authored input',
                'root_order_from_pilot':'abstain: finite point gradients cannot certify q at a root',
                'global_success_prediction':'abstain; theory has no full-pipeline success classifier',
                'dsl_sha256':sha(intake/'corpus-v1'/split/r['dsl_path'])})
    local=[
        {'case_id':'HMMT-NOV-2023-GEN-06','split':'mid','status':'designed before rule freeze; case prospective only',
         'representations':'representations-v2','root':'u=sqrt(5),v=2,R=3,x=2sqrt(5),t=sqrt(5)',
         'chart':'h; u^2=h^2-25+10sqrt(9-h^2), v=(25-u^2+h^2)/10, x=2u,t=u-h',
         'm':2,'goal_orders':{'auxiliary':1,'physical':2},'directional_orders':{'h':{'auxiliary':1,'physical':2}},
         'intervention_prediction':'signed residual removes quadratic contact; stable evaluation and resquaring preserve order2. At matched original-condition residual, physical goal requires about half as many coordinate digits as auxiliary goal.',
         'finite_prediction':'signed LM should improve auxiliary goal digits over original at common starts; physical-target gain may be smaller because q=2. No guaranteed full pipeline identification.',
         'caveat':'Other-condition error eta enters the physical error; do not score q2 on unconstrained full trajectories without eta.'},
        {'case_id':'HMMT-NOV-2023-GUTS-17','split':'final','status':'designed before rule freeze; case prospective only',
         'representations':'representations-v2','root':'O=(7,2sqrt(3)),R=3sqrt(3),t=(1/3,1/4,2/5)',
         'chart':'independent perturbations of the three cut-segment parameters',
         'm':2,'goal_orders':{'physical':2},'all_nonzero_direction_order':2,
         'proof':'inward contact normals sum to zero; radius error is exactly the average of three signed physical gaps. Quadratic weights are positive.',
         'intervention_prediction':'residual-coordinate mismatch is absent for radius order(q/m=1), although signed residual can still accelerate LM. Stable gap alone does not change the order.'},
        {'case_id':'CEMC-EUCLID-2024-08A','split':'final','status':'designed before rule freeze; case prospective only',
         'representations':'representations-v2','root':'d=e=atan2(1,-2sqrt(2)), f=g=atan2(1,2sqrt(2))',
         'chart':'independent perturbations of four circle-point angles',
         'm':2,'goal_orders':{'physical':2},'bound':'upper only on arbitrary directions',
         'directional_orders':{'d':{'physical':4},'e':{'physical':2},'f':{'physical':4},'g':{'physical':2}},
         'proof_receipt':str(intake/'cemc-line-area-jet-proof-v1.json'),
         'intervention_prediction':'signed residual linearizes contacts, but physical-area error has no square-root mismatch; two coordinate axes have even stronger q4 cancellation.'},
        {'case_id':'CEMC-EUCLID-2026-08A','split':'final_enriched','status':'natural selected after rule freeze',
         'representations':'enriched-v2','root':'x=2,y=2sqrt(2)',
         'chart':'x=2+w,y=sqrt(9-(x-1)^2); U=(2x-2,2y)/3, V=-U',
         'm':2,'goal_orders':{'physical':1},'directional_orders':{'w':{'physical':1}},
         'proof':'G=2y/3 gives dG/dw=-1/(3sqrt(2)); h=-2w/sqrt(w^2+y^2); the other equation is regular.',
         'intervention_prediction':'signed contact improves local LM goal accuracy at equal iterations; stable gap and square preserve quadratic order. This is an automatically detected positive in the bare authored input.'},
        {'case_id':'HMMT-NOV-2025-GUTS-12','split':'final_enriched','status':'natural regular negative control',
         'representations':'enriched-v2','root':'d=16/7','chart':'d=16/7+w','m':1,
         'goal_orders':{'physical':1},'directional_orders':{'w':{'physical':1}},
         'proof':'R^2-distance(center,BC)^2=16-7d and R+distance stays positive.',
         'intervention_prediction':'no quadratic contact plateau is predicted merely because IsTangent occurs; extra precision alone should not create the m2 behavior.'},
        {'case_id':'UKMT-SMC-2025-16','split':'final_enriched','status':'natural regular negative control',
         'representations':'enriched-v2','root':'x=y=2,s=4+2sqrt(2)','chart':'perturb x,y,s independently','m':1,
         'goal_orders':{'physical':1},'directional_orders':{'x':{'physical':None},'y':{'physical':None},'s':{'physical':1}},
         'proof':'On triangle interior branch the gap residuals are x-2,y-2,(s-x-y)/sqrt(2)-2, with nonsingular constant Jacobian; goal=s.',
         'intervention_prediction':'three tangencies are regular; no square-root residual-to-goal mismatch. Axes x,y preserve the target exactly and are recorded as cancellation controls.'},
        {'case_id':'HMMT-NOV-2025-GEN-08','split':'final_enriched','status':'natural new coupling; shares common-tangent motif',
         'representations':'enriched-v2 plus enriched-physical-v1',
         'root':'See exact-jets.json; include both mirrored physical branches.',
         'chart':'four circle-point angles; solve two line-distance equations for a,b by the local implicit function before measuring weak-direction order',
         'm':2,'goal_orders':{'auxiliary':1,'physical':2},'bound':'arbitrary-direction upper only',
         'directional_orders':{a:{'auxiliary':1,'physical':2} for a in ('d','e','f','g')},
         'proof_receipt':str(intake/'enriched-physical-v1/exact-jets.json'),
         'intervention_prediction':'auxiliary quadrilateral has square-root mismatch; physical feet quadrilateral does not. Signed contact should improve auxiliary precision; stable evaluation does not remove order2.',
         'caveat':'The physical quadratic form is indefinite, so some mixed directions cancel. No uniform lower bound; exact input proof replaced a mistaken preliminary informal q2 label for the auxiliary target before any outcomes.'},
        {'case_id':'GENERATED-PARABOLA-NORMAL-FOLD','split':'final_generated','status':'fresh designed normal-map DAG after rule freeze',
         'representations':'parabola-transfer-v1','root':'t=1,lam=2','chart':'t=1+w,lam=1+1/t',
         'm':2,'goal_orders':{'physical':1},'directional_orders':{'w':{'physical':1}},
         'proof_receipt':str(intake/'parabola-transfer-v1/derivation.json'),
         'intervention_prediction':'signed determinant residual regularizes the fold in 2D and reduced scalar forms; resquaring restores multiplicity. A +.01 height perturbation gives two simple roots; -.01 has no root inside guard.',
         'caveat':'Generated transfer, not natural coverage; input DAG detector must abstain because no certified circle incidence exists.'}]
    inputs=[]
    for p in sorted(intake.rglob('*.json')):
        if any(x in p.parts for x in ('representations-v2','enriched-v2','enriched-physical-v1','parabola-transfer-v1')):
            inputs.append({'path':str(p),'sha256':sha(p)})
    output={'schema':1,'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_hash':ensure_source(),
        'rule_freeze_sha256':sha(rules),'natural_corpus':rows,'local_predictions':local,'input_hashes':inputs,
        'information_policy':'Only authored inputs, exact mathematics and pre-outcome audit feedback. No unknown solver/pilot outcomes or official solutions.',
        'natural_coverage':{'total':60,'automatically_certified_bare_input':0,'root_q_automatic':0,'manual_designed_contact_cases':3},
        'local_probe_protocol':{'dps':400,'delta_exponents':[2,4,6,8,10,12],
            'directions':'positive and negative coordinate axes; positive and negative normalized (1,2,...,n); one fixed-seed integer mixed vector (seed 260911). Only directions with proven nonzero leading coefficients receive two-sided exponent scores.',
            'slope_tolerance':0.15,'rounding_check':'smallest two valid deltas plus independent exact formulas',
            'mathematical_start_generation':'Input-derived root-centred diagnostic starts, explicitly distinct from root-free pilot and native initialization. Not a deployable initial-point predictor.'},
        'local_lm_protocol':{'dps':[50,100,200],'iterations':80,'safety_seconds':30,
            'starts':'positive/negative principal mixed vector at delta 1e-2 and 1e-4, common coordinates for all residual arms',
            'variants':['original','signed','resquared','stable_gap where applicable'],'retain_actual_damping_steps_stops':True,
            'verifier':'Separate coordinate-correcting stage; original equations also checked without correction.',
            'matched_physical_comparison':'same physical start, all real lifts retained; 80 total LM iterations per physical cluster, divided deterministically among sheets; original native initialization is a separate arm'},
        'global_protocol':{'seeds':[0,1,2],'seconds_per_problem':180,'jobs':8,'threads':1,'physical_cores':1,
            'pilot':'contact_pilot.py v3 fixed CONFIG, after input predictions; no root-order certificate from finite points',
            'mid_gate':'30 mid natural + designed General6 local; then GPT-6-Pro audit3 before final outcomes',
            'final_gate':'30 final natural +4 enriched natural +fresh parabola transfer unchanged rules after audit3'},
        'baseline_predictions':['always exponent 1/2','always exponent 1','always linearization improves',
            'variable/equation count','public residual','nonzero singular-value condition','regularized goal sensitivity','always success when success prediction is scored'],
        'falsification':'Retain every invalid start, branch failure, no-effect, reversed effect, timeout and abstention. If theory is revised, affected observed cases become development and original forecasts stay archived.',
        'script_sha256':sha(Path(__file__))}
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'frozen':str(destination),'sha256':sha(destination),'natural':len(rows),'local':len(local),'unknown_optimizer_calls':0}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('intake',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();freeze(a.intake,a.destination)
