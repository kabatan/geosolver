"""Independent exact jets from line intersections; no GeoSolver or references.

The circle tangency normals are derived from n.O_A=p-r_A,
n.O_B=p-r_B and n.n=1. This is an input-only mathematical derivation.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s


def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def meet(a,b,c,d):
    v=sub(b,a);w=sub(d,c);t=cross(sub(c,a),w)/cross(v,w)
    return tuple(s.cancel(x+t*y) for x,y in zip(a,v))
def area_from_points(D,E,F,G):
    C=meet(D,E,F,G);M=meet(D,E,(0,-4),(1,-4));N=meet(F,G,(0,-4),(1,-4))
    return s.factor((N[0]-M[0])*(C[1]+4)/2)


def check():
    pL,pR,bL,bR=s.symbols('pL pR bL bR',real=True)
    aL=-s.sqrt(1-bL*bL);aR=s.sqrt(1-bR*bR)
    cy=(aL*pR-aR*pL)/(aL*bR-aR*bL)
    area=((pR+4*bR)/aR-(pL+4*bL)/aL)*(cy+4)/2
    at={pL:4,pR:4,bL:s.Rational(1,3),bR:s.Rational(1,3)}
    derivatives={str(v):s.simplify(s.diff(area,v).subs(at)) for v in (pL,pR,bL,bR)}
    assert derivatives=={'pL':12*s.sqrt(2),'pR':12*s.sqrt(2),'bL':-36*s.sqrt(2),'bR':-36*s.sqrt(2)}
    t=s.symbols('t',real=True);sq=s.sqrt(2)
    D=(-8*sq/3,s.Rational(4,3));E=(-2*sq,s.Integer(4));F=(8*sq/3,s.Rational(4,3));G=(2*sq,s.Integer(4))
    base=area_from_points(D,E,F,G)
    assert s.simplify(base-area.subs(at))==0
    rows=[]
    for i,label in enumerate(('d','e','f','g')):
        points=[D,E,F,G];center=(0,0) if i%2==0 else (0,3);point=sub(points[i],center)
        # Taylor polynomial of the exact circle point to fourth order.
        co=1-t*t/2+t**4/24;si=t-t**3/6
        points[i]=(center[0]+point[0]*co-point[1]*si,center[1]+point[1]*co+point[0]*si)
        expr=area_from_points(*points)-base
        jet=s.series(expr,t,0,5).removeO().expand()
        coeff={str(k):s.simplify(jet.coeff(t,k)) for k in (1,2,3,4)}
        assert coeff['1']==0
        if i%2==0:assert coeff['2']==0 and coeff['3']==0 and coeff['4']!=0
        else:assert coeff['2']==-18*s.sqrt(2)
        rows.append({'direction':label,'coefficients':{k:str(v) for k,v in coeff.items()}})
    return {'source':'input geometry only; analytical derivation before unknown solver runs',
        'line_branch':'outward unit normals (minus/plus 2sqrt(2)/3, 1/3), offsets4',
        'area_at_tangency':str(base),'area_derivatives':{k:str(v) for k,v in derivatives.items()},
        'residual_substitution':'p_i=4-rho_iA; b_i=(1-rho_iA+rho_iB)/3',
        'linear_in_physical_residuals':'-12sqrt(2)*(rho_LB+rho_RB)',
        'directional_jets':rows,'proof_checks_passed':True,
        'limitation':'Local source branch only. Coordinate-axis jets do not imply a uniform goal-error lower bound.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    result=check();result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
