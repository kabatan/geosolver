"""Natural contact extension selected after local rules were frozen.

No solver outcomes, answer keys, or references are used for selection or DSLs.
All four selected questions are retained, including regular tangency controls.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from unknown_authoring import eq,gt,lt,pred,put
from contact_detector import detect,transform
from unknown_corpus import canonical,signature,distance


def inputs():
    rows=[]
    put(rows,'CEMC-EUCLID-2026-08A','x y',[
        ('O','Point(0,0)'),('A','Point(2,0)'),('B','Point(-2,0)'),('omega','Circle(O,2)'),
        ('C','Point(x,y)'),('U','Intersect(omega,Line(B,C),exclude=B)'),('V','Reflect(U,O)')],
        [eq('IsTangent(Line(A,C),omega)'),eq('Distance(B,U)','2*Distance(U,C)'),
         gt('y'),gt('Distance(O,C)',2),eq('OnSegment(U,B,C)'),gt('Distance(B,U)'),gt('Distance(U,C)')],
        'Area(C,U,V)',
        'Rigid rotation fixes AB as a horizontal diameter; reflection fixes C.y>0. U is the second B-C circle intersection and lies strictly between B and C. No goal equation is substituted.')
    put(rows,'HMMT-NOV-2025-GUTS-12','d',[
        ('A','Point(-7,0)'),('B','Point(0,0)'),('C','Point(0,8)'),('D','Point(-d,8)'),
        ('O','Midpoint(A,D)'),('omega','Circle(O,Distance(A,D)/2)')],
        [eq('IsTangent(Line(B,C),omega)'),gt('d')],
        'Distance(C,D)',
        'The right trapezoid has vertices A-B-C-D in order. Positive d retains every convex source trapezoid. The diameter midpoint always has y=4, so its foot is strictly on BC. No pre-solved d is used.')
    put(rows,'UKMT-SMC-2025-16','x y s',[
        ('O','Point(x,y)'),('A','Point(0,0)'),('B','Point(s,0)'),('C','Point(s,s)'),('D','Point(0,s)'),('omega','Circle(O,2)')],
        [eq('IsTangent(Line(A,B),omega)'),eq('IsTangent(Line(A,D),omega)'),eq('IsTangent(Line(B,D),omega)'),
         gt('x'),gt('y'),gt('s'),lt('x','s'),lt('y','s'),lt('x+y','s')],
        'Distance(A,B)',
        'A rotation/reflection of the pictured half-square places the circle against the left/bottom edges and diagonal x+y=s. The centre is inside that triangular half. Radius 2 is given; the side is not substituted.')
    constructions=[('P','Point(0,0)'),('Q','Point(0,10)'),('O1','Point(a,5)'),('O2','Point(b,5)'),
        ('omega1','Circle(O1,sqrt(a**2+25))'),('omega2','Circle(O2,sqrt(b**2+25))'),
        ('L1a','Point(3*cos(alpha),3*sin(alpha))'),('L1b','Point(L1a.x-sin(alpha),L1a.y+cos(alpha))'),
        ('L2a','Point(12*cos(beta),12*sin(beta))'),('L2b','Point(L2a.x-sin(beta),L2a.y+cos(beta))'),
        ('ell1','Line(L1a,L1b)'),('ell2','Line(L2a,L2b)'),
        ('U1','ClosestPoint(O1,ell1)'),('U2','ClosestPoint(O1,ell2)'),
        ('V1','ClosestPoint(O2,ell1)'),('V2','ClosestPoint(O2,ell2)')]
    sides=[lt('a*cos(alpha)+5*sin(alpha)',3),lt('b*cos(alpha)+5*sin(alpha)',3),
           lt('a*cos(beta)+5*sin(beta)',12),lt('b*cos(beta)+5*sin(beta)',12)]
    put(rows,'HMMT-NOV-2025-GEN-08','a b alpha beta',constructions,
        [eq(f'IsTangent(ell{i},omega{j})') for i in (1,2) for j in (1,2)]+
        [lt('a','b'),gt('alpha','-pi'),lt('alpha','pi'),gt('beta','-pi'),lt('beta','pi')]+sides,
        'Area(U1,U2,V2,V1)',
        'P=(0,0),Q=(0,10) fix rigid motion. Both circles pass through P and Q by construction and a<b removes circle label duplication. Tangent lines have unit normals and positive offsets 3 and 12 from P; same-side centre guards select common external tangents. Contact quadrilateral uses physical feet. Parameter endpoints ±pi cannot be source roots because both horizontal lines through P cannot have the specified distances.')
    return rows


def hmmt_angle_variant(original):
    d=copy.deepcopy(original);d['variables']=['a','b','d','e','f','g']
    d['constructions']=d['constructions'][:6]
    for name,center,circle,angle in [('U1','O1','omega1','d'),('V1','O2','omega2','e'),('U2','O1','omega1','f'),('V2','O2','omega2','g')]:
        radius='sqrt(a**2+25)' if center=='O1' else 'sqrt(b**2+25)'
        d['constructions'].append({'name':name,'expression':f'Point({center}.x+{radius}*cos({angle}),{center}.y+{radius}*sin({angle}))'})
    d['constructions'] += [{'name':'ell1','expression':'Line(U1,V1)'},{'name':'ell2','expression':'Line(U2,V2)'}]
    d['conditions']=[eq(f'IsTangent(ell{i},omega{j})') for i in (1,2) for j in (1,2)]
    d['conditions'] += [eq('Distance(P,ell1)',3),eq('Distance(P,ell2)',12),lt('a','b')]
    # P is inside the common tangent half-planes. Both centres must be on
    # the same side of each line as P; this excludes internal tangent roots.
    for u,v in [('U1','V1'),('U2','V2')]:
        def cross(o):return f'(({v}.x-{u}.x)*({o}.y-{u}.y)-({v}.y-{u}.y)*({o}.x-{u}.x))'
        for o in ('O1','O2'):d['conditions'].append(gt(f'{cross("P")}*{cross(o)}'))
    for angle in ('d','e','f','g'):d['conditions'] += [gt(angle,'-pi'),lt(angle,'pi')]
    return d


def build(intake,destination):
    if destination.exists():raise FileExistsError(destination)
    freeze=intake/'local-prediction-protocol-v1.freeze.json'
    if not freeze.exists():raise ValueError('freeze theory rules before selecting this extension')
    destination.mkdir(parents=True)
    manifests=[];known=[]
    for p in sorted(Path('benchmarks/dsl').glob('*.json')):
        d=json.loads(p.read_text());known.append((d['id'],canonical(d),canonical(d,True),signature(d)))
    for row in inputs():
        d=row['dsl'];ident=d['id'];base=destination/'dsl';base.mkdir(exist_ok=True)
        path=base/(ident+'.json');path.write_text(json.dumps(d,indent=2)+'\n')
        variants={'original':d}
        if ident=='HMMT-NOV-2025-GEN-08':variants['constructed']=hmmt_angle_variant(d)
        for name,value in list(variants.items()):
            found=detect(value)
            if found['positive']:
                for mode in ('signed','squared','stable_gap'):variants[name+'_'+mode]=transform(value,found,mode)
        from geosolver.problem.models import GeometryProblem
        from geosolver.problem.validation import validate
        hashes={};detections={}
        for name,value in variants.items():
            report=validate(GeometryProblem.model_validate(value))
            if not report.valid:raise ValueError((ident,name,report))
            p=destination/'variants'/ident/(name+'.json');p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(json.dumps(value,indent=2)+'\n');hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest();detections[name]=detect(value)
        sig=signature(d);near=sorted(known,key=lambda t:(distance(sig,t[3]),t[0]))[:3]
        manifests.append({**row,'dsl_path':str(path),'variants':hashes,'detection':detections,
            'written_duplicates':[t[0] for t in known if t[1]==canonical(d)],
            'coefficient_blind_templates':[t[0] for t in known if t[2]==canonical(d,True)],
            'nearest_written_profiles':[{'id':t[0],'distance':distance(sig,t[3])} for t in near]})
    (destination/'semantic-manifest.json').write_text(json.dumps(manifests,indent=2,ensure_ascii=False)+'\n')
    receipt={'rule_freeze_sha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),
        'source_frame':'HMMT November2025 General/Theme/Team/Guts, Euclid2025/2026, UKMT SMC2025',
        'eligibility':'questions explicitly involving tangent circles/lines, with a finite geometry target supported by the DSL',
        'selected':[r['dsl']['id'] for r in manifests],
        'rejected_scope':{'Euclid2025':'no explicit tangency problem','HMMT2025Theme/Team':'no explicit tangency problem',
            'UKMT2025-05':'area partition of given circles; no unknown tangency solve'},
        'source_figures_checked':['source-pages/ukmt2025-p3.png','source-pages/cemc2026-p4.png'],
        'scope_limit':'mechanism-enriched four-case extension, separate from source-first 60. It estimates no unconditional population prevalence.',
        'reuse_limit':'HMMT common-tangent representation shares the earlier line-construction motif, now with variable intersecting circles and extra regular constraints; do not count as an independent theory.',
        'solver_calls':0,'answer_keys_read':False,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (destination/'selection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'selected':receipt['selected'],'variants':[len(r['variants']) for r in manifests]}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('intake',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();build(a.intake,a.destination)
