"""Stage-entry independent JMO event model and residual-weighted LM diagnostics.

This is assessment, never solver feedback. The JMO model consumes only the
first coordinate and damping of each stage before predicting five full steps;
later recorded states are used solely for comparison. It is a development
mechanism check, not an input-only unknown-problem success prediction.
"""
import argparse,hashlib,json,statistics
from collections import defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import dumps,loads


def weighted_metrics(data,step=None):
    J=mp.matrix(data['jacobian']);f=mp.matrix(data['residual_vector'])
    lam=data['damping'];r=mp.norm(f);delta=mp.matrix(step) if step is not None else mp.lu_solve(J.T*J+lam*mp.eye(J.cols),-J.T*f)
    effective=mp.norm(J.T*f)**2/r**2 if r else None
    linear=mp.norm(f+J*delta)
    return {'residual_weighted_sigma_squared':effective,
        'lambda_over_residual_weighted_sigma_squared':lam/effective if effective else None,
        'linearized_next_norm':linear,
        'linearized_true_relative_improvement':(r-linear)/r if r else None,
        'linearized_product_improvement':(r-linear)/max(r,mp.mpf('1e-30')),
        'scope':'First-order prediction from actual saved J,F and proposed step; nonlinear remainder, line-search scaling and guards are not hidden.'}


def model(point,lam,signed=False,scale=1):
    _,p,q=point
    h=mp.matrix([q/p-p/2,9*p/(2*q)-q/2])
    Dh=mp.matrix([[-q/p**2-mp.mpf('.5'),1/p],[mp.mpf('4.5')/q,-mp.mpf('4.5')*p/q**2-mp.mpf('.5')]])
    f=scale*(h if signed else mp.matrix([z*z for z in h]))
    J=scale*(Dh if signed else mp.diag([2*z for z in h])*Dh)
    d=mp.lu_solve(J.T*J+lam*mp.eye(2),-J.T*f)
    return f,J,mp.matrix([0,d[0],d[1]])


def predict_five(point,lam,floor,signed=False,scale=1):
    x=mp.matrix(point);rows=[]
    for k in range(5):
        f,J,step=model(x,lam,signed,scale);r=mp.norm(f);nxt=x+step
        fn,_,_=model(nxt,lam,signed,scale);rn=mp.norm(fn)
        I=(r-rn)/max(r,mp.mpf('1e-30'))
        rows.append({'index':k,'point':list(x),'step':list(step),'damping':lam,
            'norm':r,'next_norm':rn,'product_improvement':I,'small':I<mp.mpf('1e-10'),
            'full_step_improves':rn<r})
        x=nxt;lam=max(floor,lam/4)
    return rows


def analyze(paths,out):
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);stages=[];details=[]
    with mp.workdps(300):
        for path in paths:
            r=loads(path.read_text());name=path.stem
            if 'JMO-2013-PRE-05' not in str(path):continue
            if not (name.startswith('original__') or name.startswith('projection__')):continue
            signed=name.startswith('projection__');scale=mp.mpf(str(r.get('residual_scale') or 1))
            cfg=r.get('refiner_config',r.get('config'))
            floor=mp.mpf(cfg.damping_min) if cfg is not None else mp.mpf('1e-12')
            if '__floor_' in name:floor=mp.mpf(name.split('__floor_')[1].split('_carry')[0])
            elif '__damping_min_' in name:floor=mp.mpf(name.split('__damping_min_')[1])
            grouped=defaultdict(list);pending=None
            for ev in r['trace']:
                if ev['kind']=='lm_step':pending=ev
                if ev['kind']=='line_search' and pending:
                    grouped[ev['input']['dps']].append((pending,ev));pending=None
            for dps,events in grouped.items():
                first_lm,first_ls=events[0]
                forecast=predict_five(first_ls['input']['point'],first_lm['input']['damping'],floor,signed,scale)
                row={'source':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'point_index':path.parent.name,'condition':name,'dps':dps,'recorded_steps':len(events),
                    'prediction_information':'Only this stage entry coordinate, initial damping, known floor and independent rational JMO equations.',
                    'first_five_full_steps_prediction':forecast,'predicted_all_five_small':all(v['small'] for v in forecast),
                    'predicted_all_five_improve':all(v['full_step_improves'] for v in forecast),
                    'actual_first_five_small':[],'actual_first_five_improve':[],
                    'actual_first_five_full_steps':[],
                    'first_five_step_relative_errors':[],'first_five_improvement_absolute_errors':[]}
                for k,(lm,ls) in enumerate(events):
                    if 'output' not in ls:continue
                    trial,rv,ok=ls['output'];start=ls['input']['current_norm']
                    actual=(start-mp.norm(rv))/max(start,mp.mpf('1e-30')) if ok and rv is not None else None
                    metrics=weighted_metrics(lm['input'],ls['input']['step'])
                    rec={'source':str(path),'dps':dps,'step_index':k,'actual_product_improvement':actual,**metrics}
                    if actual is not None:rec['nonlinear_or_linesearch_improvement_difference']=actual-metrics['linearized_product_improvement']
                    details.append(rec)
                    if k<5:
                        pred=forecast[k];actualstep=mp.matrix(ls['input']['step'])
                        row['actual_first_five_small'].append(actual is not None and actual<mp.mpf('1e-10'))
                        row['actual_first_five_improve'].append(ok)
                        accepted=mp.matrix(trial) if ok and trial is not None else None
                        expected_point=mp.matrix(ls['input']['point'])+actualstep
                        full=(accepted is not None and mp.norm(accepted-expected_point)<=
                              mp.power(10,-max(10,dps-10))*max(1,mp.norm(expected_point)))
                        row['actual_first_five_full_steps'].append(bool(full))
                        row['first_five_step_relative_errors'].append(mp.norm(actualstep-mp.matrix(pred['step']))/max(mp.mpf('1e-280'),mp.norm(mp.matrix(pred['step']))))
                        row['first_five_improvement_absolute_errors'].append(abs(actual-pred['product_improvement']) if actual is not None else None)
                row['actual_five_small_event']=len(events)>=5 and all(row['actual_first_five_small']) and all(row['actual_first_five_improve'])
                boundary=next((v for v in r['trace'] if v['kind']=='stage_boundary' and v['dps']==dps),None)
                row['stage_status']=boundary.get('output',[None])[0] if boundary else None
                # This five-step model assumes accepted full steps. Deviations
                # remain visible, including target exit and non-improving trials.
                row['event_agreement']=row['predicted_all_five_small']==row['actual_five_small_event'] if len(events)>=5 else None
                row['full_step_assumptions_observed']=(len(events)>=5 and row['predicted_all_five_improve'] and
                    all(row['actual_first_five_improve']) and all(row['actual_first_five_full_steps']))
                stages.append(row)
    for name,rr in [('stages',stages),('weighted-steps',details)]:
        (out/(name+'.jsonl')).write_text(''.join(dumps(v)+'\n' for v in rr))
    aggregate=[]
    for condition,dps in sorted({(v['condition'],v['dps']) for v in stages}):
        rr=[v for v in stages if v['condition']==condition and v['dps']==dps]
        errors=[float(x) for v in rr for x in v['first_five_step_relative_errors']]
        aggregate.append({'condition':condition,'dps':dps,'stage_entries':len(rr),
            'predicted_all_five_small':sum(v['predicted_all_five_small'] for v in rr),
            'actual_five_small_event':sum(v['actual_five_small_event'] for v in rr),
            'event_agreement':sum(v['event_agreement'] is True for v in rr),
            'event_comparable':sum(v['event_agreement'] is not None for v in rr),
            'full_step_assumptions_observed':sum(v['full_step_assumptions_observed'] for v in rr),
            'event_agreement_with_full_step_assumptions':sum(v['full_step_assumptions_observed'] and v['event_agreement'] is True for v in rr),
            'median_first_five_relative_step_error':statistics.median(errors) if errors else None})
    receipt={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'mode':'Development stage-entry model assessment, not an unknown input-only forecast.',
        'natural_cases':1,'seed_dependence':'Retained source pools from three external seeds; not independent trials.',
        'aggregate':aggregate}
    (out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    paths=[]
    for sub in ('development/damping-campaign-v1','development/stage-campaign-v2'):
        paths.extend((a.archive/sub/'runs/JMO-2013-PRE-05').glob('*/*.json'))
    if not paths:raise ValueError('No source paths; inspect campaign names')
    analyze(sorted(paths),a.output)
