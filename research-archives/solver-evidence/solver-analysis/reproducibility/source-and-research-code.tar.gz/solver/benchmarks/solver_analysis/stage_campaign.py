"""Run a frozen paired-stage diagnostic campaign on independent physical cores.

Every variant of one initial point runs sequentially on the same core. Groups
are parallel; condition order is independently shuffled by a fixed seed. Each
condition uses a fresh Python process and cache. All nonzero exits are retained.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
import platform
import queue
import random
import subprocess
import sys
import time
from pathlib import Path

from exact_codec import loads
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]
THREADS={k:'1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')}


def make_plan(archive):
    groups=[]
    pools={'JMO-2013-PRE-05':archive/'development/jmo-legacy-source-pool.json',
           'HMMT-2014-FEB-GEO-10':archive/'development/hmmt2014-legacy-source-pool.json'}
    for ident,pool in pools.items():
        points=loads(pool.read_text())['points'];conditions=[]
        names=['original','direct_gap','stable_gap','projection','projection_squared','identity_removed','normal_form_squared','normal_form_linear','reorder_only','scale_only','redundancy_only'] if ident.startswith('JMO') else ['original','signed_contact','contact_squared','incidence_saturated','identity_removed','reorder_only','scale_only','relative_incidence','relative_external','both_relative','relative_signed_contact']
        for name in names:conditions.append({'name':name+'__native_refine','variant':name,'engine':'native_refine','iterations':80,'dps':120,'verify':True})
        if ident.startswith('JMO'):
            for exponent in (24,48):conditions.append({'name':f'original__damping_min_1e-{exponent}','variant':'original','engine':'native_refine','iterations':80,'dps':120,'damping':f'1e-{exponent}','verify':True})
            conditions.append({'name':'original__rank_cap512','variant':'original','engine':'native_refine','iterations':80,'dps':120,'rank_cap':512,'verify':True})
            for name in ('original','projection','projection_squared'):
                for dps in (50,100,200):conditions.append({'name':f'{name}__lm{dps}','variant':name,'engine':'native_lm','iterations':80,'dps':dps,'verify':False})
        for name in ('original','projection' if ident.startswith('JMO') else 'signed_contact'):
            conditions.append({'name':name+'__scipy_refine','variant':name,'engine':'scipy_refine','iterations':320,'dps':120,'verify':True})
        for index,point in enumerate(points):
            group={'case_id':ident,'pool':str(pool),'pool_sha256':hashlib.sha256(pool.read_bytes()).hexdigest(),
                   'point_index':index,'uid':point['uid'],'conditions':list(conditions)}
            random.Random(29011+index).shuffle(group['conditions']);groups.append(group)
    random.Random(29012).shuffle(groups)
    return {'schema':1,'kind':'instrumented development diagnostic, not ordinary wall-time benchmark',
        'source_hash':ensure_source(),'thread_environment':THREADS,'archive':str(archive),
        'safety_seconds_per_condition':30,'independent_trial_warning':'Points are retained sources; external/internal seed overlap persists.',
        'groups':groups,'planned_conditions':sum(len(g['conditions']) for g in groups),
        'protocol':str(archive/'development/intervention-protocol-v1.md')}


def run(plan,destination,jobs):
    if destination.exists():raise FileExistsError(destination)
    if ensure_source()!=plan['source_hash']:raise ValueError('Source changed')
    sys.path.insert(0,str(ROOT/'benchmarks'))
    from research_runner import _independent_cpus
    cpus=_independent_cpus()[:jobs];available=queue.Queue()
    for cpu in cpus:available.put(cpu)
    destination.mkdir(parents=True)
    plan.update(execution_cores=cpus,python=sys.executable,platform=platform.platform(),
        script_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')})
    (destination/'manifest.json').write_text(json.dumps(plan,indent=2)+'\n')
    archive=Path(plan['archive']);worker=Path(__file__).with_name('paired_stages.py');start=time.monotonic()
    env=dict(os.environ,**THREADS);done=0;failed=0
    def one_group(group):
        cpu=available.get();rows=[]
        try:
            ident=group['case_id'];directory=destination/'runs'/ident/str(group['point_index']);directory.mkdir(parents=True)
            for condition in group['conditions']:
                output=directory/(condition['name']+'.json')
                cmd=['taskset','-c',str(cpu),sys.executable,'-B',str(worker),'run',
                    str(archive/'development/representations-v2'/ident/(condition['variant']+'.json')),
                    str(ROOT/'benchmarks/dsl'/(ident+'.json')),group['pool'],str(group['point_index']),str(output),
                    '--engine',condition['engine'],'--iterations',str(condition['iterations']),
                    '--dps',str(condition['dps']),'--seconds',str(plan['safety_seconds_per_condition'])]
                for key,flag in [('damping','--damping'),('rank_cap','--rank-cap'),('initial_damping','--initial-damping'),('residual_scale','--residual-scale')]:
                    if key in condition:cmd += [flag,str(condition[key])]
                if condition.get('carry_damping'):cmd.append('--carry-damping')
                if condition['verify']:cmd.append('--verify')
                begun=time.monotonic()
                try:
                    r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=plan['safety_seconds_per_condition']+20)
                    row={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
                except subprocess.TimeoutExpired as e:
                    row={'exit_code':'process_timeout','stdout':str(e.stdout),'stderr':str(e.stderr)}
                row.update(case_id=ident,point_index=group['point_index'],condition=condition['name'],cpu=cpu,
                           process_seconds=time.monotonic()-begun,output=str(output),output_exists=output.exists())
                rows.append(row)
            (directory/'execution.json').write_text(json.dumps(rows,indent=2)+'\n')
            return rows
        finally:available.put(cpu)
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(cpus)) as executor:
        futures=[executor.submit(one_group,g) for g in plan['groups']]
        for future in concurrent.futures.as_completed(futures):
            rows=future.result();done+=len(rows);failed+=sum(r['exit_code']!=0 for r in rows)
            print(json.dumps({'completed':done,'planned':plan['planned_conditions'],'nonzero_process_exits':failed,
                              'elapsed_seconds':round(time.monotonic()-start,2)}),flush=True)
    (destination/'completion.json').write_text(json.dumps({'completed':done,'planned':plan['planned_conditions'],
        'nonzero_process_exits':failed,'elapsed_seconds':time.monotonic()-start,'source_hash_after':ensure_source()},indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();s=p.add_subparsers(dest='mode',required=True)
    a=s.add_parser('plan');a.add_argument('archive',type=Path);a.add_argument('output',type=Path)
    a=s.add_parser('run');a.add_argument('plan',type=Path);a.add_argument('output',type=Path);a.add_argument('--jobs',type=int,default=8)
    a=p.parse_args()
    if a.mode=='plan':
        if a.output.exists():raise FileExistsError(a.output)
        plan=make_plan(a.archive);a.output.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'groups':len(plan['groups']),'conditions':plan['planned_conditions']}))
    else:run(json.loads(a.plan.read_text()),a.output,a.jobs)
