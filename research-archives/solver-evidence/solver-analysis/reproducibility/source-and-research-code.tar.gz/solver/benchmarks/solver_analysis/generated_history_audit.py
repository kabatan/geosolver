"""Static input/family inventory across modern and legacy experiment assets.

No old generator is executed. Literal Python fixtures and embedded JSON inputs
are screened; Julia function-based generators are indexed and manually reviewed.
The screen is not an isomorphism proof and never claims a fresh mathematical
principle from a missing textual match.
"""
import argparse,ast,hashlib,json,re,subprocess
from collections import Counter
from pathlib import Path
from unknown_corpus import canonical,signature,distance


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalized(doc):
    if not isinstance(doc,dict) or 'variables' not in doc:return None
    if {'constructions','conditions','target'}<=doc.keys():return doc
    if not {'construction','constraints','answer'}<=doc.keys():return None
    vs=doc['variables'];vs=vs.get('names',[]) if isinstance(vs,dict) else vs
    cs=[]
    for c in doc['constraints']:
        if isinstance(c,str):cs.append({'predicate':c})
        elif {'def','value'}<=c.keys():cs.append({'left':c['def'],'operator':'=','right':c['value']})
        else:return None
    cs += [{'predicate':g} for g in doc.get('guards',[]) if isinstance(g,str)]
    return {'id':doc.get('id'),'variables':vs,
        'constructions':[{'name':c['name'],'expression':c.get('expr',c.get('expression'))} for c in doc['construction']],
        'conditions':cs,'target':doc['answer']}


def audit(repo,experiment,archive,out):
    if out.exists():raise FileExistsError(out)
    roots=[repo/'benchmarks/dsl',repo/'tests',experiment/'research/experiments',
        experiment/'research/datasets',experiment/'benchmarks/generated',experiment/'julia/GeoTargetBenchmarks/src']
    paths=[Path(v) for v in subprocess.check_output(['rg','--files',*[str(p) for p in roots]],text=True).splitlines()
        if v.endswith(('.json','.jsonl','.py','.jl'))]
    inventory=[];inputs=[];families=[];errors=[];keywords=[]
    def walk(doc,path,location):
        dsl=normalized(doc)
        if dsl is not None:
            try:inputs.append({'id':dsl.get('id') or location,'path':str(path),'location':location,
                'legacy':('construction' in doc),'exact':canonical(dsl),'template':canonical(dsl,True),'signature':signature(dsl)})
            except Exception as ex:errors.append({'path':str(path),'location':location,'error':type(ex).__name__+': '+str(ex)})
        if isinstance(doc,dict):
            family=doc.get('family_id',doc.get('family'))
            if isinstance(family,str):families.append({'family':family,'id':doc.get('instance_id',doc.get('id',doc.get('case_id'))),'path':str(path),'location':location})
            for k,v in doc.items():
                if isinstance(v,(dict,list)):walk(v,path,location+'/'+str(k))
        elif isinstance(doc,list):
            for i,v in enumerate(doc):
                if isinstance(v,(dict,list)):walk(v,path,location+'/'+str(i))
    for path in paths:
        body=path.read_text(errors='replace');inventory.append({'path':str(path),'sha256':digest(path),'bytes':path.stat().st_size})
        if path.suffix=='.jl':
            for n,line in enumerate(body.splitlines(),1):
                if re.search(r'parabola|evolute|double.root|tangent.circle|SING-ISOLATED|multiplicity',line,re.I):
                    keywords.append({'path':str(path),'line':n,'text':line[:400]})
        elif path.suffix=='.py':
            try:
                tree=ast.parse(body)
                for node in ast.walk(tree):
                    if isinstance(node,ast.Dict):
                        try:doc=ast.literal_eval(node)
                        except (ValueError,TypeError,SyntaxError):continue
                        if normalized(doc):walk(doc,path,'literal-line-'+str(node.lineno))
            except Exception as ex:errors.append({'path':str(path),'error':type(ex).__name__+': '+str(ex)})
        else:
            try:
                docs=[json.loads(s) for s in body.splitlines() if s.strip()] if path.suffix=='.jsonl' else [json.loads(body)]
                for i,doc in enumerate(docs):walk(doc,path,str(i))
            except Exception as ex:errors.append({'path':str(path),'error':type(ex).__name__+': '+str(ex)})
    seen=set();inputs=[v for v in inputs if (v['exact'],v['id']) not in seen and not seen.add((v['exact'],v['id']))]
    seen=set();families=[v for v in families if (v['family'],v['id']) not in seen and not seen.add((v['family'],v['id']))]
    unknown=[]
    for source in [archive/'unknown-intake/corpus-v1'/s/'cases.jsonl' for s in ('mid','final')]+[archive/'unknown-intake/final-extension-corpus-v1/cases.jsonl']:
        for line in source.read_text().splitlines():
            v=json.loads(line);dsl=v.get('dsl') or json.loads((source.parent/v['dsl_path']).read_text())
            ex,tm,sg=canonical(dsl),canonical(dsl,True),signature(dsl)
            unknown.append({'id':v['id'],'case_source':str(source),'exact_matches':[i for i in inputs if i['exact']==ex],
                'coefficient_blind_matches':[i for i in inputs if i['template']==tm],
                'nearest_profiles':[{**i,'distance':distance(sg,i['signature'])} for i in sorted(inputs,key=lambda i:(distance(sg,i['signature']),str(i['id'])))[:3]],
                'interpretation':'Written-input screen only; no claim of geometric or theoretical independence.'})
    out.mkdir(parents=True)
    for name,rows in [('files',inventory),('input-records',inputs),('family-records',families),('generator-lines',keywords),('unknown-screen',unknown)]:
        (out/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    receipt={'script_sha256':digest(Path(__file__)),'roots':[str(r) for r in roots],'files':len(paths),
        'distinct_input_id_fingerprints':len(inputs),'legacy_inputs':sum(v['legacy'] for v in inputs),
        'distinct_family_id_records':len(families),'families':dict(Counter(v['family'] for v in families)),
        'unknown_cases':len(unknown),'with_exact_match':sum(bool(v['exact_matches']) for v in unknown),
        'with_coefficient_blind_match':sum(bool(v['coefficient_blind_matches']) for v in unknown),'errors':errors,
        'limitations':['No generator code execution; nonliteral Python and Julia DSL builders require source review.',
            'No exhaustive geometric isomorphism decision.',
            'All prior multiplicity, constant-target manifold, tangent and near-root principles are development knowledge.']}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('errors','families','limitations','roots')}));print(json.dumps({'errors':len(errors),'families':receipt['families']}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--experiment',type=Path,default=Path('/home/kabatan/work/solver-experiment'));a=p.parse_args();audit(Path.cwd(),a.experiment,a.archive,a.output)
