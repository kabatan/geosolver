"""Prospective mid-study generated observer-offset contact family.

One geometry trajectory is scored with three genuine distance observables.
This is a new generated diagnostic of a known contact principle, not a new
natural problem or an unused mathematical singularity type.
"""
import argparse,hashlib,json,random,sys,time
from datetime import datetime,timezone
from pathlib import Path
from mpmath import mp
from contact_detector import detect,transform
from exact_codec import dumps,loads
from paired_stages import bundle_of
from stage_replay import ensure_source
from prospective_local import command

ID='GENERATED-OBSERVER-OFFSET-CONTACT'
OFFSETS=('0','1e-6','1/3')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rational(v):
    if '/' in v:
        a,b=v.split('/');return mp.mpf(a)/mp.mpf(b)
    return mp.mpf(v)
def save(p,v):
    if p.exists():raise FileExistsError(p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(dumps(v)+'\n')


def prepare(archive):
    dest=archive/'unknown-intake/observer-contact-mid-v1'
    if dest.exists():raise FileExistsError(dest)
    # Neither references nor any solver outcome is read during preparation.
    dsl={'id':ID,'variables':['h'],'constructions':[
        {'name':'O','expression':'Point(0,2)'},{'name':'T','expression':'Point(h,0)'},
        {'name':'A','expression':'Point(-1,0)'},{'name':'B','expression':'Point(1,0)'},
        {'name':'L','expression':'Line(A,B)'},
        {'name':'C','expression':'Circle(O,Distance(O,T))'},
        {'name':'P','expression':'Point(1/3,1)'}],
        'conditions':[{'left':'IsTangent(L,C)','operator':'=','right':0},
            {'left':'h','operator':'>','right':-1},{'left':'h','operator':'<','right':1}],
        'target':'Distance(P,T)'}
    detection=detect(dsl);assert detection['positive'] and len(detection['contacts'])==1
    variants={'original':dsl,**{k:transform(dsl,detection,k) for k in ('signed','squared','stable_gap')}}
    dest.mkdir(parents=True)
    for name,v in variants.items():
        bundle_of(v);p=dest/(name+'.json');p.write_text(json.dumps(v,indent=2)+'\n')
    forecast={'created_utc':datetime.now(timezone.utc).isoformat(),'source_hash':ensure_source(),
        'theory_rule_freeze_sha256':sha(archive/'unknown-intake/prediction-freeze-v1.json') if (archive/'unknown-intake/prediction-freeze-v1.json').exists() else None,
        'base_forecast_sha256':sha(archive/'unknown-intake/individual-predictions-v1.json'),
        'source':'new generated mid-study family, no external source or solution',
        'history_relation':'Known circle-line tangency and m,q principle; new fixed observer-offset diagnostic. Not an unused mathematical structure or an additional natural case.',
        'detection':detection,'offsets':OFFSETS,'geometry':'O=(0,2),T=(h,0),C=Circle(O,OT),L:y=0, -1<h<1',
        'factor':'F_public=sqrt(4+h^2)-2=h^2/(sqrt(4+h^2)+2); production smoothed F=-h^2',
        'unique_root_proof':'F=0 iff h=0 on the guard',
        'targets':'P_a=(a,1); G_a(h)=sqrt((h-a)^2+1)',
        'goal_identity':'G_a(h)^2-G_a(0)^2=h^2-2*a*h',
        'predictions':{'m':2,'q_at_a_zero':2,'q_at_each_nonzero_a':1,
            'coefficients':'F/h^2->1/4; at a=0, (G-1)/h^2->1/2; at a!=0, (G-G0)/h->-a/sqrt(1+a^2)',
            'crossover':'linear and quadratic terms in G^2-G0^2 have equal magnitude at |h|=2|a|; finite samples above this scale can mimic q2 even when root q1',
            'goal_only_counterexample':'h=2a !=0 gives exactly G_a(h)=G_a(0) but F_public>0, for both nonzero fixed offsets',
            'finite_lm':'signed should increase goal digits over original at same starts and80 iterations; stable quadratic and resquared preserve multiplicity. No global output prediction.',
            'targets_share_trajectory':True},
        'probes':{'dps':400,'signed_powers':[2,4,6,8,10,12],'asymptotic_slope_tolerance':'.15','coefficient_relative_tolerance':'1e-3'},
        'optimizer':{'starts':['-.01','.01','-.0001','.0001'],'dps':[50,100,200],'iterations':80,
            'residual_arms':list(variants),'seconds_safety':30,'native_scalar_search':'not used; direct local stage only'},
        'scoring':'all fixed offsets reported from the same saved coordinate, including exact goal cancellation with nonzero residual; not three independent geometries',
        'information_separation':'No solver/pilot results of this generated family exist at freeze. Natural official references were already acquired separately; they do not enter this derivation.',
        'dsl_hashes':{n:sha(dest/(n+'.json')) for n in variants},'script_sha256':sha(Path(__file__))}
    p=dest/'forecast.json';p.write_text(json.dumps(forecast,indent=2)+'\n')
    pool=dest/'pool.json'
    with mp.workdps(550):save(pool,{'points':[{'x':(mp.mpf(h),),'uid':ID+'__'+h,'external_seed':0} for h in forecast['optimizer']['starts']]})
    groups=[];resultroot=archive/'unknown-results/observer-contact-mid-v1'
    for index in range(4):
        jobs=[]
        for dps in (50,100,200):
            for variant in variants:
                output=resultroot/'runs'/f'start{index}__{variant}__{dps}.json'
                jobs.append(command(dest/(variant+'.json'),dest/'original.json',pool,index,output,80,dps))
        random.Random(960911+index).shuffle(jobs);groups.append({'id':'start'+str(index),'jobs':jobs})
    plan={'source_hash':ensure_source(),'jobs':4,'groups':groups,'forecast_sha256':sha(p),
        'wait_for_receipt':str(archive/'analysis/development-comparison-analysis-batch-v1/completion.json')}
    pp=dest/'plan.json';pp.write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps({'family':ID,'jobs':48,'forecast':str(p),'plan':str(pp)}))


def observations(h):
    r=mp.sqrt(4+h*h);gap=h*h/(r+2)
    goals={}
    for offset in OFFSETS:
        a=rational(offset);g=mp.sqrt((h-a)**2+1);g0=mp.sqrt(a*a+1)
        # Stable identity, independently evaluated from the public DSL target.
        error=(h*h-2*a*h)/(g+g0)
        goals[offset]={'value':g,'root_value':g0,'signed_error':error,
            'relative_error':abs(error)/max(1,abs(g0)),
            'digits':float(min(350,-mp.log10(max(mp.mpf('1e-350'),abs(error)/max(1,abs(g0))))))}
    return {'h':h,'residual':gap,'guard':-1<h<1,'goals':goals}


def analyze(archive,out):
    if out.exists():raise FileExistsError(out)
    intake=archive/'unknown-intake/observer-contact-mid-v1';root=archive/'unknown-results/observer-contact-mid-v1'
    if json.loads((root/'batch/completion.json').read_text()).get('status')!='complete':raise ValueError('batch incomplete')
    forecast=json.loads((intake/'forecast.json').read_text());plan=json.loads((intake/'plan.json').read_text())
    out.mkdir(parents=True);probes=[];scores=[];counterexamples=[];runs=[]
    with mp.workdps(400):
        for sign in (-1,1):
            rr=[]
            for exponent in forecast['probes']['signed_powers']:
                h=sign*mp.mpf(10)**(-exponent);z=observations(h);z.update(sign=sign,exponent=exponent);rr.append(z);probes.append(z)
            a,b=rr[-2:];m=mp.log10(b['residual']/a['residual'])/-2
            for offset in OFFSETS:
                ga,gb=a['goals'][offset],b['goals'][offset];q=mp.log10(abs(gb['signed_error']/ga['signed_error']))/-2
                expected=2 if offset=='0' else 1;aa=rational(offset)
                c=mp.mpf(1)/2 if offset=='0' else -aa/mp.sqrt(1+aa*aa)
                measured=gb['signed_error']/b['h']**expected
                scores.append({'offset':offset,'sign':sign,'measured_m':m,'measured_q':q,'predicted_q':expected,
                    'm_pass':abs(m-2)<=mp.mpf('.15'),'q_pass':abs(q-expected)<=mp.mpf('.15'),
                    'predicted_leading_coefficient':c,'measured_leading_coefficient':measured,
                    'coefficient_relative_error':abs((measured-c)/c),
                    'coefficient_pass':abs((measured-c)/c)<=mp.mpf('1e-3'),
                    'q_over_m_error_always_half':abs(q/m-mp.mpf('.5')),
                    'q_over_m_error_always_one':abs(q/m-1)})
        for offset in OFFSETS[1:]:
            a=rational(offset);z=observations(2*a);z['chosen_offset']=offset
            z['zero_goal_nonzero_gap']=z['goals'][offset]['signed_error']==0 and z['residual']>0
            counterexamples.append(z)
        for g in plan['groups']:
            for job in g['jobs']:
                p=Path(job['command'][8]);start,variant,dps=p.stem.split('__')
                row={'file':str(p),'start':start,'variant':variant,'dps':int(dps),'available':p.exists()}
                if p.exists():
                    r=loads(p.read_text());row.update(raw_sha256=sha(p),status=r['status'],error=r['error'],
                        censored=r['safety_deadline_hit'],numeric_seconds=r['numeric_seconds'],calls=r['numeric_calls'],
                        initial=observations(r['point']['x'][0]),final=observations(r['pre_verifier_point'][0]),
                        lm_steps=sum(v['kind']=='lm_step' for v in r['trace']))
                runs.append(row)
    write(out/'probes.jsonl',probes);write(out/'scores.jsonl',scores)
    write(out/'counterexamples.jsonl',counterexamples);write(out/'runs.jsonl',runs)
    pairs=[]
    for r in runs:
        if r['variant']=='original':continue
        base=next(v for v in runs if v['start']==r['start'] and v['dps']==r['dps'] and v['variant']=='original')
        for offset in OFFSETS:
            a=base.get('final',{}).get('goals',{}).get(offset);b=r.get('final',{}).get('goals',{}).get(offset)
            pairs.append({'start':r['start'],'dps':r['dps'],'variant':r['variant'],'offset':offset,
                'goal_digit_gain':b['digits']-a['digits'] if a and b else None})
    write(out/'pairs.jsonl',pairs)
    summary={'family':ID,'planned_runs':48,'available':sum(r['available'] for r in runs),
        'scored_directions_and_offsets':len(scores),'m_pass':sum(r['m_pass'] for r in scores),
        'q_pass':sum(r['q_pass'] for r in scores),'coefficient_pass':sum(r['coefficient_pass'] for r in scores),
        'goal_only_counterexamples':sum(r['zero_goal_nonzero_gap'] for r in counterexamples),
        'forecast_sha256':sha(intake/'forecast.json'),'script_sha256':sha(Path(__file__)),
        'scope':'One generated mid-study contact geometry with observer-offset continuation. All observer goals share each trajectory. No natural-problem or independent-structure count is increased.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


def write(p,rows):p.write_text(''.join(dumps(r)+'\n' for r in rows))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','analyze']);p.add_argument('archive',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    if a.mode=='prepare':prepare(a.archive)
    else:analyze(a.archive,a.output)
