"""Source-first unknown inputs. Does not import or run GeoSolver's solve path.

References and observed solver outcomes are intentionally absent. All semantic
adaptations are stored alongside the input. Syntax validation is allowed;
solution discovery and prediction occur only after the corpus is frozen.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def eq(left,right=0):return {'left':left,'operator':'=','right':right}
def gt(left,right=0):return {'left':left,'operator':'>','right':right}
def lt(left,right):return {'left':left,'operator':'<','right':right}
def pred(value):return {'predicate':value}
def c(name,expression):return {'name':name,'expression':expression}
def pos(*names):return [gt(n) for n in names]
def segment(p,a,b,strict=False):
    return [eq(f'OnSegment({p},{a},{b})')]+([gt(f'Distance({p},{a})'),gt(f'Distance({p},{b})')] if strict else [])
def put(out,ident,variables,constructions,conditions,target,semantics):
    out.append({'dsl':{'id':ident,'variables':variables.split() if isinstance(variables,str) else variables,
                      'constructions':[c(k,v) for k,v in constructions], 'conditions':conditions,'target':target},
                'semantic_notes':semantics,'reference_status':'not yet independently certified',
                'solver_outcomes_seen':False})


def hmmt():
    out=[]
    put(out,'HMMT-NOV-2022-GEN-06','',[
        ('A','Point(1/2,sqrt(3)/2)'),('B','Point(0,0)'),('C','Point(1,0)'),
        ('D','Point(1,-1)'),('E','Point(0,-1)'),('O12','Point(1/2,-1-cos(pi/12)/(2*sin(pi/12)))'),
        ('F','Point(O12.x+cos(3*pi/4)/(2*sin(pi/12)),O12.y+sin(3*pi/4)/(2*sin(pi/12)))'),
        ('N','Point(O12.x+cos(25*pi/12)/(2*sin(pi/12)),O12.y+sin(25*pi/12)/(2*sin(pi/12)))'),
        ('omega','Circumcircle(A,F,N)')],[], 'pi*Radius(omega)**2',
        'Rigid-motion normalization; triangle above BC, square below BC, dodecagon below DE. Dodecagon central angle pi/6; D angle 5pi/12 and N angle25pi/12. No equation involving target was pre-solved.')
    put(out,'HMMT-NOV-2022-THM-04','a b d',[
        ('A','Point(0,a)'),('B','Point(d,b)'),('Ap','Point(0,-a)')],
        [eq('Distance(A,B)',16),eq('Distance(Ap,B)',26),eq('IsInteger(a)'),eq('IsInteger(b)')]+pos('a','b','d'), 'a',
        'Reflection across the ice unfolds the reflected ray. Positive heights and separation ensure the reflection point lies between the tower feet. All possible Alice heights are the source task.')
    put(out,'HMMT-NOV-2023-GEN-02','n',[
        ('P1','Point(1,0)'),('P7','Point(cos(12*pi/n),sin(12*pi/n))'),('P8','Point(cos(14*pi/n),sin(14*pi/n))')],
        [eq('IsInteger(n)'),gt('n',7),eq('Angle(P1,P7,P8)','178*pi/180')],'n',
        'Unit circumradius removes similarity. Vertex order follows the regular polygon; n>=8 follows distinct source vertices.')
    put(out,'HMMT-NOV-2023-GEN-04','a b x1 x2',[
        ('A','Point(x1,x1**2)'),('B','Point(x2,x2**2)'),('M','Midpoint(A,B)')],
        [eq('A.y','a*A.x+b'),eq('B.y','a*B.x+b'),eq('M.x',5),eq('M.y',101),lt('x1','x2')],'a+b',
        'Order x1<x2 removes duplicate endpoint labellings, preserving all secant lines. Midpoint conditions are unreduced source conditions.')
    put(out,'HMMT-NOV-2023-GEN-06','ox oy r',[
        ('A','Point(0,0)'),('B','Point(5,0)'),('C','Point(5,5)'),('D','Point(0,5)'),
        ('O','Point(ox,oy)'),('omega','Circle(O,r)'),('T','ClosestPoint(O,Line(C,D))'),
        ('X','Intersect(omega,Line(A,B),exclude=A)'),('Y','Intersect(omega,Line(A,D),exclude=A)')],
        [eq('OnCircle(A,omega)'),eq('IsTangent(Line(C,D),omega)'),eq('Distance(X,Y)',6),gt('r')]+segment('T','C','D'),
        'Distance(A,T)', 'AB and AD are interpreted as their lines, matching conventional second-intersection notation; CD tangency is explicitly on the segment. Record source-segment ambiguity separately before full-set certification.')
    put(out,'HMMT-NOV-2023-THM-02','k s',[
        ('L','Point(0,0)'),('O','Point(0,s)'),('R','Point(s,s)'),('E','Point(s,0)'),('K','Point(k,0)'),('F','Point(k,s)')],
        [eq('Distance(R,L)',12),eq('Distance(R,K)',11),gt('s'),pred('k != 0')], 'Area(R,K,L)',
        'Both signs of rectangle width k are retained. Reflecting the whole configuration fixes the square to the right of LO without restricting relative placement. Adaptation: return each possible triangle area, not the product of the areas.')
    put(out,'HMMT-NOV-2023-THM-04','x y',[
        ('L','Point(0,0)'),('O','Point(23,0)'),('V','Point(23,20)'),('E','Point(0,20)'),('R','Point(x,y)'),('omega','Circumcircle(R,O,V)')],
        [eq('Distance(R,L)',23),eq('Distance(R,E)',23),pred('ConvexPolygon([L,O,V,E,R])')], 'Radius(omega)',
        'The rectangle is fixed by rigid motion; strict convexity selects the permitted side for the fifth vertex.')
    put(out,'HMMT-NOV-2023-THM-09','u v w t',[
        ('N','Point(0,0)'),('O','Point(u,0)'),('W','Point(v,w)'),('S','Point(u/3,0)'),('P','Point(2*u/3,0)'),
        ('K','Point(v/3,w/3)'),('A','Point(2*v/3,2*w/3)'),('E','Point((1-t)*u+t*v,t*w)')],
        [eq('Distance(E,P)',5),eq('Distance(E,K)',5),eq('Distance(E,A)',6),eq('Distance(E,S)',6),gt('u'),gt('w'),gt('t'),lt('t',1)],
        'Distance(O,W)', 'Trisection is constructed; E is on the open opposite side. Reflection fixes w>0. Nondegenerate triangle and pentagon are preserved.')
    put(out,'HMMT-NOV-2023-TEAM-01','',[
        ('A','Point(0,sqrt(3))'),('B','Point(-1,0)'),('C','Point(1,0)'),('M','Midpoint(A,B)'),('N','Midpoint(A,C)'),
        ('omega','Circumcircle(A,B,C)'),('X','Intersect(omega,Line(M,N),n=1)'),('Y','Intersect(omega,Line(M,N),n=2)')],
        [],'Distance(X,Y)','Fixed equilateral coordinates; the two chord endpoints are both retained and their order does not affect the target.')
    put(out,'HMMT-NOV-2023-TEAM-03','x y z',[
        ('A','Point(-x,0)'),('C','Point(x,0)'),('B','Point(0,y)'),('D','Point(0,-y)'),('E','Point(0,z)'),('F','Point(0,-z)')],
        [eq('Area(A,B,C,D)',1),eq('Area(A,E,C,F)',9),eq('y/x','x/z')]+pos('x','y','z')+[lt('y','z')],
        'Distance(A,E)','Rhombus diagonals bisect perpendicularly. Similarity must swap diagonal roles, since a same-role shared diagonal would give equal size. y/x=x/z expresses that similarity without using the answer.')
    put(out,'HMMT-NOV-2023-TEAM-07','t',[
        ('A','Point(0,0)'),('B','Point(20,0)'),('C','Point(28,21)'),('D','Point(0,21)'),('P','Point(28*t,21*t)')],
        [eq('Dot(Vector(P,B),Vector(P,D))'),gt('t'),lt('t',1)],'Distance(A,P)',
        'Perpendicularity is a signed dot product. Parameter t is positive on AC, excluding the source-forbidden endpoint A; endpoint C cannot satisfy perpendicularity.')
    put(out,'HMMT-NOV-2023-GUTS-03','',[
        ('A','Point(0,0)'),('B','Point(20,0)'),('C','Point(20,23)'),('D','Point(0,23)'),('M','Midpoint(C,D)'),('X','Reflect(M,A)')],
        [],'Area(X,B,D)','Direct rigid-motion construction of the stated rectangle and point reflection.')
    put(out,'HMMT-NOV-2023-GUTS-05','b cx cy dx dy ex ey',[
        ('A','Point(0,0)'),('B','Point(b,0)'),('C','Point(cx,cy)'),('D','Point(dx,dy)'),('E','Point(ex,ey)'),
        *[(f'M{i}',f'Midpoint({a},{z})') for i,(a,z) in enumerate(zip('ABCDE','BCDEA'))]],
        [eq('+'.join(f'Distance({a},{b})' for a,b in zip('ABCDE','BCDEA')),64),
         eq('Distance(A,C)+Distance(C,E)+Distance(E,B)+Distance(B,D)+Distance(D,A)',72),
         pred('ConvexPolygon([A,B,C,D,E])'),gt('b'),gt('cy')],
        '+'.join(f'Distance(M{i},M{(i+1)%5})' for i in range(5)),
        'Target-invariant positive-dimensional configurations retained. Normalization removes only translation, rotation and reflection; the midpoint perimeter theorem is not substituted into the target.')
    put(out,'HMMT-NOV-2023-GUTS-11','s',[
        ('A','Point(-1,1)'),('B','Point(1,1)'),('C','Point(1,-1)'),('D','Point(-1,-1)'),
        ('W','Point(-s,s)'),('X','Point(s,s)'),('Y','Point(s,-s)'),('Z','Point(-s,-s)'),
        ('P','Intersect(Line(C,X),Line(A,B))'),('Q','Intersect(Line(C,Z),Line(A,D))')],
        [eq('Collinear(P,W,Q)'),gt('s'),lt('s',1)],'Distance(A,B)/Distance(W,X)',
        'Concentric aligned squares normalized to outer half-side 1. Both source intersections remain explicit constructions with their denominator domains.')
    put(out,'HMMT-NOV-2023-GUTS-14','b c',[
        ('A','Point(0,0)'),('B','Point(5,b)'),('C','Point(6,c)'),('D','Intersect(Line(B,C),Line(A,Point(1,0)))')],
        [eq('Angle(B,A,D)','Angle(D,A,C)'),gt('b'),lt('c',0)]+segment('D','B','C',True),
        'Distance(A,D)','AD is the positive x axis, so distances to its perpendicular through A are 5 and6. Interior angle bisector forces B,C on opposite sides. One continuous shape parameter remains.')
    put(out,'HMMT-NOV-2023-GUTS-17','x y r',[
        ('A','Point(0,0)'),('B','Point(15,0)'),('C','Point(15/2,15*sqrt(3)/2)'),
        ('Ab','Point(3,0)'),('Ac','Point(3/2,3*sqrt(3)/2)'),('Ba','Point(11,0)'),
        ('Bc','Point(13,2*sqrt(3))'),('Ca','Point(5,5*sqrt(3))'),('Cb','Point(10,5*sqrt(3))'),
        ('O','Point(x,y)'),('omega','Circle(O,r)'),
        *[(f'F{i}',f'ClosestPoint(O,Line({a},{b}))') for i,(a,b) in enumerate([('Ab','Ac'),('Ba','Bc'),('Ca','Cb')])]],
        [eq(f'IsTangent(Line({a},{b}),omega)') for a,b in [('Ab','Ac'),('Ba','Bc'),('Ca','Cb')]]+
        sum([segment(f'F{i}',a,b) for i,(a,b) in enumerate([('Ab','Ac'),('Ba','Bc'),('Ca','Cb')])],[])+[gt('r')],
        'r','Corner cuts are constructed by stated side lengths. Tangency is to each specified segment via foot membership; do not replace segment tangency by unguarded line tangency.')
    put(out,'HMMT-NOV-2023-GUTS-20','',[
        ('A','Point(0,0)'),('B','Point(10,0)'),('C','Point(10,10)'),('D','Point(0,10)'),('E','Point(17,0)'),('F','Point(0,14)'),
        ('P','Intersect(ParallelLine(Line(C,E),B),ParallelLine(Line(C,F),D))')],
        [],'Area(A,E,P,F)','Source rays and parallel lines are constructed exactly, without a numerical solve.')
    put(out,'HMMT-NOV-2023-GUTS-23','x y',[
        ('A','Point(4,1/4)'),('B','Point(-5,-1/5)'),('O','Midpoint(A,B)'),('omega','Circle(O,Distance(A,B)/2)'),
        ('X','Point(x,1/x)'),('Y','Point(y,1/y)')],
        [eq('OnCircle(X,omega)'),eq('OnCircle(Y,omega)'),lt('x','y'),
         *[pred(f'{z} != {v}') for z in ('x','y') for v in ('0','4','-5')]],
        'Distance(X,Y)','Hyperbola is parametrized by its nonzero x-coordinate. A andB are excluded independently for both new intersections; x<y removes only endpoint permutation.')
    put(out,'HMMT-NOV-2023-GUTS-25','a b r',[
        ('A','Point(0,0)'),('B','Point(a,0)'),('C','Point(0,b)'),('O','Point(r,r)'),('omega','Circle(O,r)'),
        ('X','Point(27*a/28,b/28)'),('Y','Point(3*a/28,25*b/28)')],
        [eq('Distance(B,C)',28),eq('OnCircle(X,omega)'),eq('OnCircle(Y,omega)')]+pos('a','b','r')+[lt('r','a'),lt('r','b')],
        'Area(A,B,C)','Leg tangencies are constructed at positive axis feet. Source chord decomposition fixes BX=1,XY=24,YC=3 when BC=28. Swapping leg labels preserves area and covers reversed endpoint labelling.')
    put(out,'HMMT-NOV-2023-GUTS-29','x y r',[
        *[(f'A{i}',f'Point(11*sqrt(3)*cos({i}*pi/3),11*sqrt(3)*sin({i}*pi/3))') for i in range(6)],
        *[(f'B{i}',f'Point(x+r*cos({i}*pi/3),y+r*sin({i}*pi/3))') for i in range(6)]],
        [eq(f'Distance(B{i},Line(A{i},A{i+1}))',v) for i,v in enumerate((7,3,8))]+pos('r')+[lt('r','11*sqrt(3)')]+
        [gt(f'(A{(i+1)%6}.x-A{i}.x)*(B{i}.y-A{i}.y)-(A{(i+1)%6}.y-A{i}.y)*(B{i}.x-A{i}.x)') for i in range(6)],
        'r','Aligned regular hexagons have side length equal to circumradius. Positive signed gaps on all six corresponding sides enforce containment; three source gaps remain distance conditions.')
    return out


def build(destination,selection,source='HMMT'):
    if destination.exists():raise FileExistsError(destination)
    if source=='CEMC':
        from unknown_cemc import cemc
        items=cemc()
    elif source=='UKMT':
        from unknown_ukmt import ukmt
        items=ukmt()
    else:items=hmmt()
    selected=json.loads(selection.read_text());lookup={x[0]:(org,i,x) for org,rows in selected['sources'].items() for i,x in enumerate(rows)}
    from geosolver.problem.models import GeometryProblem
    from geosolver.problem.validation import validate
    for row in items:
        dsl=row['dsl'];report=validate(GeometryProblem.model_validate(dsl))
        if not report.valid:raise ValueError((dsl['id'],report))
    destination.mkdir(parents=True)
    for row in items:
        dsl=row['dsl']
        org,i,source=lookup[dsl['id']]
        row.update(source_organization=org,source_file=source[1],source_page_1based=source[2],family=source[3],split='mid' if i%2==0 else 'final')
        p=destination/'dsl'/f"{dsl['id']}.json";p.parent.mkdir(exist_ok=True)
        p.write_text(json.dumps(dsl,indent=2,ensure_ascii=False)+'\n');row['dsl_path']=str(p);row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    (destination/'semantic-manifest.json').write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'authored':len(items),'destination':str(destination),'solver_runs':0}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);p.add_argument('selection',type=Path);p.add_argument('--source',choices=['HMMT','CEMC','UKMT'],default='HMMT');a=p.parse_args();build(a.destination,a.selection,a.source)
