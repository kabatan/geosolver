"""Development interventions, with explicit semantic obligations.

These transformations are for causal experiments, not product improvements.
They do not inspect reference answers or solver outcomes.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]


def tangency_variants(dsl):
    """JMO 2013: incidence by construction gives squared tangency defects."""
    result={'original':copy.deepcopy(dsl)}
    for mode in ('direct_gap','stable_gap','projection','projection_squared','scale_only','reorder_only','redundancy_only'):
        changed=copy.deepcopy(dsl)
        if mode=='reorder_only':changed['conditions']=list(reversed(changed['conditions']))
        elif mode=='redundancy_only':changed['conditions'].append(copy.deepcopy(changed['conditions'][4]))
        else:
            for index,point,other,circle in ((4,'P','R','O1'),(5,'Q','S','O2')):
                tangent=f'Line({point},{other})'
                projection=f'(Dot(Vector({point},Center({circle})),Vector({point},{other}))/Distance({point},{other}))'
                if mode=='direct_gap':expr=f'abs(Distance(Center({circle}),{tangent})-Radius({circle}))'
                elif mode=='stable_gap':expr=f'{projection}**2/(Distance(Center({circle}),{tangent})+Radius({circle}))'
                elif mode=='projection':expr=projection
                elif mode=='projection_squared':expr=f'{projection}**2'
                else:expr=f'7 * IsTangent({tangent},{circle})'
                changed['conditions'][index]={'left':expr,'operator':'=','right':0}
        result[mode]=changed
    # θ is a genuine free coordinate on this example. Fixing it is a diagnostic
    # slice, explicitly not an equivalent representation of all configurations.
    changed=copy.deepcopy(dsl)
    changed['conditions'].append({'left':'theta','operator':'=','right':'pi/2'})
    result['theta_slice']=changed
    changed=copy.deepcopy(dsl);changed['conditions']=changed['conditions'][4:]
    result['identity_removed']=changed
    for mode in ('normal_form_squared','normal_form_linear'):
        changed=copy.deepcopy(dsl)
        for index,expression in ((4,'(p**2-2*q)/(2*p)'),(5,'(q**2-9*p)/(2*q)')):
            changed['conditions'][index]={'left':f'({expression})**2' if mode.endswith('squared') else expression,'operator':'=','right':0}
        result[mode]=changed
    return result


def common_contact_variants(dsl):
    result={'original':copy.deepcopy(dsl)}
    cross='((O1.x-M.x)*(T.y-M.y)-(O1.y-M.y)*(T.x-M.x))/Distance(O1,M)'
    foot='Dot(Vector(M,T),Vector(M,O1))/Distance(M,O1)**2'
    for mode in ('signed_contact','contact_squared','incidence_saturated','identity_removed','reorder_only','scale_only',
                 'relative_incidence','relative_external','both_relative','relative_signed_contact'):
        changed=copy.deepcopy(dsl)
        if mode=='identity_removed':changed['conditions']=changed['conditions'][3:]
        elif mode=='reorder_only':changed['conditions']=list(reversed(changed['conditions']))
        elif mode=='incidence_saturated':
            changed['conditions'][3]={'left':'t*((107/15-5)**2+12**2)-2*r1*((107/15-5)*16/65+12*63/65)','operator':'=','right':0}
        elif mode=='scale_only':
            changed['conditions'][5]={'left':'7*(Distance(O1,M)-r1-r2)','operator':'=','right':0}
        elif mode in ('relative_incidence','relative_external','both_relative','relative_signed_contact'):
            if mode in ('relative_incidence','both_relative','relative_signed_contact'):
                changed['conditions'][3]={'left':'Distance(O1,T)/r1-1','operator':'=','right':0}
            if mode in ('relative_external','both_relative'):
                changed['conditions'][5]={'left':'(Distance(O1,M)-r1-r2)/r1','operator':'=','right':0}
            elif mode=='relative_signed_contact':
                changed['conditions'][5]={'left':f'({cross})/r1','operator':'=','right':0}
                changed['conditions'] += [{'left':foot,'operator':'>','right':0},{'left':foot,'operator':'<','right':1}]
        else:
            changed['conditions'][5]={'left':cross if mode=='signed_contact' else f'({cross})**2','operator':'=','right':0}
            changed['conditions'] += [{'left':foot,'operator':'>','right':0},{'left':foot,'operator':'<','right':1}]
        result[mode]=changed
    return result


def forbidden_component_variants(dsl):
    result={'original':copy.deepcopy(dsl)}
    for mode in ('squared_distance','factored','saturated','guard_strengthened','gauge_fixed'):
        changed=copy.deepcopy(dsl)
        if mode=='guard_strengthened':
            changed['conditions'].append({'left':'Distance(B,O1)/r1','operator':'>','right':'1/2'})
        elif mode=='gauge_fixed':
            changed['variables'].remove('r1')
            changed['constructions'].insert(0,{'name':'r1','expression':'1'})
        else:
            expr={'squared_distance':'Distance(A,B)**2-r1**2',
                  'factored':'b*(b-2*Ax)','saturated':'b-2*Ax'}[mode]
            changed['conditions'][4]={'left':expr,'operator':'=','right':0}
        result[mode]=changed
    return result


OBLIGATIONS={
 'JMO-2013-PRE-05':{
   'applicability':'The constructed circle contains the designated point P/Q, and that point lies on the tested line. Both original line and circle remain nondegenerate.',
   'proof':'R^2=d^2+a^2. R-d=a^2/(R+d), and R=d iff a=0 when R+d>0. Keeping Line(P,R), Line(Q,S), Circumcircle(P,Q,S), Circumcircle(P,Q,R) preserves their exceptional domains.',
   'branches':'0<theta<pi, p,q>0; constructions exclude q=2 and p=9. Projection sign changes do not remove either orientation.',
   'slice_warning':'theta_slice changes the full configuration set; the target has an independently proved constant value along the original one-dimensional solution manifold. Report separately.',
   'contrasts':[['original','stable_gap','roundoff cancellation'],['stable_gap','projection','contact multiplicity and sign'],['projection','projection_squared','reverse intervention retaining stable evaluation'],['original','scale_only','constant scale'],['original','reorder_only','order'],['original','redundancy_only','redundancy']]},
 'HMMT-2013-FEB-GEO-04':{
   'applicability':'r1,r2,Ay>0 and b!=0 in original guards; |A|=r1 is retained.',
   'proof':'|A-B|^2-r1^2=(|A|^2-r1^2)+b(b-2Ax). Under b!=0, subtracting the retained first equation and dividing by b preserves exactly the allowed root set.',
   'guard_proof':'With u=r2/r1,z=b/r1,a=Ax/r1, u^2=2-2a, (z-1)^2=u^2, z=2a. Thus z^2-z-1=0. Every allowed root has |z|>= (sqrt(5)-1)/2 > 1/2.',
   'gauge_warning':'gauge_fixed represents equivalence classes under positive similarity; normalize physical starts by r1 and retain the inverse scale as provenance. Native starts are a separate comparison.',
   'contrasts':[['original','squared_distance','distance evaluation'],['squared_distance','factored','equation recombination'],['factored','saturated','forbidden component removal'],['original','guard_strengthened','search guard only'],['original','gauge_fixed','scale freedom only']]},
 'HMMT-2014-FEB-GEO-10':{
   'applicability':'Positive radii, t>0; first two incidences retained. M and O1 distinct. Contact foot strictly between centers.',
   'proof':'For a point T on both circles, external tangency iff T lies on the open center segment. The signed perpendicular height is zero and 0<dot(T-M,O1-M)/|O1-M|^2<1 exactly expresses this. Squaring the height preserves its zero set with identical foot guards.',
   'saturation':'Circle1 incidence squared is t*(t*|w|^2-2*r1*w.v). Because t>0 and r1>0, division by t plus retained positivity is equivalent to the original distance equation.',
   'branch_warning':'Foot guards are part of the signed-contact representation; compare contact_squared with identical guards to isolate contact multiplicity. Off-solution feasible regions differ from original.',
   'identity_removal':'A,B,C are fixed 13-14-15 coordinates. The first three equalities hold identically and removing them preserves every valid configuration.',
   'contrasts':[['original','signed_contact','contact geometry with branch guards'],['signed_contact','contact_squared','reverse multiplicity control with identical guards'],['original','incidence_saturated','excluded t=0 component'],['original','identity_removed','construction identities'],['original','reorder_only','order'],['original','scale_only','scale']]}}


def build(destination):
    if destination.exists() and any(destination.iterdir()):raise FileExistsError(destination)
    destination.mkdir(parents=True,exist_ok=True)
    manifest={}
    for ident,transform in [('JMO-2013-PRE-05',tangency_variants),('HMMT-2013-FEB-GEO-04',forbidden_component_variants),('HMMT-2014-FEB-GEO-10',common_contact_variants)]:
        dsl=json.loads((ROOT/'benchmarks/dsl'/f'{ident}.json').read_text())
        manifest[ident]={'obligations':OBLIGATIONS[ident],'variants':{}}
        for name,changed in transform(dsl).items():
            from geosolver.problem.models import GeometryProblem
            from geosolver.problem.validation import validate
            problem=GeometryProblem.model_validate(changed)
            report=validate(problem)
            if not report.valid:raise ValueError(report)
            target=destination/ident/f'{name}.json';target.parent.mkdir(parents=True,exist_ok=True)
            payload=json.dumps(changed,ensure_ascii=False,indent=2)+'\n';target.write_text(payload)
            manifest[ident]['variants'][name]={'path':str(target),'sha256':hashlib.sha256(payload.encode()).hexdigest()}
    (destination/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'variants':sum(len(v['variants']) for v in manifest.values()),'destination':str(destination)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);build(p.parse_args().destination)
