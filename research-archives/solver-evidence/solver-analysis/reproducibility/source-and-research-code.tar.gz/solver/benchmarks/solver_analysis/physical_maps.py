"""Independent maps between authored contact coordinates and physical objects.

No solver, reference file or optimization is imported. Every real sheet is
enumerated, including sheets violating segment guards (marked, not deleted).
Maps use arbitrary precision values and return exact-codec-compatible objects.
"""
from __future__ import annotations
import itertools
from mpmath import mp


def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(a,t):return tuple(x*t for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def norm(a):return mp.sqrt(dot(a,a))


def circle(a,b,c):
    v=sub(b,a);w=sub(c,a);det=2*cross(v,w)
    if det==0:raise ValueError('collinear circle points')
    z=((dot(v,v)*w[1]-dot(w,w)*v[1])/det,
       (v[0]*dot(w,w)-w[0]*dot(v,v))/det)
    return add(a,z),norm(z),abs(cross(v,w))/(norm(v)*norm(w))


def line(a,b):
    v=sub(b,a);length=norm(v)
    if not length:raise ValueError('coincident line points')
    normal=(-v[1]/length,v[0]/length);offset=dot(normal,a)
    # Canonical orientation independent of endpoint order.
    if normal[0]<0 or (normal[0]==0 and normal[1]<0):normal=mul(normal,-1);offset=-offset
    return normal,offset,length


def meet(l,r):
    a,p=l[:2];b,q=r[:2];det=cross(a,b)
    if det==0:raise ValueError('parallel lines')
    return ((p*b[1]-q*a[1])/det,(a[0]*q-b[0]*p)/det)


def segment_parameter(p,a,b):
    v=sub(b,a);length2=dot(v,v)
    if not length2:raise ValueError('zero segment')
    t=dot(sub(p,a),v)/length2
    return t,min(t,1-t),abs(cross(sub(p,a),v))/length2


def intersections(center,radius,a,b):
    v=sub(b,a);length=norm(v);unit=mul(v,1/length)
    along=dot(sub(center,a),unit);foot=add(a,mul(unit,along));gap=radius*radius-dot(sub(foot,center),sub(foot,center))
    if gap<0:return [],{'status':'no_real_lift','discriminant':gap}
    signs=(0,) if gap==0 else (-1,1)
    out=[]
    for sign in signs:
        p=add(foot,mul(unit,sign*mp.sqrt(gap)));t,margin,_=segment_parameter(p,a,b)
        out.append({'point':p,'t':t,'sheet_sign':sign,'segment_margin':margin})
    return out,{'status':'tangent' if gap==0 else 'secant','discriminant':gap,'foot':foot,
                'foot_segment_margin':segment_parameter(foot,a,b)[1]}


def cuts():
    q=mp.sqrt(3)
    return [((mp.mpf(3),mp.mpf(0)),(mp.mpf('1.5'),mp.mpf('1.5')*q)),
            ((mp.mpf(11),mp.mpf(0)),(mp.mpf(13),2*q)),
            ((mp.mpf(5),5*q),(mp.mpf(10),5*q))]


def triangle_from_lines(L,R):
    C=meet(L,R);M=meet(L,((mp.mpf(0),mp.mpf(1)),mp.mpf(-4)));N=meet(R,((mp.mpf(0),mp.mpf(1)),mp.mpf(-4)))
    signed_area=(N[0]-M[0])*(C[1]+4)/2
    return {'C':C,'M':M,'N':N,'area':abs(signed_area),
        'source_orientation':bool(M[0]<0<N[0] and C[1]>6),
        'line_pair_margin':abs(cross(L[0],R[0])),
        'bottom_intersection_margin':min(abs(L[0][0]),abs(R[0][0]))}


def constructed_to_physical(case_id,values):
    if case_id=='HMMT-NOV-2023-GEN-06':
        x,t=values;u=x/2;v=(t*t-t*x+25)/10;r=mp.sqrt(u*u+v*v)
        return {'original_coordinates':(u,v,r),'center':(u,v),'radius':r,
            'contact_sheet':mp.sign(u-t),'auxiliary_point':(t,mp.mpf(5)),
            'physical_foot':(u,mp.mpf(5)),
            'auxiliary_goal':mp.sqrt(t*t+25),'physical_goal':mp.sqrt(u*u+25),
            'constructed_segment_margin':min(t,5-t)/5,'original_segment_margin':min(u,5-u)/5,
            'circle_construction_margin':abs(x*5)/(max(1,abs(x))*mp.sqrt(t*t+25))}
    if case_id=='HMMT-NOV-2023-GUTS-17':
        points=[add(a,mul(sub(b,a),t)) for (a,b),t in zip(cuts(),values)]
        O,R,margin=circle(*points)
        foot_margins=[]
        for a,b in cuts():
            unit=mul(sub(b,a),1/norm(sub(b,a)));foot=add(a,mul(unit,dot(sub(O,a),unit)))
            foot_margins.append(segment_parameter(foot,a,b)[1])
        return {'original_coordinates':(*O,R),'center':O,'radius':R,'physical_goal':R,
            'constructed_points':points,'circle_construction_margin':margin,
            'constructed_segment_margins':[min(t,1-t) for t in values],'original_segment_margins':foot_margins}
    if case_id=='CEMC-EUCLID-2024-08A':
        points=[(4*mp.cos(values[0]),4*mp.sin(values[0])),(3*mp.cos(values[1]),3+3*mp.sin(values[1])),
                (4*mp.cos(values[2]),4*mp.sin(values[2])),(3*mp.cos(values[3]),3+3*mp.sin(values[3]))]
        L=line(*points[:2]);R=line(*points[2:]);tri=triangle_from_lines(L,R)
        margins=[segment_parameter(p,tri['C'],tri[end])[1] for p,end in zip(points,('M','M','N','N'))]
        return {'original_coordinates':(*tri['C'],tri['M'][0],tri['N'][0]),'left_line':L,'right_line':R,
            'physical_goal':tri['area'],'constructed_points':points,'segment_margins':margins,
            'point_separation_margins':[L[2]/7,R[2]/7],**tri}
    raise ValueError(case_id)


def all_lifts(case_id,physical):
    if case_id=='HMMT-NOV-2023-GEN-06':
        u,v,r=physical;incidence=r*r-u*u-v*v
        if abs(incidence)>100*mp.eps*max(1,r*r,u*u+v*v):
            return {'status':'no_incidence_lift','incidence_residual':incidence,'sheets':[]}
        gap=10*v+u*u-25
        if gap<0:return {'status':'no_real_lift','discriminant':gap,'sheets':[]}
        signs=(0,) if gap==0 else (-1,1)
        return {'status':'real_lifts','discriminant':gap,'sheets':[
            {'values':(2*u,u+sign*mp.sqrt(gap)),'sheet':(sign,),
             'segment_feasible':bool(0<=u+sign*mp.sqrt(gap)<=5)} for sign in signs]}
    if case_id=='HMMT-NOV-2023-GUTS-17':
        O=tuple(physical[:2]);R=physical[2];sets=[];receipts=[]
        for a,b in cuts():
            points,receipt=intersections(O,R,a,b);sets.append(points);receipts.append(receipt)
        sheets=[{'values':tuple(p['t'] for p in row),'sheet':tuple(p['sheet_sign'] for p in row),
            'segment_feasible':all(p['segment_margin']>=0 for p in row)} for row in itertools.product(*sets)]
        return {'status':'real_lifts' if sheets else 'no_real_lift','line_receipts':receipts,'sheets':sheets}
    if case_id=='CEMC-EUCLID-2024-08A':
        cx,cy,m,n=physical;C=(cx,cy);M=(m,mp.mpf(-4));N=(n,mp.mpf(-4));sets=[];receipts=[]
        for end in (M,N):
            for O,R in (((mp.mpf(0),mp.mpf(0)),mp.mpf(4)),((mp.mpf(0),mp.mpf(3)),mp.mpf(3))):
                points,receipt=intersections(O,R,C,end)
                for p in points:p['angle']=mp.atan2(p['point'][1]-O[1],p['point'][0]-O[0])
                sets.append(points);receipts.append(receipt)
        sheets=[{'values':tuple(p['angle'] for p in row),'sheet':tuple(p['sheet_sign'] for p in row),
            'segment_feasible':all(p['segment_margin']>0 for p in row)} for row in itertools.product(*sets)]
        return {'status':'real_lifts' if sheets else 'no_real_lift','line_receipts':receipts,'sheets':sheets}
    raise ValueError(case_id)
