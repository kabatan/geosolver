"""Fixed common starts, NOMAD or standard SciPy, and the same HP backend.

This is an instrumented stage experiment, not the ordinary 180-second pipeline.
All original-domain rejections and actual residual calls are retained. The same
explicit bounds and original-residual start pool are shared by all arms.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import random
import time
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from exact_codec import dumps,loads
from paired_stages import bundle_of,run_point,WorkLimit
from stage_replay import ensure_source
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.evaluation.classify_evaluation_failure import EvaluationStatus
from geosolver.engine.standard.problem.infer_problem_bounds import infer_problem_bounds
from geosolver.engine.standard.search.nomad_backend import NomadBackend
from geosolver.engine.standard.search.nomad_config import NomadConfig
from geosolver.runtime.deadline import runtime_session

CONFIG={'seed':20260912,'proposals':64,'starts':16,'actual_calls_per_start':256,
        'hp_candidates':4,'hp_candidate_safety_seconds':30,'search_safety_seconds':120,
        'hp_iterations':80,'hp_dps':120,'dedup_relative_distance':1e-6}


def prepare(dsl):
    start=time.monotonic();bundle=bundle_of(dsl);e=build_ir_evaluator(bundle)
    bounds=infer_problem_bounds(bundle);rng=random.Random(CONFIG['seed']);rows=[]
    for i in range(CONFIG['proposals']):
        x=tuple(rng.uniform(a,b) for a,b in bounds);v=e.evaluate_float_residual(x)
        rows.append({'index':i,'x':x,'valid':v.evaluation_status is EvaluationStatus.OK,
            'status':v.evaluation_status.value,'norm':v.residual_norm_float})
    selected=[r['index'] for r in rows if r['valid']][:CONFIG['starts']]
    return {'config':CONFIG,'case_id':dsl['id'],'dsl':dsl,'bounds':bounds,'proposals':rows,'selected_indices':selected,
        'selection':'first sixteen evaluable original-representation proposals, independent of residual size, guard, reference or outcome',
        'seconds':time.monotonic()-start,'residual_calls':len(rows),'source_hash':ensure_source()}


def run(dsl,pool,backend,hp_dsl=None):
    if ensure_source()!=pool['source_hash']:raise ValueError('source changed')
    if CONFIG!=pool['config']:raise ValueError('pool configuration differs')
    hp_dsl=dsl if hp_dsl is None else hp_dsl
    bundle=bundle_of(dsl);e=build_ir_evaluator(bundle);bounds=pool['bounds'];rows=[];search=[]
    if bundle.var_names!=bundle_of(pool['dsl']).var_names or bundle.var_names!=bundle_of(hp_dsl).var_names:
        raise ValueError('common multistart requires identical coordinates; use physical maps otherwise')
    if not bundle.var_names:
        raise ValueError('Zero-variable input: no multistart optimization task. Use the production direct-evaluation route; retain any earlier attempted diagnostic as inapplicable.')
    starts=[pool['proposals'][i]['x'] for i in pool['selected_indices']]
    begun=time.monotonic();active_start=0
    class Proxy:
        def __getattr__(self,name):return getattr(e,name)
        def evaluate_float_residual(self,x):
            v=e.evaluate_float_residual(x);ok=v.evaluation_status is EvaluationStatus.OK
            guard=e.evaluate_guard(x)[0] if ok else False
            hard=e.evaluate_float_hard_feasibility(x,include_margins=False).hard_feasible if ok else False
            rows.append({'x':tuple(float(z) for z in x),'valid':ok,'guard':guard,'hard':hard,
                'status':v.evaluation_status.value,'norm':v.residual_norm_float,'start_index':active_start,
                'residual_vector':v.residual_vector if ok else None})
            return v
    proxy=Proxy()
    lo=np.array([a for a,b in bounds]);hi=np.array([b for a,b in bounds])
    with runtime_session(begun+CONFIG['search_safety_seconds']) as timing:
        for j,x in enumerate(starts):
            active_start=j;before=len(rows);t0=time.monotonic()
            record={'start_index':j,'start':x,'backend':backend,'seed':CONFIG['seed']+j}
            try:
                if backend=='nomad':
                    config=NomadConfig(max_bb_eval=CONFIG['actual_calls_per_start'],max_time_sec=None,
                        seed_values=(CONFIG['seed']+j,),bound_expansion_ratio=0,
                        keep_per_run=CONFIG['actual_calls_per_start'],keep_after_dedup=CONFIG['actual_calls_per_start'])
                    result=NomadBackend(config=config,start_points=(list(x),)).run_search(
                        bundle=bundle,evaluator=proxy,bounds=bounds,search_mode='disco_mads')
                    record.update(status='completed',native_evaluation_count=result.evaluation_count)
                else:
                    def fun(y):
                        if len(rows)-before>=CONFIG['actual_calls_per_start']:raise WorkLimit('actual residual call cap')
                        v=proxy.evaluate_float_residual(y)
                        return np.array(v.residual_vector) if v.evaluation_status is EvaluationStatus.OK else np.full(len(bundle.targets),1e6)
                    result=least_squares(fun,np.array(x),bounds=(lo,hi),x_scale='jac',ftol=1e-12,xtol=1e-12,gtol=1e-12,
                        max_nfev=CONFIG['actual_calls_per_start'])
                    record.update(status=int(result.status),scipy_nfev=int(result.nfev),scipy_njev=int(result.njev or 0))
            except WorkLimit:record['status']='actual_call_limit'
            except Exception as exc:record.update(status='error',error=type(exc).__name__+': '+str(exc))
            record.update(actual_residual_calls=len(rows)-before,seconds=time.monotonic()-t0)
            search.append(record)
            if time.monotonic()-begun>=CONFIG['search_safety_seconds']:break
    search_seconds=time.monotonic()-begun
    eligible=sorted((r for r in rows if r['valid']),key=lambda r:(not(r['guard'] and r['hard']),r['norm']))
    selected=[];spans=[max(1,b-a) for a,b in bounds]
    for r in eligible:
        if any(sum(((x-y)/s)**2 for x,y,s in zip(r['x'],v['x'],spans))**.5<CONFIG['dedup_relative_distance'] for v in selected):continue
        selected.append(r)
        if len(selected)>=CONFIG['hp_candidates']:break
    hp=[]
    for j,r in enumerate(selected):
        point={'x':r['x'],'uid':f'common/{backend}/{r["start_index"]}/{j}',
            'external_seed':CONFIG['seed'],'source_revision':0,'origin_start_index':r['start_index']}
        hp.append(run_point(dsl=hp_dsl,original=pool['dsl'],point=point,engine='native_refine',
            dps=CONFIG['hp_dps'],iterations=CONFIG['hp_iterations'],seconds=CONFIG['hp_candidate_safety_seconds'],
            damping=None,rank_cap=None,verify=True))
    return {'schema':1,'kind':'instrumented fixed-work multistart plus common native HP',
        'source_hash':ensure_source(),'config':CONFIG,'intervention_dsl':dsl,'hp_dsl':hp_dsl,'backend':backend,
        'common_pool':pool,'search':search,'search_trace':rows,'search_seconds':search_seconds,
        'search_safety_censored':search_seconds>=CONFIG['search_safety_seconds'],
        'unprocessed_start_indices':list(range(len(search),len(starts))),
        'search_residual_calls':len(rows),'search_counters':timing.counters,
        'selected_hp_inputs':selected,'hp_results':hp,'total_seconds':time.monotonic()-begun,
        'limitations':['Shared starts are conditional on original construction evaluability.',
            'The diagnostic selection rule is common to both backends but differs from the full production ledger.',
            'HP is a fresh restart with fresh caches; verifier coordinates are saved separately.',
            'Actual calls, precision and elapsed time are reported; one call is not a constant cost across representations.']}


if __name__=='__main__':
    p=argparse.ArgumentParser();s=p.add_subparsers(dest='mode',required=True)
    q=s.add_parser('prepare');q.add_argument('dsl',type=Path);q.add_argument('output',type=Path)
    q=s.add_parser('run');q.add_argument('dsl',type=Path);q.add_argument('pool',type=Path);q.add_argument('output',type=Path);q.add_argument('--backend',choices=['nomad','scipy'],required=True);q.add_argument('--hp-dsl',type=Path)
    a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    dsl=json.loads(a.dsl.read_text())
    result=prepare(dsl) if a.mode=='prepare' else run(dsl,loads(a.pool.read_text()),a.backend,json.loads(a.hp_dsl.read_text()) if a.hp_dsl else None)
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(dumps(result)+'\n')
    print(json.dumps({'output':str(a.output),'mode':a.mode,'seconds':result.get('total_seconds',result.get('seconds')),
        'starts':len(result.get('selected_indices',result.get('search',[])))}))
