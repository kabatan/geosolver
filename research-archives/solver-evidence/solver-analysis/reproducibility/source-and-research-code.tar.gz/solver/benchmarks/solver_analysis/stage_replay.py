"""Reference-blind capture and replay of the frozen GeoSolver's stages.

Capture is diagnostic, never a wall-time benchmark. Numerical calls are
forwarded unchanged; serialization happens after the run. Full evaluation
inputs, actual backend starts, candidate pools, revisions and stage cutoffs
are retained. Replay creates fresh evaluators and caches.
"""

from __future__ import annotations

import argparse
import copy
import importlib
import json
import time
from contextlib import ExitStack
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from mpmath import mp

from exact_codec import dumps, loads, validate_roundtrip
from geosolver.engine.standard.contracts.external_pipeline_config import ExternalPipelineConfig
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator, IREvaluator
from geosolver.engine.standard.evaluation.final_verifier import verify_final_candidate
from geosolver.engine.standard.orchestration.run_external_pipeline import run_external_pipeline
from geosolver.engine.standard.problem.load_problem_bundle import load_problem_bundle
from geosolver.engine.standard.refinement.mpmath_refiner import MpmathRefiner
from geosolver.engine.standard.search.nomad_backend import NomadBackend
from geosolver.engine.standard.search.scipy_multistart_backend import ScipyMultistartBackend
from geosolver.problem.models import GeometryProblem
from geosolver.runtime.deadline import runtime_session
from geosolver.runtime.integrity import source_tree_hash
from geosolver.runtime.worker import _json_value

EXPECTED_SOURCE = 'sha256:6d59d43c8bcbe882e0cf35457e1671ed7ef94a421b6c67c8c98268308f2fe758'


def ensure_source():
    actual=source_tree_hash()
    if actual.removeprefix('sha256:') != EXPECTED_SOURCE.removeprefix('sha256:'):
        raise RuntimeError(f'Product baseline changed: {actual}')
    return actual


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(dumps(value)+'\n')


def capture(dsl,seed,seconds,instrument=True,detailed_refinement=False):
    identity=ensure_source()
    problem=GeometryProblem.model_validate(dsl)
    document=problem.engine_document()
    trace=[]; evaluation_inputs=[]
    started=time.monotonic(); deadline=started+seconds
    def wrapped(original,kind,prepare,*,exact_output=True):
        def call(*args,**kwargs):
            entry={'kind':kind,'sequence':len(trace),'started_after_seconds':time.monotonic()-started,
                   'input':prepare(args,kwargs),'ambient_dps':mp.dps,'status':'running'}
            trace.append(entry)
            try:
                output=original(*args,**kwargs)
                entry['output']=output if exact_output else _json_value(output)
                entry['status']='completed'
                return output
            except BaseException as exc:
                entry['status']='interrupted' if isinstance(exc,TimeoutError) else 'error'
                entry['error']=type(exc).__name__+': '+str(exc)
                raise
            finally:
                entry['completed_after_seconds']=time.monotonic()-started
        return call
    def backend_inputs(args,kwargs):
        self=args[0]
        return {'backend':type(self).__name__,'config':self.config,
                'start_points':copy.deepcopy(self.start_points),
                'constraint_scales':self.constraint_scales,
                **{k:copy.deepcopy(v) for k,v in kwargs.items() if k not in ('bundle','evaluator')}}
    def refinement_inputs(args,kwargs):
        return {'config':args[0].config,'candidates':tuple(kwargs['candidates']),
                'deadline_remaining':None if kwargs.get('deadline_monotonic') is None else kwargs['deadline_monotonic']-time.monotonic()}
    pipeline_module=importlib.import_module('geosolver.engine.standard.orchestration.run_external_pipeline')
    assembly_module=importlib.import_module('geosolver.engine.standard.orchestration.assemble_exact_results')
    refiner_module=importlib.import_module('geosolver.engine.standard.refinement.mpmath_refiner')
    scalar_module=importlib.import_module('geosolver.engine.standard.search.scalar_branch_scan')
    original_float=IREvaluator.evaluate_float_residual
    def record_float(self,values):
        entry={'sequence':len(evaluation_inputs),'values':tuple(values),'status':'running'}
        evaluation_inputs.append(entry)
        try:
            result=original_float(self,values)
            entry['status']=result.evaluation_status.value
            entry['residual_vector']=tuple(result.residual_vector)
            return result
        except BaseException as exc:
            entry['status']=type(exc).__name__
            raise
    result=None; error=None
    with ExitStack() as stack:
        if instrument:
            stack.enter_context(patch.object(IREvaluator,'evaluate_float_residual',record_float))
            for cls in (NomadBackend,ScipyMultistartBackend):
                stack.enter_context(patch.object(cls,'run_search',wrapped(cls.run_search,'search',backend_inputs)))
            stack.enter_context(patch.object(scalar_module,'scan_scalar_branches',wrapped(
                scalar_module.scan_scalar_branches,'scalar_search',lambda a,k:{n:loads(dumps(v)) for n,v in k.items() if n!='evaluator'})))
            stack.enter_context(patch.object(MpmathRefiner,'refine_candidates',wrapped(MpmathRefiner.refine_candidates,'refine',refinement_inputs)))
            stack.enter_context(patch.object(pipeline_module,'run_initial_probe',wrapped(
                pipeline_module.run_initial_probe,'probe',lambda a,k:{n:copy.deepcopy(v) for n,v in k.items() if n!='evaluator'})))
            stack.enter_context(patch.object(assembly_module,'verify_final_candidate',wrapped(
                assembly_module.verify_final_candidate,'verify',lambda a,k:{n:tuple(v) if n=='values' else copy.deepcopy(v) for n,v in k.items() if n!='evaluator'},exact_output=False)))
            stack.enter_context(patch.object(assembly_module,'identify_answer',wrapped(
                assembly_module.identify_answer,'exactify',lambda a,k:{'args':tuple(a),'kwargs':copy.deepcopy(k)},exact_output=False)))
            if detailed_refinement:
                stack.enter_context(patch.object(MpmathRefiner,'_run_stage',wrapped(
                    MpmathRefiner._run_stage,'lm_stage',lambda a,k:{n:loads(dumps(v)) for n,v in k.items() if n not in ('bundle','evaluator','residual_fn','integer_closures')})))
                stack.enter_context(patch.object(refiner_module,'compute_levenberg_marquardt_step',wrapped(
                    refiner_module.compute_levenberg_marquardt_step,'lm_step',lambda a,k:copy.deepcopy(k))))
                stack.enter_context(patch.object(refiner_module,'_select_rank_revealing_subsystem',wrapped(
                    refiner_module._select_rank_revealing_subsystem,'rank_chart',lambda a,k:{'args':copy.deepcopy(a),'kwargs':copy.deepcopy(k)})))
        with mp.workdps(180),runtime_session(deadline) as timings:
            config=ExternalPipelineConfig.production_baseline_tier(seed=seed,total_time_budget_sec=seconds)
            try:
                result=run_external_pipeline(document,seed=seed,pipeline_config=config,deadline_monotonic=deadline)
            except TimeoutError as exc:
                error=type(exc).__name__+': '+str(exc)
            except Exception as exc:
                error=type(exc).__name__+': '+str(exc)
            elapsed=time.monotonic()-started
            retained=tuple(timings.candidates.values())
    return {'schema':1,'source_hash':identity,'dsl':dsl,'seed':seed,'instrumented':instrument,
            'budget_seconds':seconds,'elapsed_seconds':elapsed,'error':error,
            'numeric_roundtrip_receipt':validate_roundtrip(),'trace':trace,
            'float_evaluations':evaluation_inputs,'retained_candidates':retained,
            'result':None if result is None else _json_value(result),
            'counters':timings.counters,'phase_seconds':dict(timings)}


def replay(record,event_index,*,dsl=None,order='original',limit=None,seconds=180,fixed_work=False,backend=None):
    ensure_source()
    event=record['trace'][event_index]
    if event['status']!='completed':
        raise ValueError('Cannot treat an interrupted stage as a completed replay baseline')
    problem=GeometryProblem.model_validate(dsl or record['dsl'])
    bundle=load_problem_bundle(problem.engine_document());evaluator=build_ir_evaluator(bundle)
    kind=event['kind'];inputs=event['input']
    started=time.monotonic();deadline=started+seconds
    with mp.workdps(event['ambient_dps']),runtime_session(deadline) as timings:
        if kind=='search':
            cls={'NomadBackend':NomadBackend,'ScipyMultistartBackend':ScipyMultistartBackend}[backend or inputs['backend']]
            config=inputs['config']
            if fixed_work:config=replace(config,max_time_sec=None)
            runner=cls(config=config,start_points=inputs['start_points'],constraint_scales=inputs['constraint_scales'])
            output=runner.run_search(bundle=bundle,evaluator=evaluator,bounds=inputs['bounds'],
                search_mode='scipy_multistart' if cls is ScipyMultistartBackend else inputs['search_mode'],
                guard_feasible_prefix_count=inputs['guard_feasible_prefix_count'])
        elif kind=='scalar_search':
            from geosolver.engine.standard.search.scalar_branch_scan import scan_scalar_branches
            output=scan_scalar_branches(evaluator=evaluator,**inputs)
        elif kind=='probe':
            from geosolver.engine.standard.orchestration.run_initial_probe import run_initial_probe
            output=run_initial_probe(evaluator=evaluator,**inputs)
        elif kind=='refine':
            candidates=inputs['candidates']
            if order=='reverse':candidates=tuple(reversed(candidates))
            if limit is not None:candidates=candidates[:limit]
            stage_deadline=deadline if fixed_work or inputs['deadline_remaining'] is None else min(deadline,started+inputs['deadline_remaining'])
            output=MpmathRefiner(config=inputs['config']).refine_candidates(
                bundle=bundle,evaluator=evaluator,candidates=candidates,deadline_monotonic=stage_deadline)
        elif kind=='verify':
            output=_json_value(verify_final_candidate(evaluator=evaluator,**inputs))
        elif kind=='exactify':
            from geosolver.engine.standard.exact_assembly.identify_answer import identify_answer
            output=_json_value(identify_answer(*inputs['args'],**inputs['kwargs']))
        else:raise ValueError(kind)
    return {'schema':1,'source_hash':ensure_source(),'kind':kind,'source_event':event_index,
            'input':inputs,'intervention':{'different_dsl':dsl is not None,'order':order,'limit':limit,
                'fixed_work_requested':fixed_work,'safety_deadline_seconds':seconds,'backend':backend},
            'output':output,'elapsed_seconds':time.monotonic()-started,'counters':timings.counters,
            'phase_seconds':dict(timings),'same_encoded_output':dumps(output)==dumps(event['output'])}


def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='mode',required=True)
    cap=sub.add_parser('capture');cap.add_argument('dsl',type=Path);cap.add_argument('output',type=Path)
    cap.add_argument('--seed',type=int,default=0);cap.add_argument('--seconds',type=float,default=180)
    cap.add_argument('--no-instrument',action='store_true')
    cap.add_argument('--detailed-refinement',action='store_true')
    rep=sub.add_parser('replay');rep.add_argument('capture',type=Path);rep.add_argument('event',type=int);rep.add_argument('output',type=Path)
    rep.add_argument('--dsl',type=Path);rep.add_argument('--order',choices=['original','reverse'],default='original')
    rep.add_argument('--limit',type=int);rep.add_argument('--seconds',type=float,default=180)
    rep.add_argument('--fixed-work',action='store_true');rep.add_argument('--backend',choices=['NomadBackend','ScipyMultistartBackend'])
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError('Stage artifacts are immutable: '+str(args.output))
    if args.mode=='capture':
        result=capture(json.loads(args.dsl.read_text()),args.seed,args.seconds,not args.no_instrument,args.detailed_refinement)
    else:
        result=replay(loads(args.capture.read_text()),args.event,dsl=None if args.dsl is None else json.loads(args.dsl.read_text()),
            order=args.order,limit=args.limit,seconds=args.seconds,fixed_work=args.fixed_work,backend=args.backend)
    save(args.output,result)
    print(json.dumps({'output':str(args.output),'mode':args.mode,'elapsed':result['elapsed_seconds'],
        'events':len(result.get('trace',[])),'same_output':result.get('same_encoded_output'),'error':result.get('error')}))


if __name__=='__main__':main()
