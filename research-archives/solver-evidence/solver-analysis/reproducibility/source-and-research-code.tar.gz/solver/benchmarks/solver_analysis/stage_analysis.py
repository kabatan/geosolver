"""Post-run analytic assessment of paired-stage outputs, including failures."""
import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import Counter,defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from natural_evidence import jmo,hmmt,original_conditions
from paired_stages import bundle_of
from stationary_check import check
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator


def digits(value):
    try:
        v=abs(mp.mpf(value))
        return float(min(mp.mpf(550),-mp.log10(v))) if v else 550.
    except Exception:return None


def analyze(campaign,destination,stationary=False):
    if destination.exists():raise FileExistsError(destination)
    completion=json.loads((campaign/'completion.json').read_text())
    if completion['completed']!=completion['planned']:raise ValueError('incomplete campaign')
    destination.mkdir(parents=True);rows=[];errors=[];evaluators={};stationary_rows=[]
    for groupfile in sorted((campaign/'runs').glob('*/*/execution.json')):
        for execution in json.loads(groupfile.read_text()):
            p=Path(execution['output']);ident=execution['case_id']
            row={k:execution[k] for k in ('case_id','point_index','condition','cpu','process_seconds','exit_code')}
            if not p.exists():row['output_missing']=True;rows.append(row);continue
            r=loads(p.read_text());verify=r.get('verification');isdict=isinstance(verify,dict)
            row.update(status=r['status'],error=r['error'],numeric_seconds=r['numeric_seconds'],
                verification_seconds=r['verification_seconds'],numeric_float_calls=r['numeric_calls']['float'],
                numeric_hp_calls=r['numeric_calls']['hp'],actual_hp_calls=r['actual_calls']['hp'],
                safety_censored=r['safety_deadline_hit'],verification_censored=r['verification_deadline_hit'],
                verified=getattr(verify,'verified',False),verification_status=getattr(verify,'status',verify.get('error') if isdict else None),
                verification_dps=getattr(verify,'precision_dps',None),
                source_uid=r['point']['uid'],external_seed=r['point']['external_seed'],
                lm_steps=sum(t['kind']=='lm_step' for t in r['trace']),
                rank_charts=sum(t['kind']=='rank_chart' for t in r['trace']),
                output_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            fn=jmo if ident.startswith('JMO') else hmmt
            with mp.workdps(600):
                try:
                    initial=fn([mp.mpf(v) for v in r['point']['x']]);pre=fn(r['pre_verifier_point'])
                    post=fn(verify.values) if not isdict and getattr(verify,'values',None) else None
                    scipy=next((t['x'] for t in r['trace'] if t['kind']=='scipy_result'),None)
                    key='goal_error' if ident.startswith('JMO') else 'legal_goal_error'
                    for prefix,val in [('initial',initial),('scipy_only',fn(scipy) if scipy else None),('pre_verifier',pre),('post_verifier',post)]:
                        if val is None:continue
                        row[prefix+'_goal_digits']=digits(val[key]);row[prefix+'_geometry']=val
                    row['gain_goal_digits']=row['pre_verifier_goal_digits']-row['initial_goal_digits']
                    if ident.startswith('JMO'):
                        row['initial_region']='angle_boundary' if abs(mp.mpf(initial['sin_theta']))<mp.mpf('.05') else 'interior_angle'
                    else:
                        # Input-scale boundary diagnostic, not reference-value classification.
                        row['initial_region']='radius_boundary' if abs(mp.mpf(initial['r1']))<mp.mpf('.001') else 'positive_radius'
                    row['pre_verifier_20digit_goal']=row['pre_verifier_goal_digits']>=20
                    row['post_verifier_20digit_goal']=row.get('post_verifier_goal_digits',-math.inf)>=20
                    row['scipy_only_20digit_goal']=row.get('scipy_only_goal_digits',-math.inf)>=20
                    for prefix,point in [('scipy_only',scipy),('pre_verifier',r['pre_verifier_point'])]:
                        if point is None:continue
                        independent=original_conditions(ident,point)
                        row[prefix+'_independent_original_check']=independent
                        row[prefix+'_independent_conditions_and_20digit_goal']=independent['passed'] and row.get(prefix+'_20digit_goal',False)
                    if stationary:
                        if ident not in evaluators:evaluators[ident]=build_ir_evaluator(bundle_of(r['original_dsl']))
                        for prefix,point in [('scipy_only',scipy),('pre_verifier',r['pre_verifier_point'])]:
                            if point is None:continue
                            checked=check(evaluators[ident],point)
                            row[prefix+'_numeric_conditions']=checked['numeric_conditions_passed']
                            row[prefix+'_conditions_and_20digit_goal']=checked['numeric_conditions_passed'] and row.get(prefix+'_20digit_goal',False)
                            stationary_rows.append({'case_id':ident,'point_index':r['point_index'] if 'point_index' in r else execution['point_index'],
                                'condition':execution['condition'],'stage':prefix,'point':point,'assessment':checked})
                except Exception as ex:errors.append({'path':str(p),'error':type(ex).__name__+': '+str(ex)});row['analytic_error']=str(ex)
            rows.append(row)
    grouped=defaultdict(list)
    for row in rows:grouped[(row['case_id'],row['condition'])].append(row)
    summaries=[]
    for (ident,condition),values in sorted(grouped.items()):
        def med(key):
            v=[r[key] for r in values if r.get(key) is not None]
            return statistics.median(v) if v else None
        summaries.append({'case_id':ident,'condition':condition,'n':len(values),
            'verified':sum(r.get('verified',False) for r in values),
            'pre_20digit_goal':sum(r.get('pre_verifier_20digit_goal',False) for r in values),
            'post_20digit_goal':sum(r.get('post_verifier_20digit_goal',False) for r in values),
            'scipy_only_20digit_goal':sum(r.get('scipy_only_20digit_goal',False) for r in values),
            'pre_independent_conditions_and_20digit_goal':sum(r.get('pre_verifier_independent_conditions_and_20digit_goal',False) for r in values),
            'pre_independent_numeric_conditions':sum(r.get('pre_verifier_independent_original_check',{}).get('passed',False) for r in values),
            'scipy_only_numeric_conditions':sum(r.get('scipy_only_numeric_conditions',False) for r in values) if stationary else None,
            'pre_numeric_conditions':sum(r.get('pre_verifier_numeric_conditions',False) for r in values) if stationary else None,
            'pre_conditions_and_20digit_goal':sum(r.get('pre_verifier_conditions_and_20digit_goal',False) for r in values) if stationary else None,
            'censored':sum(r.get('safety_censored',False) for r in values),
            'status':dict(Counter(str(r.get('status')) for r in values)),
            **{'median_'+k:med(k) for k in ('numeric_seconds','numeric_hp_calls','numeric_float_calls','scipy_only_goal_digits','pre_verifier_goal_digits','post_verifier_goal_digits','gain_goal_digits','lm_steps')}})
    lookup={(r['case_id'],r['point_index'],r['condition']):r for r in rows};pairs=[]
    for r in rows:
        name=r['condition'];ident=r['case_id']
        # Paired against the same engine and precision; preserve both failures.
        suffix=name.split('__',1)[1]
        baseline='original__'+suffix
        if suffix.startswith('damping_') or suffix.startswith('rank_'):baseline='original__native_refine'
        b=lookup.get((ident,r['point_index'],baseline))
        if b is None or name==baseline:continue
        pairs.append({'case_id':ident,'point_index':r['point_index'],'external_seed':r.get('external_seed'),
            'condition':name,'baseline':baseline,'baseline_verified':b.get('verified',False),'intervention_verified':r.get('verified',False),
            'baseline_20digit_goal':b.get('pre_verifier_20digit_goal',False),'intervention_20digit_goal':r.get('pre_verifier_20digit_goal',False),
            'goal_digit_difference':r['pre_verifier_goal_digits']-b['pre_verifier_goal_digits'] if 'pre_verifier_goal_digits' in r and 'pre_verifier_goal_digits' in b else None,
            'numeric_seconds_difference':r.get('numeric_seconds',0)-b.get('numeric_seconds',0)})
    (destination/'rows.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    (destination/'paired-differences.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in pairs))
    (destination/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    if stationary:(destination/'stationary-assessments.jsonl').write_text(''.join(dumps(r)+'\n' for r in stationary_rows))
    flat=[{k:v for k,v in r.items() if k!='status'} for r in summaries]
    with (destination/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    (destination/'receipt.json').write_text(json.dumps({'planned':completion['planned'],'assessed':len(rows),'analytic_errors':errors,
        'analytic_precision':600,'analytic_references_used_only_after_runs':True,
        'stationary_checks':stationary,'stationary_count':len(stationary_rows),
        'independence_warning':'These are conditional retained candidates from two development problems, not 4612 independent natural problems.',
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
    print(json.dumps({'assessed':len(rows),'analytic_errors':len(errors),'summary':summaries}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('campaign',type=Path);p.add_argument('destination',type=Path);p.add_argument('--stationary',action='store_true');a=p.parse_args();analyze(a.campaign,a.destination,a.stationary)
