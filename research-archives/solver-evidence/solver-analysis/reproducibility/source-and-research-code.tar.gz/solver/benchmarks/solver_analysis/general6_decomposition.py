"""Apply the previously derived General6 identity to saved local endpoints."""
import argparse,hashlib,json,statistics
from collections import defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps


def analyze(source,out):
    if out.exists():raise FileExistsError(out)
    rows=[]
    with mp.workdps(400):
        for r in map(loads,source.read_text().splitlines()):
            if r['case_id']!='HMMT-NOV-2023-GEN-06' or r['matched_physical'] or 'final' not in r:continue
            z=r['final']['geometry'];g,eta=z['residuals'];G=z['goals']['physical']
            terms=[5*eta,-4*g,eta*g,-g*g];pred=mp.fsum(terms);actual=G*G-30
            denom=mp.fsum(abs(t) for t in terms)
            rows.append({'variant':r['variant'],'dps':r['dps'],'start_index':r['start_index'],
                'eta':eta,'gap':g,'terms':terms,'actual_squared_goal_error':actual,
                'identity_relative_error':abs(actual-pred)/max(denom,mp.mpf('1e-350')),
                'log10_regular_over_contact_term':mp.log10(abs(5*eta/(4*g))) if eta and g else None,
                'regular_term_dominates':abs(5*eta)>abs(4*g),
                'source_file':r['file']})
    by=defaultdict(list)
    for r in rows:by[r['variant'],r['dps']].append(r)
    summary=[]
    for (v,d),rr in sorted(by.items()):
        ratios=[float(r['log10_regular_over_contact_term']) for r in rr if r['log10_regular_over_contact_term'] is not None]
        summary.append({'variant':v,'dps':d,'n':len(rr),'regular_term_dominates':sum(r['regular_term_dominates'] for r in rr),
            'median_log10_regular_over_contact_term':statistics.median(ratios) if ratios else None,
            'maximum_identity_relative_error':float(max(r['identity_relative_error'] for r in rr))})
    out.mkdir(parents=True);(out/'rows.jsonl').write_text(''.join(dumps(r)+'\n' for r in rows))
    result={'summary':summary,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'identity':'G_f^2-30=5*eta-4*g+eta*g-g^2; eta=XY-6, g=R-(5-v)',
        'scope':'Post-outcome decomposition using the identity recorded in audit2 before outcomes; no new prediction score or changed forecast.'}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args();analyze(a.source,a.output)
