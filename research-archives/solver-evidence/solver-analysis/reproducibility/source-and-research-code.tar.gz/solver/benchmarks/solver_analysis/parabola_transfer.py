"""A fresh normal-map fold, selected after theory v1 was frozen.

This is a designed structural transfer, not a natural competition problem.
The input-only elimination is exact; neither optimizer nor references imported.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sympy as s
from unknown_authoring import c,eq,gt,lt


def write(destination):
    if destination.exists():raise FileExistsError(destination)
    destination.mkdir(parents=True);t=s.symbols('t',positive=True)
    rho=t*t/2+1+1/t-s.Rational(5,2);h=1-(1+1/t)+t*t
    assert s.factor(rho)==(t-1)**2*(t+2)/(2*t)
    assert s.simplify(h-(t-1)*(t*t+t+1)/t)==0
    variants={}
    for epsilon,label in [('0','fold'),('1/100','split'),('-1/100','no_root')]:
        d={'id':'GENERATED-PARABOLA-NORMAL-'+label.upper(),'variables':['t','lam'],
            'constructions':[c('P','Point(t,t**2/2)'),c('F','Point(0,1/2)'),
                c('N','Point(t*(1-lam),t**2/2+lam)'),c('K',f'Point(-1,5/2+({epsilon}))')],
            'conditions':[eq('N.x','K.x'),eq('N.y','K.y'),gt('t','1/2'),lt('t','3/2'),gt('lam',1),lt('lam',3)],
            'target':'Distance(F,P)'}
        variants[label+'_original']=d
        reduced=copy.deepcopy(d);reduced['variables']=['t'];reduced['constructions'][2]=c('N','Point(-1,t**2/2+1+1/t)')
        reduced['conditions']=[eq('N.y','K.y'),gt('t','1/2'),lt('t','3/2')]
        variants[label+'_reduced']=reduced
        if label=='fold':
            signed=copy.deepcopy(d);signed['conditions'][1]=eq('1-lam+t**2')
            variants['fold_signed']=signed
            signed1=copy.deepcopy(reduced);signed1['conditions'][0]=eq('(t-1)*(t**2+t+1)/t')
            variants['fold_reduced_signed']=signed1
            squared=copy.deepcopy(signed);squared['conditions'][1]=eq('(1-lam+t**2)**2')
            variants['fold_resquared']=squared
    from geosolver.problem.models import GeometryProblem
    from geosolver.problem.validation import validate
    for name,d in variants.items():
        result=validate(GeometryProblem.model_validate(d));assert result.valid,(name,result)
        (destination/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
    receipt={'rule':'local-prediction-protocol-v1','source':'Sol Pro transfer suggestion after rule freeze; independent exact checks here',
        'input_map':'N(t,lam)=(t*(1-lam),t^2/2+lam)','geometry':'normal to P(t)=(t,t^2/2), normal vector(-t,1)',
        'root':'(t,lam)=(1,2)','kernel':'(1,-1)','determinant':'1-lam+t^2','kernel_derivative_of_determinant':3,
        'eliminated_residual':str(s.factor(rho)),'signed_equivalent_on_guard':str(s.factor(h)),
        'goal_error':'(t-1)*(t+1)/2','goal_squared_error_over_residual_limit':'2/3',
        'predictions':{'fold':'m=2,q=1; signed contact regularizes the weak direction; scalar reduced arm isolates damping law',
                       'split':'positive height perturbation gives two simple roots in guard, m=1; both values are independently derivable',
                       'no_root':'negative height perturbation has no real root in guard; extra precision cannot produce a valid root'},
        'excluded_root':'t=-2,lam=1/2 lies outside both guards and is regular',
        'scope':'Fresh generated DAG family; fold theory itself is classical. Distinct from circle-point incidence detector, whose abstention is retained.',
        'optimizer_calls':0,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (destination/'derivation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args();write(a.destination)
