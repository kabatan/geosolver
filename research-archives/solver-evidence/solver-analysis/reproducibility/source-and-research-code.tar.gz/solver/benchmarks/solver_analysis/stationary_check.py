"""Evaluate saved coordinates without correction, search, or identification.

This is a numerical residual/domain check. It does not certify that a nearby
exact solution exists, and it never reassigns later coordinates to this point.
"""
from mpmath import mp
from geosolver.engine.standard.evaluation.verification_system import sample_equations
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode


def check(evaluator, point, precision=120, tolerance='1e-20'):
    saved=tuple(v._mpf_ for v in point)
    result={'precision':precision,'tolerance':tolerance,'coordinate_correction':False,
            'guarantee':'numeric condition and domain check only; no existence certificate'}
    with mp.workdps(precision),high_precision_mode():
        try:
            raw=evaluator.evaluate_hp_residual(point,precision=precision)
            guard,tags=evaluator.evaluate_guard(point)
            hard=evaluator.evaluate_hp_hard_feasibility(point,precision=precision,include_margins=True)
            eq=evaluator.verification_equations
            samples=sample_equations(eq,point,precision)
            rows=[]
            for equation,(value,trace,error) in zip(eq,samples):
                scale=max(mp.mpf(1),equation.term_scale(point,precision))
                fraction=(abs(value)+error)/scale
                rows.append({'source':equation.source,'value':value,'error_indicator':error,
                             'scale':scale,'relative_value':fraction,'branch_trace':trace})
            fraction=max((r['relative_value'] for r in rows),default=mp.mpf(0))
            passed=raw.is_finite and guard and hard.hard_feasible and mp.isfinite(fraction) and fraction<=mp.mpf(tolerance)
            result.update(numeric_conditions_passed=bool(passed),guard=guard,guard_tags=tags,hard=hard,
                          max_scaled_equation_error=fraction,public_residual=raw,rows=rows)
        except Exception as ex:
            result.update(numeric_conditions_passed=False,error=type(ex).__name__+': '+str(ex))
    assert saved==tuple(v._mpf_ for v in point),'stationary check changed coordinates'
    return result
