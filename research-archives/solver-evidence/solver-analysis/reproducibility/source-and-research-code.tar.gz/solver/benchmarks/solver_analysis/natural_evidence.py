"""Assess archived candidates with separately derived geometry; no search calls."""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from mpmath import mp
from contact_probe import geometry


def n(v):return mp.nstr(v,45)


def original_conditions(ident,x,tolerance='1e-20'):
    """Independent formulas at the saved point, without a product evaluator.

    These checks give numerical residuals and exact-sign domain tests at the
    current arithmetic precision, not interval existence certificates.
    """
    try:
        if ident=='JMO-2013-PRE-05':
            theta,p,q=x;s=mp.sin(theta)
            domain=0<theta<mp.pi and p>0 and q>0 and p!=9 and q!=2 and s!=0
            g=geometry(theta,p,q);r1=g['radius1'];r2=r1/g['goal']
            residuals=[g['stable1']/max(1,r1),g['stable2']/max(1,r2)]
            margins=[theta,mp.pi-theta,p,q,abs(p-9),abs(q-2),abs(s)]
            description='The four constant length/collinearity equations hold by construction. The two original line-circle gaps are evaluated through exact stable identities.'
        elif ident=='HMMT-2014-FEB-GEO-10':
            r1,r2,t=x;v=mp.matrix([mp.mpf(16)/65,-mp.mpf(63)/65]);w=mp.matrix([mp.mpf(32)/15,-12])
            o=mp.matrix([-2,16])+r1*v;T=mp.matrix([-2,16])+t*w
            d1=mp.norm(t*w-r1*v);d2=mp.norm(T);d12=mp.norm(o)
            residuals=[abs(d1-r1)/max(1,d1,abs(r1)),abs(d2-r2)/max(1,d2,abs(r2)),
                       abs(d12-r1-r2)/max(1,d12,abs(r1+r2))]
            domain=r1>0 and r2>0 and t>0;margins=[r1,r2,t]
            description='The fixed triangle sides are exactly13,14,15. Separately derived centre/contact-point coordinates check all three nonconstant original distances.'
        else:raise ValueError('No independent equation set for '+ident)
        worst=max(residuals);passed=bool(domain and mp.isfinite(worst) and worst<=mp.mpf(tolerance))
        return {'passed':passed,'domain':bool(domain),'maximum_scaled_residual':n(worst),
                'scaled_residuals':[n(v) for v in residuals],'minimum_domain_margin':n(min(margins)),
                'tolerance':tolerance,'coordinate_correction':False,'formula_scope':description,
                'guarantee':'Numerical original-condition check; no interval existence certificate.'}
    except Exception as ex:return {'passed':False,'error':type(ex).__name__+': '+str(ex),'coordinate_correction':False}


def jmo(x):
    theta,p,q=x;g=geometry(theta,p,q)
    p0=mp.root(36,3);q0=mp.root(162,3)
    return {'theta':n(theta),'p':n(p),'q':n(q),'sin_theta':n(mp.sin(theta)),
            'p_error':n(p-p0),'q_error':n(q-q0),
            'transverse_error':n(mp.sqrt((p-p0)**2+(q-q0)**2)),
            'goal':n(g['goal']),'goal_error':n(g['goal']-mp.root(mp.mpf(2)/9,3)),
            'stable_gap_norm':n(mp.sqrt(g['stable1']**2+g['stable2']**2)),
            'projection_norm':n(mp.sqrt(g['projection1']**2+g['projection2']**2)),
            'radius1':n(g['radius1']), 'radius2':n(g['radius1']/g['goal'])}


def hmmt(x):
    r1,r2,t=x;v=(mp.mpf(16)/65,-mp.mpf(63)/65);w=(mp.mpf(32)/15,mp.mpf(-12));a=(-2,16)
    o=(a[0]+r1*v[0],a[1]+r1*v[1]);T=(a[0]+t*w[0],a[1]+t*w[1])
    dist=mp.sqrt(o[0]**2+o[1]**2)
    h=(o[0]*T[1]-o[1]*T[0])/dist
    proj=(o[0]*T[0]+o[1]*T[1])/dist**2
    return {'r1':n(r1),'r2':n(r2),'t':n(t),'h':n(h),'foot_fraction':n(proj),
        'legal_r1_error':n(r1-mp.mpf(1507415)/640008),
        'legal_goal_error':n(r2-mp.mpf(1235)/108),'boundary_goal_error':n(r2-mp.sqrt(260)),
        'incidence_curve_error':n(t-mp.mpf(8889)/54314*r1),
        'distance_to_boundary':n(mp.sqrt(r1*r1+t*t+(r2-mp.sqrt(260))**2))}


def aime(x):
    x=x[0];m=mp.sqrt(x*x+225);n0=mp.sqrt(x*x+36)
    return {'x':n(x),'first_distance':n(m),'second_distance':n(n0),
        'nearest_integer_pair':f'{mp.nint(m)},{mp.nint(n0)}',
        'goal':n(30+2*m),'nearest_legal_goal_error':n(min(abs(30+2*m-z) for z in (64,96,220))),
        'boundary_distance':n(abs(x))}


def run(root,out):
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True)
    summary={}
    with mp.workdps(600):
        for ident,fn in [('JMO-2013-PRE-05',jmo),('HMMT-2014-FEB-GEO-10',hmmt),('aime-2003-1-7',aime)]:
            rows=[];summaries=[]
            for file in sorted((root/ident).glob('*.json')):
                v=json.loads(file.read_text());s=v['solver_result'];d=s['diagnostics'];p=d['pipeline_summary'];sources=set()
                for candidate in d['candidate_records']:
                    if candidate.get('source'):
                        source=candidate['source'];uid=source['candidate_uid']
                        if uid not in sources:
                            sources.add(uid)
                            rows.append({'seed':v['seed'],'stage':'float_source','uid':uid,'revision':0,
                                'coordinate_dps':53,'stored_residual':str(source['residual_norm_float']),
                                'status':source['evaluation_status'],'hard_tags':'|'.join(source['hard_violation_tags']),
                                **fn([mp.mpf(z) for z in source['x_float']])})
                    if candidate.get('x_hp'):
                        rows.append({'seed':v['seed'],'stage':'retained_hp','uid':candidate['candidate_uid'],
                            'revision':candidate['revision'],'coordinate_dps':candidate['coordinate_precision_dps'],
                            'stored_residual':candidate['residual_norm_hp'],'status':candidate['refinement_status'],
                            'hard_tags':'|'.join(candidate['hard_violation_tags']),**fn([mp.mpf(z) for z in candidate['x_hp']])})
                summaries.append({'seed':v['seed'],'elapsed':s['elapsed_seconds'],'answers':s['answers'],
                    'phase_seconds':d['phase_timings'],'distinct_sources':len(sources),
                    'retained_records':len(d['candidate_records']),'search':p['search'],
                    'fallback':p['search_staged_fallback'],'discrete':p['phase_discrete_completion']})
            with (out/f'{ident}.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            summary[ident]={'runs':summaries,'by_stage':dict(Counter(r['stage'] for r in rows))}
    (out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    (out/'receipt.json').write_text(json.dumps({'mode':'archival assessment; uses independent analytic references',
        'precision':600,'limitation':'The retained HP records are final archived revisions, not a complete trajectory. Float sources are conditional on retention.',
        'natural_source_root':str(root),'formula_source':'verify_derivations.py, contact_probe.py and mechanisms-v0.md'},indent=2)+'\n')
    print(json.dumps({i:v['by_stage'] for i,v in summary.items()}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.root,a.out)
