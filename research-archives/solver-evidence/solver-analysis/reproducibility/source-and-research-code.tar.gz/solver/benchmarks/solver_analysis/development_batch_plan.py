"""Plan the remaining development comparisons without executing search."""
import argparse
import json
import random
import sys
from pathlib import Path
from stage_replay import ensure_source


def main(archive,out):
    if out.exists():raise FileExistsError(out)
    code=Path(__file__).parent.resolve();prefix=[sys.executable,'-B'];groups=[]
    for i in range(107):
        directory=archive/f'development/stage-campaign-v2/runs/JMO-2013-PRE-05/{i}'
        groups.append({'id':f'exact_{i:03d}','jobs':[{'command':prefix+[str(code/'multiplicity_proposal.py'),str(directory),
            str(archive/f'development/multiplicity-proposal-v1/{i}.json')],'process_timeout':60}]})
    detection=json.loads((archive/'development/contact-detector-v2/scan.json').read_text())
    ids=[r['case_id'] for r in detection['rows'] if r['positive']]+['HMMT-2014-FEB-GEO-10']
    for ident in ids:
        original=Path.cwd()/'benchmarks/dsl'/(ident+'.json')
        pool=archive/'development/common-multistart-v1/pools'/(ident+'.json')
        jobs=[{'command':prefix+[str(code/'common_multistart.py'),'prepare',str(original),str(pool)],'required_for_next':True,'process_timeout':30}]
        if ident=='HMMT-2014-FEB-GEO-10':
            variants={n:archive/'development/representations-v2'/ident/(n+'.json') for n in ('original','signed_contact','contact_squared')}
        else:
            variants={'original':original,**{n:archive/'development/contact-detector-v2/variants'/ident/(n+'.json') for n in ('signed','squared','stable_gap')}}
        arms=[(backend,name,dsl) for backend in ('nomad','scipy') for name,dsl in variants.items()]
        random.Random(20260914+len(groups)).shuffle(arms)
        for backend,name,dsl in arms:
            dest=archive/'development/common-multistart-v1/runs'/ident/(backend+'__'+name+'.json')
            jobs.append({'command':prefix+[str(code/'common_multistart.py'),'run',str(dsl),str(pool),str(dest),
                '--backend',backend,'--hp-dsl',str(original)],'process_timeout':290})
        groups.append({'id':ident,'jobs':jobs})
    random.Random(20260914).shuffle(groups)
    plan={'source_hash':ensure_source(),'jobs':8,'groups':groups,
        'wait_for_receipt':str(archive/'campaigns/development-followup-sequence.json'),
        'scope':'instrumented development; no unknown outcomes. Original HP residual is common to all frontend arms.',
        'predictions':['Common-start signed vs squared frontend comparison isolates frontend changes when HP residual is fixed to original.',
            'M x proposal continuation uses the same saved verifier result within each proposal pair. Natural archived identification inputs are a separate stratum.',
            'Generic contact detection is not a full-pipeline failure predictor; successful scalar and multivariable contact controls are retained.'],
        'required_remaining':'Same-pool candidate selection replay and representation-specific HP crosses reuse these saved searches; they must not rerun different search pools.'}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps({'groups':len(groups),'jobs':sum(len(g['jobs']) for g in groups),'cases':ids}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);a=p.parse_args();main(a.archive,a.output)
