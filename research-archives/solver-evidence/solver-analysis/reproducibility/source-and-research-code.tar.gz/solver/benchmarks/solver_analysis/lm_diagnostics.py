"""Compare recorded JMO LM steps to independently derived contact equations.

Post-hoc mathematical analysis, never an input to search or prediction.
The recorded step is checked against the exact two-coordinate contact model,
not against another implementation of the recorded numerical Jacobian.
"""
import argparse
import hashlib
import json
import statistics
from pathlib import Path
from mpmath import mp
from exact_codec import loads


def n(v):return mp.nstr(v,35)
def run(campaign,out):
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);summaries=[];details=[]
    names=['original__lm50','original__lm100','original__lm200',
        'original__native_refine','original__damping_min_1e-24','original__damping_min_1e-48',
        'projection__lm200']
    with mp.workdps(240):
        rootp=mp.root(36,3);rootq=mp.root(162,3)
        for directory in sorted((campaign/'runs/JMO-2013-PRE-05').iterdir(),key=lambda p:int(p.name)):
            for name in names:
                path=directory/(name+'.json');r=loads(path.read_text());tr=r['trace']
                steps=[z for z in tr if z['kind']=='lm_step'];lines=[z for z in tr if z['kind']=='line_search']
                assert len(steps)==len(lines)
                row={'point_index':int(directory.name),'condition':name,'file':str(path),'steps':len(steps),'stages':[]}
                previous=None;stage=None
                for i,(step,line) in enumerate(zip(steps,lines)):
                    point=line['input']['point'];theta,p,q=point;lam=step['input']['damping'];dps=line['input']['dps']
                    norm=line['input']['current_norm'];trial,rv,improved=line['output']
                    improvement=(norm-mp.norm(rv))/max(abs(norm),mp.mpf('1e-30')) if improved else None
                    if dps!=previous:
                        stage={'dps':dps,'first_step':i,'start_damping':n(lam),'start_residual':n(norm),
                            'iterations':0,'small_improvement_iterations':0,'last_residual':None}
                        row['stages'].append(stage);previous=dps
                    stage['iterations']+=1;stage['last_residual']=n(mp.norm(rv)) if rv is not None else None
                    stage['last_damping']=n(lam)
                    stage['small_improvement_iterations']+=int(improvement is not None and improvement<mp.mpf('1e-10'))
                    record={'point_index':row['point_index'],'condition':name,'step':i,'dps':dps,
                        'damping':n(lam),'residual':n(norm),'improvement':n(improvement) if improvement is not None else None,
                        'point':[n(v) for v in point],'transverse_error':n(mp.sqrt((p-rootp)**2+(q-rootq)**2))}
                    if not name.startswith('projection'):
                        a=mp.matrix([q/p-p/2,9*p/(2*q)-q/2])
                        Da=mp.matrix([[-q/p**2-mp.mpf('.5'),1/p],[mp.mpf('4.5')/q,-mp.mpf('4.5')*p/q**2-mp.mpf('.5')]])
                        f=mp.matrix([v*v for v in a]);J=mp.diag([2*v for v in a])*Da;A=J.T*J
                        model=mp.lu_solve(A+lam*mp.eye(2),-J.T*f)
                        actual=mp.matrix(line['input']['step'][1:]);model_error=mp.norm(actual-model)/max(mp.norm(model),mp.mpf('1e-220'))
                        eigmax=(A[0,0]+A[1,1]+mp.sqrt((A[0,0]-A[1,1])**2+4*A[0,1]**2))/2
                        eigmin=mp.det(A)/eigmax if eigmax else 0
                        record.update(contact_norm=n(mp.norm(a)),model_relative_step_error=n(model_error),
                            damping_over_largest_transverse_jtj_eigenvalue=n(lam/eigmax) if eigmax else None,
                            damping_over_smallest_transverse_jtj_eigenvalue=n(lam/eigmin) if eigmin else None,
                            local_interior=bool(abs(p-rootp)+abs(q-rootq)<mp.mpf('.01') and abs(mp.sin(theta))>mp.mpf('.001')),
                            independent_model_step=[n(v) for v in model])
                    details.append(record)
                summaries.append(row)
    with (out/'step-analysis.jsonl').open('w') as f:
        for r in details:f.write(json.dumps(r)+'\n')
    (out/'stage-analysis.json').write_text(json.dumps(summaries,indent=2)+'\n')
    aggregate=[]
    for name in names:
        selected=[r for r in details if r['condition']==name]
        local=[r for r in selected if r.get('local_interior')]
        stages=[r for r in summaries if r['condition']==name]
        aggregate.append({'condition':name,'points':len(stages),'recorded_steps':len(selected),'local_interior_steps':len(local),
            'median_model_relative_step_error':statistics.median(float(r['model_relative_step_error']) for r in local) if local else None,
            'lambda_dominates_all_transverse_eigenvalues':sum(float(r['damping_over_largest_transverse_jtj_eigenvalue'] or 0)>1 for r in local),
            'second_stage_stops_after_five_small_improvements':sum(len(r['stages'])>1 and r['stages'][1]['iterations']==5 and r['stages'][1]['small_improvement_iterations']==5 for r in stages),
            'median_total_steps':statistics.median(r['steps'] for r in stages)})
    receipt={'kind':'post-hoc independent analytic trace check; no solver reruns',
        'model':'F=(h1^2,h2^2), h1=q/p-p/2, h2=9p/(2q)-q/2; theta exactly absent',
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'aggregate':aggregate}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('campaign',type=Path);p.add_argument('output',type=Path);a=p.parse_args();run(a.campaign,a.output)
