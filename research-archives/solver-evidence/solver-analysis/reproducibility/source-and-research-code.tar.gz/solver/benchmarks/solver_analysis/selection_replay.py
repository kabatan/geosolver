"""Fixed retained candidate pools, reference-blind rankings and total LM budget.

The three source seed ledgers are paired units, not independent natural cases.
All rankings are recorded before optimizer restarts; invalid points stay last.
"""
import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from paired_stages import bundle_of
from stage_replay import ensure_source
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode


def prepare(archive):
    root=Path(__file__).resolve().parents[2];dest=archive/'development/selection-replay-v2'
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir();pool=archive/'development/jmo-legacy-source-pool.json';points=loads(pool.read_text())['points']
    base=archive/'development/representations-v2/JMO-2013-PRE-05'
    dsl=json.loads((base/'original.json').read_text());signed=json.loads((base/'projection.json').read_text())
    e=build_ir_evaluator(bundle_of(dsl));h=build_ir_evaluator(bundle_of(signed));scores=[];begun=time.monotonic()
    with mp.workdps(100),high_precision_mode():
        for i,point in enumerate(points):
            r={'index':i,'uid':point['uid'],'seed':point['external_seed'],'error':None}
            try:
                def exact_float(v):
                    if isinstance(v,float):
                        numerator,denominator=v.as_integer_ratio();return mp.mpf(numerator)/denominator
                    return mp.mpf(v)
                x=tuple(exact_float(v) for v in point['x']);scale=[max(1,abs(v)) for v in x];eps=mp.mpf('1e-25')
                def sample(xx):
                    f=e.evaluate_hp_residual(xx,precision=100)
                    g=e.evaluate_answer_hp(xx,precision=100).answer_hp
                    if not f.is_finite or g is None:raise ValueError('nonfinite current evaluation')
                    return mp.matrix(f.residual_vector),g
                f,g=sample(x);hh=h.evaluate_hp_residual(x,precision=100)
                if not hh.is_finite:raise ValueError('signed residual not finite')
                J=mp.matrix(len(f),len(x));DG=mp.matrix(1,len(x))
                guard=e.evaluate_guard(x)[0];hard=e.evaluate_hp_hard_feasibility(x,precision=100,include_margins=False).hard_feasible
                for j,sc in enumerate(scale):
                    xp=list(x);xm=list(x);xp[j]+=eps*sc;xm[j]-=eps*sc
                    fp,gp=sample(xp);fm,gm=sample(xm)
                    for k in range(len(f)):J[k,j]=(fp[k]-fm[k])/(2*eps)
                    DG[0,j]=(gp-gm)/(2*eps)
                correction=mp.lu_solve(J.T*J+mp.mpf('1e-12')*mp.eye(len(x)),J.T*f)
                r.update(eligible=True,guard=bool(guard),hard=bool(hard),raw_norm=mp.norm(f),signed_norm=mp.norm(hh.residual_vector),
                    goal_correction=abs((DG*correction)[0])/max(1,abs(g)),current_goal=g,
                    raw_jacobian=J,normalized_variable_scale=scale,gradient=DG)
            except Exception as ex:r.update(eligible=False,guard=False,hard=False,error=type(ex).__name__+': '+str(ex))
            scores.append(r)
    save=dest/'scores.json';save.write_text(dumps({'rows':scores,'seconds':time.monotonic()-begun,
        'definition':'score uses public original residual, signed contact norm, or regularized |DG*(JtJ+1e-12I)^-1*JtF| / max(1,|G|)',
        'reference_access':False,'gradient_dps':100,'difference_step':'1e-25','pool_sha256':hashlib.sha256(pool.read_bytes()).hexdigest()})+'\n')
    if not any(r['eligible'] for r in scores):raise ValueError('No ranking evaluable; inspect retained failures before running an experiment.')
    groups=[];rankings=[]
    for seed in (0,1,2):
        subset=[r for r in scores if r['seed']==seed]
        for ranking in ('raw_norm','signed_norm','goal_correction','ledger_order'):
            order=sorted(subset,key=lambda r:(not(r['eligible'] and r['guard'] and r['hard']),
                r['index'] if ranking=='ledger_order' else r.get(ranking,mp.inf),r['index']))
            rankings.append({'seed':seed,'method':ranking,'all_indices':[r['index'] for r in order]})
            for k in (1,4):
                indices=[r['index'] for r in order[:k]]
                for variant in ('original','projection'):
                    jobs=[]
                    for j,index in enumerate(indices):
                        runid=f'seed{seed}__{ranking}__K{k}__{variant}__rank{j}'
                        jobs.append({'command':[sys.executable,'-B',str(Path(__file__).with_name('paired_stages.py')),'run',
                            str(base/(variant+'.json')),str(base/'original.json'),str(pool),str(index),str(dest/'runs'/(runid+'.json')),
                            '--engine','native_lm','--dps','100','--iterations',str(80//k),'--seconds','30'],
                            'process_timeout':50})
                    groups.append({'id':f'seed{seed}__{ranking}__K{k}__{variant}','jobs':jobs})
    random.Random(660911).shuffle(groups)
    plan={'source_hash':ensure_source(),'jobs':8,'groups':groups,'ranking_file':str(save),
        'ranking_file_sha256':hashlib.sha256(save.read_bytes()).hexdigest(),'rankings':rankings,
        'total_lm_iteration_cap_per_condition':80,'precision':100,'initial_damping_and_floor':'fixed production defaults',
        'wait_for_receipt':str(archive/'unknown-local-v1/mid-batch/completion.json'),
        'interpretation':'Controlled retained-pool K/allocation diagnostic; no claim to reproduce unretained search points or the full production selection heuristic. Every skipped index is retained in rankings; equal per-candidate allocation means order alone cannot change total completed output sets.',
        'predictions':'No registered unconditional win for a ranking. Test whether signed residual and goal correction rank useful points differently from raw residual and whether K4 can offset the quarter-sized refinement budget.'}
    p=dest/'plan.json';p.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'groups':len(groups),'jobs':sum(len(g['jobs']) for g in groups),'path':str(p)}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);a=p.parse_args();prepare(a.archive)
