"""Exact, independent algebra checks for development mechanisms.

No GeoSolver evaluator or benchmark answer is imported. Identities are checked
over rational polynomial rings; positive-root intervals use integer arithmetic.
"""

from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as s


def verify():
    p,q,c,r=s.symbols('p q c r')
    equations=[p*p-2*q,q*q-9*p]
    basis=s.groebner(equations,p,q,c)
    ratio2=(q*q*(p*p+4-4*p*c))/(p*p*(q*q+81-18*q*c))
    numerator=s.cancel(ratio2-p*p/(q*q)).as_numer_denom()[0]
    remainder=basis.reduce(numerator)[1]
    assert remainder==0
    determinant=s.det(s.Matrix([[(q/p-p/2).diff(p),(q/p-p/2).diff(q)],
                                 [(9*p/(2*q)-q/2).diff(p),(9*p/(2*q)-q/2).diff(q)]]))
    det_num=s.cancel(determinant-s.Rational(3,4)).as_numer_denom()[0]
    assert basis.reduce(det_num)[1]==0
    intervals={'p':(s.Rational(3301,1000),s.Rational(3302,1000),36),
               'q':(s.Rational(5451,1000),s.Rational(5452,1000),162)}
    for low,high,value in intervals.values():assert low**3<value<high**3
    w=s.Matrix([s.Rational(32,15),-12]);v=s.Matrix([s.Rational(16,65),s.Rational(-63,65)])
    a=s.Matrix([-2,16]);assert v.dot(v)==1
    k=s.factor(2*w.dot(v)/w.dot(w))
    alpha=s.factor(a.dot(v)-k*a.dot(w));beta=s.factor(k*k*w.dot(w)/2)
    factor=s.factor((alpha-beta*r)**2-(a.dot(a)+2*k*a.dot(w)*r+k*k*w.dot(w)*r*r))
    expected=-4*(640008*r-1507415)**2/s.Integer(77898717300625)
    assert s.expand(factor-expected)==0
    r1=s.Rational(1507415,640008);t=k*r1;r2=alpha-beta*r1
    assert r1>0 and t>0 and r2>0
    # Original three distance equations after squaring, with positive radii
    # separately proved, so each verifies the original nonnegative distance.
    original_checks=[s.factor((t*w-r1*v).dot(t*w-r1*v)-r1*r1),
                     s.factor((a+t*w).dot(a+t*w)-r2*r2),
                     s.factor((a+r1*v).dot(a+r1*v)-(r1+r2)**2)]
    assert original_checks==[0,0,0]
    return {'status':'exact algebraic identity checks passed; development theory only',
            'JMO-2013-PRE-05':{'ratio_squared_remainder':str(remainder),'normal_chart_determinant':'3/4',
              'positive_cube_root_intervals':{name:[str(v[0]),str(v[1])] for name,v in intervals.items()},
              'domain_obligation':'0<theta<pi; q!=2,p!=9; all radii and distances used as divisors positive'},
            'HMMT-2014-FEB-GEO-10':{'k':str(k),'alpha':str(alpha),'beta':str(beta),'factorization':str(factor),
              'configuration':{'r1':str(r1),'r2':str(r2),'t':str(t)},
              'original_squared_equations':list(map(str,original_checks)),
              'positive_sign_checks':True,'boundary_linear_coefficient':str(alpha/s.sqrt(260)-1)},
            'limitation':'No global numerical convergence, all-corpus certification, or novelty claim follows from these checks.'}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    result=verify();args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
