"""Prepare, execute and score the preregistered local input-derived starts.

Preparation and probes use independent geometric formulas. Optimizer calls are
delegated to paired_stages.py in isolated processes by task_batch.py. Frozen
forecast, input and pool hashes travel with every plan.
"""
import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path
from mpmath import mp
from exact_codec import dumps,loads
from prospective_geometry import *
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    if p.exists():raise FileExistsError(p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(dumps(v)+'\n')


def specs(intake,ident):
    if ident in (GEN,GUTS,CEMC):
        base=intake/'representations-v2'/ident
        stem='constructed_aux_target' if ident==GEN else 'constructed'
        return [(name,base/(stem+suffix+'.json'),False) for name,suffix in
            [('original',''),('signed','__signed'),('resquared','__squared'),('stable_gap','__stable_gap')]],base/'original.json'
    if ident in (CEMC26,H25,G25,UK25):
        base=intake/'enriched-v2/variants'/ident;stem='constructed' if ident==H25 else 'original'
        names=[('original','')]
        if ident in (CEMC26,H25):names += [('signed','_signed'),('resquared','_squared'),('stable_gap','_stable_gap')]
        return [(name,base/(stem+suffix+'.json'),False) for name,suffix in names],base/'original.json'
    if ident==PARA:
        base=intake/'parabola-transfer-v1'
        return [(name,base/(stem+'.json'),reduced) for name,stem,reduced in
            [('original','fold_original',False),('signed','fold_signed',False),('resquared','fold_resquared',False),
             ('reduced','fold_reduced',True),('reduced_signed','fold_reduced_signed',True)]],base/'fold_original.json'
    raise ValueError(ident)


def command(dsl,original,pool,index,out,iterations,dps):
    return {'command':[sys.executable,'-B',str(Path(__file__).with_name('paired_stages.py')),'run',
        str(dsl),str(original),str(pool),str(index),str(out),'--engine','native_lm','--dps',str(dps),
        '--iterations',str(iterations),'--seconds','30'],'process_timeout':50}


def prepare(archive):
    intake=archive/'unknown-intake';forecast=intake/'individual-predictions-v1.json'
    f=json.loads(forecast.read_text());dest=archive/'unknown-local-v1'
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir();groups={'mid':[],'final':[]};manifest=[]
    with mp.workdps(550):
        for rec in f['local_predictions']:
            ident=rec['case_id'];split='mid' if rec['split']=='mid' else 'final';n=DIMENSIONS[ident]
            variants,physical_dsl=specs(intake,ident);original=variants[0][1]
            points=[];physical=[];lifted=[];clusters=[]
            ds=tuple(mp.mpf(i+1)/mp.sqrt(sum((j+1)**2 for j in range(n))) for i in range(n))
            for mirror in ([False,True] if ident==H25 else [False]):
                for exponent in (2,4):
                    for sign in (-1,1):
                        index=len(points);uid=f'{ident}__mirror{int(mirror)}__delta{exponent}__sign{sign}'
                        x=chart(ident,tuple(sign*mp.mpf(10)**(-exponent)*v for v in ds),mirror)
                        z=evaluate(ident,x)
                        points.append({'uid':uid,'x':x,'external_seed':0,'case_id':ident,'branch_mirror':mirror,
                            'delta_exponent':exponent,'direction_sign':sign,'independent_start_geometry':z})
                        if ident in (GEN,GUTS,CEMC,H25):
                            physical.append({**points[-1],'x':tuple(z['original_coordinates'])})
                            start=time.monotonic();lift=lifts(ident,z['original_coordinates']);elapsed=time.monotonic()-start
                            indices=[];errors=[]
                            for sheet in lift['sheets']:
                                i=len(lifted);indices.append(i);zz=evaluate(ident,sheet['values'])
                                error=max(abs(a-b) for a,b in zip(z['original_coordinates'],zz['original_coordinates']))
                                errors.append(error)
                                lifted.append({'uid':uid+'__sheet'+str(sheet['sheet']),'x':sheet['values'],
                                    'external_seed':0,'case_id':ident,'physical_cluster':index,'sheet':sheet['sheet'],
                                    'sheet_source_feasible':sheet['segment_feasible'],'independent_start_geometry':zz})
                            assert errors and max(errors)<mp.mpf('1e-500'),(ident,errors)
                            clusters.append({'index':index,'lift_indices':indices,'lift_receipt':lift,
                                'roundtrip_errors':errors,'lift_seconds':elapsed})
            pool=dest/'pools'/ident/'constructed.json';save(pool,{'points':points,'sampling':'input-derived chart; exactly fixed in individual forecast'})
            pool_scalar=dest/'pools'/ident/'scalar.json'
            if ident==PARA:save(pool_scalar,{'points':[{**p,'x':(p['x'][0],)} for p in points],
                'mapping':'t -> (t,1+1/t), exact elimination of N.x=-1 on guard'})
            pool_phy=dest/'pools'/ident/'physical.json';pool_lifts=dest/'pools'/ident/'all-lifts.json'
            if physical:save(pool_phy,{'points':physical});save(pool_lifts,{'points':lifted,'clusters':clusters})
            for index,p in enumerate(points):
                jobs=[]
                for dps in (50,100,200):
                    for name,path,reduced in variants:
                        ref=(intake/'parabola-transfer-v1/fold_reduced.json') if reduced else original
                        runid=f'{ident}__start{index}__{name}__{dps}'
                        jobs.append(command(path,ref,pool_scalar if reduced else pool,index,dest/'runs'/(runid+'.json'),80,dps))
                random.Random(360911+index).shuffle(jobs)
                groups[split].append({'id':ident+'__local'+str(index),'jobs':jobs})
            for cluster in clusters:
                index=cluster['index'];jobs=[];runid=f'{ident}__physical{index}__original__100'
                jobs.append(command(physical_dsl,physical_dsl,pool_phy,index,dest/'matched-runs'/(runid+'.json'),80,100))
                count=len(cluster['lift_indices']);base,remainder=divmod(80,count)
                for name,path,reduced in variants:
                    for j,i in enumerate(cluster['lift_indices']):
                        iterations=base+(j<remainder);runid=f'{ident}__physical{index}__{name}__lift{j}__100'
                        jobs.append(command(path,original,pool_lifts,i,dest/'matched-runs'/(runid+'.json'),iterations,100))
                random.Random(460911+index).shuffle(jobs)
                groups[split].append({'id':ident+'__matched'+str(index),'jobs':jobs})
            manifest.append({'case_id':ident,'split':split,'root_source':'input derivation in frozen individual forecast',
                'pool':str(pool),'pool_sha256':sha(pool),'start_count':len(points),
                'physical_pool':str(pool_phy) if physical else None,'physical_clusters':clusters,
                'variants':[{'name':name,'path':str(path),'sha256':sha(path),'reduced':red} for name,path,red in variants],
                'original_path':str(original),'physical_dsl':str(physical_dsl)})
    for split,gg in groups.items():
        random.Random(560911).shuffle(gg)
        plan={'source_hash':ensure_source(),'jobs':8,'groups':gg,'forecast_sha256':sha(forecast),
            'wait_for_receipt':str(archive/'unknown-results'/split/'sequence.json'),
            'independence':'Physical sheets share one cluster and total budget80 per representation; local full-budget starts are separate diagnostics.'}
        p=dest/(split+'-plan.json');p.write_text(json.dumps(plan,indent=2)+'\n')
    save(dest/'manifest.json',{'forecast_sha256':sha(forecast),'cases':manifest,
        'source_hash':ensure_source(),'geometry_script_sha256':sha(Path(__file__).with_name('prospective_geometry.py')),
        'prepare_script_sha256':sha(Path(__file__)),'unknown_solver_calls_at_preparation':0})
    print(json.dumps({'plans':{k:{'groups':len(v),'jobs':sum(len(g['jobs']) for g in v)} for k,v in groups.items()},'path':str(dest)}))


def probes(archive,split):
    f=json.loads((archive/'unknown-intake/individual-predictions-v1.json').read_text())
    rows=[];summary=[];start=time.monotonic()
    with mp.workdps(400):
        for rec in f['local_predictions']:
            if ('mid' if rec['split']=='mid' else 'final')!=split:continue
            ident=rec['case_id'];n=DIMENSIONS[ident]
            axes={'HMMT-NOV-2023-GEN-06':['h'],GUTS:['t0','t1','t2'],CEMC:['d','e','f','g'],
                CEMC26:['w'],H25:['d','e','f','g'],G25:['w'],UK25:['x','y','s'],PARA:['w']}[ident]
            for mirror in ([False,True] if ident==H25 else [False]):
                base=evaluate(ident,roots(ident,mirror))
                for label,direction,kind,axis in directions(n):
                    ss=[]
                    for exponent in (2,4,6,8,10,12):
                        delta=mp.mpf(10)**(-exponent);x=chart(ident,tuple(delta*v for v in direction),mirror)
                        z=evaluate(ident,x);normf=mp.norm(z['residuals'])
                        errors={k:abs(v-base['goals'][k]) for k,v in z['goals'].items()}
                        row={'case_id':ident,'mirror':mirror,'direction':label,'axis':None if axis is None else axes[axis],
                            'kind':kind,'delta_exponent':exponent,'delta':delta,'x':x,'residual_norm':normf,
                            'goal_errors':errors,'geometry':z};rows.append(row);ss.append(row)
                    slopes={'residual':mp.log10(ss[-1]['residual_norm']/ss[-2]['residual_norm'])/-2}
                    for goal in base['goals']:
                        before,after=ss[-2]['goal_errors'][goal],ss[-1]['goal_errors'][goal]
                        slopes[goal]=mp.log10(after/before)/-2 if min(before,after)>mp.mpf('1e-300') else None
                    predicted={}
                    if kind=='axis':predicted=rec.get('directional_orders',{}).get(axes[axis],{})
                    if 'all_nonzero_direction_order' in rec:predicted={k:rec['all_nonzero_direction_order'] for k in base['goals']}
                    scoring={}
                    for goal,order in predicted.items():
                        slope=slopes[goal]
                        scoring[goal]={'predicted_q':order,'measured_q':slope,
                            'pass':slope is None if order is None else slope is not None and abs(slope-order)<=mp.mpf('.15'),
                            'ratio_q_over_m':None if order is None else mp.mpf(order)/rec['m'],
                            'baseline_half_error':None if slope is None else abs(slope/slopes['residual']-mp.mpf('.5')),
                            'baseline_one_error':None if slope is None else abs(slope/slopes['residual']-1)}
                    summary.append({'case_id':ident,'mirror':mirror,'direction':label,'slopes':slopes,
                        'predicted_m':rec['m'],'m_pass':abs(slopes['residual']-rec['m'])<=mp.mpf('.15'),
                        'goal_scoring':scoring,'unscored_reason':None if scoring else 'No nonzero leading coefficient certificate for this mixed direction.',
                        'all_probes_guard_valid':all(r['geometry']['guard'] for r in ss)})
    dest=archive/'unknown-local-v1/probes'/split
    save(dest/'raw.json',{'rows':rows,'dps':400,'seconds':time.monotonic()-start,'forecast_sha256':sha(archive/'unknown-intake/individual-predictions-v1.json')})
    save(dest/'summary.json',{'rows':summary,'source':'independent geometric chart evaluations; not GeoSolver results'})
    print(json.dumps({'split':split,'probe_rows':len(rows),'directions':len(summary),
        'm_pass':sum(r['m_pass'] for r in summary),'goal_certified_directions':sum(len(r['goal_scoring']) for r in summary),
        'goal_pass':sum(t['pass'] for r in summary for t in r['goal_scoring'].values())}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','probes']);p.add_argument('archive',type=Path)
    p.add_argument('--split',choices=['mid','final'],default='mid');a=p.parse_args()
    if a.mode=='prepare':prepare(a.archive)
    else:probes(a.archive,a.split)
