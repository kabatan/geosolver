"""Initial-state stopping certificates and a single isolated stop-floor pair.

The certificate contains no future iteration. The measured stage is the frozen
native implementation. The optional denominator intervention changes one AST
constant in an in-memory function, never the product source on disk.
"""
import argparse, ast, dataclasses, hashlib, importlib, inspect, json, textwrap, time, sys
from contextlib import ExitStack
from datetime import datetime, timezone
from fractions import Fraction as Q
from pathlib import Path
from unittest.mock import patch
from mpmath import mp
from exact_codec import dumps,loads
from paired_stages import bundle_of
from stage_replay import ensure_source
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator,IREvaluator
from geosolver.engine.standard.refinement.mpmath_refiner import MpmathRefiner,_convert_problem_bounds
from geosolver.engine.standard.refinement.refiner_config import RefinerConfig
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode
from geosolver.runtime.deadline import runtime_session
sys.set_int_max_str_digits(100000)


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    if p.exists():raise FileExistsError(p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(dumps(v)+'\n')
def rational(x):
    if hasattr(x,'_mpf_'):
        sign,man,exp,_=x._mpf_
        return (-1 if sign else 1)*Q(man)*Q(2)**exp
    return Q(x)
def display(q):return str(q.numerator)+'/'+str(q.denominator)


def power_certificate(e,m,c=Q(1),lam=Q('1e-6'),floor=Q('1e-24'),delta=Q('1e-30'),tau=Q('1e-10'),target=Q('1e-70')):
    r=c*abs(e)**m;z=c*c*e**(2*m-2)/lam;boost=min(Q(256),lam/floor)
    b=(1+m*(m-1)*boost*z)/(1+m*m*boost*z)
    upper=min(Q(1),r/delta)*(1-b**m);lower=r*b**(5*m)
    pred='abstain'
    if r<=target:pred='target_initial'
    elif upper<tau and lower>target:pred='five_small_stall'
    elif m==1 and r*(lam/(c*c+lam))**4<=target:pred='target_within4'
    return {'prediction':pred,'r0':display(r),'z0':display(z),'I_upper':display(upper),
            'r5_lower':display(lower),'small_sufficient':upper<tau,'target_excluded':lower>target,
            'future_step_evaluations':0}


def native_stage(dsl,x,*,dps=100,iterations=80,lam='1e-6',floor='1e-24',target='1e-70',delta=None,residual_fn=None):
    identity=ensure_source();bundle=bundle_of(dsl);e=build_ir_evaluator(bundle);trace=[];calls=0
    mod=importlib.import_module('geosolver.engine.standard.refinement.mpmath_refiner')
    begun=time.monotonic();deadline=begun+60
    def observed(fn,kind):
        def call(**kw):
            rec={'kind':kind,'input':loads(dumps({k:v for k,v in kw.items() if k not in ('residual_fn','trial_filter')}))}
            trace.append(rec);result=fn(**kw);rec['output']=loads(dumps(result));return result
        return call
    old_hp=IREvaluator.evaluate_hp_residual
    def counted(*a,**k):
        nonlocal calls
        calls+=1;return old_hp(*a,**k)
    intervention=None
    with mp.workdps(250),ExitStack() as stack,runtime_session(deadline) as timings:
        cfg=dataclasses.replace(RefinerConfig(),damping_initial=mp.mpf(lam),damping_min=mp.mpf(floor),max_stage_iters=iterations)
        ref=MpmathRefiner(config=cfg)
        if delta is not None:
            source=textwrap.dedent(inspect.getsource(MpmathRefiner._run_stage));tree=ast.parse(source)
            matches=[n for n in ast.walk(tree) if isinstance(n,ast.Constant) and n.value=='1e-30']
            assert len(matches)==1
            old_ast=ast.dump(tree);matches[0].value=delta;modified=ast.unparse(tree)
            ns={};exec(compile(modified,'<research-stop-floor>','exec'),mod.__dict__,ns)
            matches[0].value='1e-30';assert ast.dump(tree)==old_ast
            intervention={'one_constant_only':True,'original_function_sha256':hashlib.sha256(source.encode()).hexdigest(),
                          'modified_function_sha256':hashlib.sha256(modified.encode()).hexdigest(),'delta':delta}
            stack.enter_context(patch.object(MpmathRefiner,'_run_stage',ns['_run_stage']))
        stack.enter_context(patch.object(IREvaluator,'evaluate_hp_residual',counted))
        for name,kind in [('compute_levenberg_marquardt_step','lm_step'),('run_line_search','line_search')]:
            stack.enter_context(patch.object(mod,name,observed(getattr(mod,name),kind)))
        with high_precision_mode():
            hf=e.evaluate_hp_hard_feasibility(x,precision=dps,include_margins=False)
        args={} if residual_fn is None else {'residual_fn':residual_fn}
        status,point,norm=ref._run_stage(bundle=bundle,evaluator=e,start_point=list(x),bounds=_convert_problem_bounds(bundle),
            dps=dps,target_residual=mp.mpf(target),preserve_hard_feasibility=hf.hard_feasible,**args)
        return {'source_hash':identity,'dsl':dsl,'input':x,'status':status,'point':point,'norm':norm,'trace':trace,
                'config':cfg,'target':mp.mpf(target),'dps':dps,'delta':delta or '1e-30','intervention':intervention,
                'hp_residual_calls':calls,'seconds':time.monotonic()-begun,'timings':dict(timings)}


def events(raw):
    result=[];lm=None
    with mp.workdps(300):
        for ev in raw['trace']:
            if ev['kind']=='lm_step':lm=ev
            elif ev['kind']=='line_search' and lm:
                out=ev.get('output');x=mp.matrix(ev['input']['point']);step=mp.matrix(lm['output'])
                improved=bool(out and out[-1]);new=mp.matrix(out[0]) if improved else x
                r=ev['input']['current_norm'];rn=mp.norm(out[1]) if improved else r
                result.append({'input':list(x),'output':list(new),'norm':r,'next_norm':rn,'lambda':lm['input']['damping'],
                    'full_step':improved and mp.norm(new-x-step)<=mp.mpf('1e-12')*max(mp.norm(step),mp.mpf('1e-300')),
                    'product_I':(r-rn)/max(r,mp.mpf(raw['delta'])),'true_I':(r-rn)/r if r else None,
                    'small':(r-rn)/max(r,mp.mpf(raw['delta']))<mp.mpf('1e-10')})
                lm=None
    return result


def powers(out):
    assert not out.exists();specs=[]
    for m in (1,2,4):
        for exponent in (5,11,21,73):
            e=Q(10)**(-exponent);c=Q(1)
            specs.append({'m':m,'e':display(e),'c':display(c),'certificate':power_certificate(e,m,c)})
    for exponent in (5,11,21):
        e=Q(10)**(-exponent);c=Q('1e-12')
        specs.append({'m':1,'e':display(e),'c':display(c),'certificate':power_certificate(e,1,c)})
    save(out/'forecast.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(Path(__file__)),
        'scope':'Development scalar models, not unknown natural problems. Initial rational inequalities, no future recurrence.',
        'scoring':'certified stall requires native stalled and5 accepted small steps; target certificate requires target within4; abstentions retain actual outcomes.',
        'rows':specs})
    rows=[]
    for i,s in enumerate(specs):
        with mp.workdps(250):
            eq=Q(s['e']);cq=Q(s['c']);x=mp.mpf(eq.numerator)/eq.denominator;c=mp.mpf(cq.numerator)/cq.denominator;m=s['m']
            dsl={'id':f'SCALAR-{i}','variables':['x'],'constructions':[],
                 'conditions':[{'left':f'x**{m}','operator':'=','right':0}],'target':'x'}
            def residual(v,precision):
                with mp.workdps(precision):return [c*v[0]**m]
            raw=native_stage(dsl,[x],residual_fn=residual);save(out/'runs'/f'{i}.json',raw)
            ev=events(raw);p=s['certificate']['prediction'];ok=None
            if p=='five_small_stall':ok=raw['status']=='stalled' and len(ev)==5 and all(e['small'] for e in ev)
            elif p.startswith('target_'):ok=raw['status']=='target_reached' and len(ev)<=4
            rows.append({'index':i,'m':m,'e':s['e'],'c':s['c'],'prediction':p,'status':raw['status'],'steps':len(ev),
                'certified_prediction_pass':ok,'all_full_steps':all(e['full_step'] for e in ev)})
    result={'forecast_sha256':sha(out/'forecast.json'),'rows':rows,'source_unchanged':ensure_source()}
    save(out/'summary.json',result);print(json.dumps(result))


def floor_pair(archive,out):
    source=archive/'development/damping-campaign-v1/runs/JMO-2013-PRE-05/0/original__floor_1e-48_carry_1.json'
    if not source.exists():raise FileNotFoundError(source)
    raw=loads(source.read_text());stage=next(e for e in raw['trace'] if e['kind']=='stage_boundary' and e['dps']==100)
    with mp.workdps(350):
        x=stage['input'];lam=stage['initial_damping']
        save(out/'protocol.json',{'source':str(source),'sha256':sha(source),'point':x,'lambda':lam,
            'intervention':'Only small-improvement denominator1e-30 ->1e-80. Same start, lambda,100dps,80iterations,1e-48 damping floor,1e-70 target.',
            'prediction':'Trajectories agree through baseline stop. Lower denominator delays floor-induced stop; no fixed later precision gain asserted.',
            'created_utc':datetime.now(timezone.utc).isoformat()})
        runs=[]
        for delta in (None,'1e-80'):
            rr=native_stage(raw['intervention_dsl'],x,lam=lam,floor='1e-48',delta=delta)
            save(out/('baseline.json' if delta is None else 'lower-denominator.json'),rr);runs.append(rr)
        ea,eb=map(events,runs);overlap=min(len(ea),len(eb));equal=all(dumps(a['output'])==dumps(b['output']) for a,b in zip(ea,eb))
        result={'protocol_sha256':sha(out/'protocol.json'),'steps':[len(ea),len(eb)],'statuses':[r['status'] for r in runs],
            'identical_prefix_coordinates':equal,'prefix_length':overlap,'delayed_stop':len(eb)>len(ea),
            'baseline_last5':ea[-5:],'intervention_at_baseline_last5':eb[max(0,len(ea)-5):len(ea)],
            'source_unchanged':ensure_source()}
        save(out/'summary.json',result)
        print(json.dumps({k:v for k,v in result.items() if 'last5' not in k}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['powers','floor']);p.add_argument('output',type=Path);p.add_argument('--archive',type=Path);a=p.parse_args()
    if a.mode=='powers':powers(a.output)
    else:floor_pair(a.archive,a.output)
