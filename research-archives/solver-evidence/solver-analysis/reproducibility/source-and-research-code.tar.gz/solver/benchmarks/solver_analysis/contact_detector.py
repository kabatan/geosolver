"""Input-only construction contact detector; deliberately incomplete.

No case identifiers, references, or observed outcomes enter the detection rule.
It proves incidence using the construction DAG and exact scalar algebra. A
positive result means a squared contact factor exists, not solver failure.
Nondegeneracy and goal sensitivity remain separate applicability conditions.
"""
from __future__ import annotations
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import sympy as sp


def tree(s):return ast.parse(str(s),mode='eval').body
def call(n,name):return isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id==name
def source(n):return ast.unparse(n)


class GeometryDAG:
    def __init__(self,dsl):
        self.nodes={v['name']:tree(v['expression']) for v in dsl['constructions']}
        self.variables=set(dsl['variables']);self.memo={}

    def deref(self,n,depth=0):
        if depth>30:raise ValueError('dependency depth')
        if isinstance(n,ast.Name) and n.id in self.nodes:return self.deref(self.nodes[n.id],depth+1)
        return n

    def scalar(self,n,depth=0):
        if depth>30:raise ValueError('dependency depth')
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):
            return sp.Rational(str(n.value))
        if isinstance(n,ast.Name):
            if n.id=='pi':return sp.pi
            if n.id in self.variables:return sp.Symbol(n.id,real=True)
            if n.id in self.nodes:return self.scalar(self.nodes[n.id],depth+1)
            raise ValueError('unsupported name')
        if isinstance(n,ast.Attribute) and n.attr in ('x','y'):
            return self.point(n.value,depth+1)[0 if n.attr=='x' else 1]
        if isinstance(n,ast.UnaryOp):
            v=self.scalar(n.operand,depth+1)
            if isinstance(n.op,ast.USub):return -v
            if isinstance(n.op,ast.UAdd):return v
        if isinstance(n,ast.BinOp):
            a,b=self.scalar(n.left,depth+1),self.scalar(n.right,depth+1)
            for op,fn in ((ast.Add,lambda:a+b),(ast.Sub,lambda:a-b),(ast.Mult,lambda:a*b),(ast.Div,lambda:a/b),(ast.Pow,lambda:a**b)):
                if isinstance(n.op,op):return fn()
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):
            funcs={'sqrt':sp.sqrt,'sin':sp.sin,'cos':sp.cos,'tan':sp.tan,'abs':sp.Abs}
            if n.func.id in funcs:return funcs[n.func.id](*(self.scalar(a,depth+1) for a in n.args))
        raise ValueError('unsupported scalar expression')

    def point(self,n,depth=0):
        n=self.deref(n)
        if call(n,'Point') and len(n.args)==2:return tuple(self.scalar(a,depth+1) for a in n.args)
        if call(n,'Midpoint') and len(n.args)==2:
            a,b=(self.point(v,depth+1) for v in n.args)
            return tuple((x+y)/2 for x,y in zip(a,b))
        raise ValueError('unsupported point expression')

    def on_line(self,p,a,b):
        # First use syntactic incidence; then a small exact algebra certificate.
        if source(p) in (source(a),source(b)):return {'method':'shared construction node'}
        try:
            P,A,B=(self.point(n) for n in (p,a,b))
            expr=(P[0]-A[0])*(B[1]-A[1])-(P[1]-A[1])*(B[0]-A[0])
            if sp.count_ops(expr)>300:return None
            z=sp.trigsimp(sp.cancel(expr))
            if z==0:return {'method':'exact collinearity identity','expression':str(expr),'simplified':'0'}
        except (ValueError,TypeError,ZeroDivisionError,RecursionError):pass
        return None

    def circle_points(self,n):
        v=self.deref(n)
        if call(v,'Circumcircle') and len(v.args)==3:return list(v.args)
        if call(v,'Circle') and len(v.args)==2:
            center,r=v.args;r=self.deref(r)
            if call(r,'Distance') and len(r.args)==2:
                a,b=r.args
                if source(a)==source(center):return [b]
                if source(b)==source(center):return [a]
            points=[]
            try:
                O=self.point(center);R=self.scalar(v.args[1])
                for name,node in self.nodes.items():
                    try:
                        P=self.point(node)
                        expr=(P[0]-O[0])**2+(P[1]-O[1])**2-R**2
                        if sp.count_ops(expr)<=300 and sp.trigsimp(sp.cancel(expr))==0:
                            points.append(ast.Name(id=name,ctx=ast.Load()))
                    except (ValueError,TypeError,ZeroDivisionError,RecursionError):pass
                return points
            except (ValueError,TypeError,ZeroDivisionError,RecursionError):pass
        return []


def detect(dsl):
    dag=GeometryDAG(dsl);found=[]
    for index,row in enumerate(dsl['conditions']):
        if row.get('operator')!='=':continue
        a,b=tree(row['left']),tree(row['right'])
        if isinstance(a,ast.Constant) and a.value==0:a,b=b,a
        if not (isinstance(b,ast.Constant) and b.value==0 and call(a,'IsTangent') and len(a.args)==2):continue
        lhs,rhs=a.args
        if call(dag.deref(rhs),'Line'):lhs,rhs=rhs,lhs
        line=dag.deref(lhs)
        if not (call(line,'Line') and len(line.args)==2):continue
        A,B=line.args
        for P in dag.circle_points(rhs):
            certificate=dag.on_line(P,A,B)
            if not certificate:continue
            p,u,v,c=map(source,(P,A,B,rhs))
            h=f'(Dot(Vector({p},Center({c})),Vector({u},{v}))/Distance({u},{v}))'
            found.append({'condition_index':index,'point':p,'line':source(lhs),'circle':c,
                'incidence_certificate':certificate,'contact_coordinate':h,
                'stable_gap':f'{h}**2/(Radius({c})+Distance(Center({c}),{source(lhs)}))',
                'factor_identity':'R^2=d^2+h^2; R-d=h^2/(R+d)',
                'local_contact_order':2,
                'domain_requirements':['original constructions defined','line endpoints distinct','R>0','R+d bounded away from zero'],
                'failure_prediction':'abstain until other-constraint and goal sensitivity checks'})
            break
    return {'detector_version':2,'contacts':found,'positive':bool(found),
        'coverage_limitation':'Only zero IsTangent(line,circle) constraints with certified construction incidence. Does not detect arbitrary algebraic implied incidences.'}


def transform(dsl,detection,mode):
    result=copy.deepcopy(dsl)
    for row in detection['contacts']:
        h=row['contact_coordinate']
        expression={'signed':h,'squared':f'{h}**2','stable_gap':row['stable_gap']}[mode]
        result['conditions'][row['condition_index']]={'left':expression,'operator':'=','right':0}
    return result


def prove_identity_rows(dsl):
    """Small, input-only exact prover; never infer identities from magnitude."""
    dag=GeometryDAG(dsl);proofs=[]
    for i,row in enumerate(dsl['conditions']):
        if row.get('operator')!='=':continue
        a,b=tree(row['left']),tree(row['right']);expr=None;method=None
        try:
            if ast.dump(a)==ast.dump(b):expr=sp.Integer(0);method='identical syntax'
            elif call(a,'Distance') and len(a.args)==2:
                A,B=(dag.point(v) for v in a.args);rhs=dag.scalar(b)
                if rhs.is_nonnegative:
                    expr=sum((x-y)**2 for x,y in zip(A,B))-rhs**2
                    method='squared point distance identity with nonnegative right side'
            elif call(a,'Collinear') and len(a.args)==3 and dag.scalar(b)==0:
                A,B,C=(dag.point(v) for v in a.args)
                expr=(B[0]-A[0])*(C[1]-A[1])-(B[1]-A[1])*(C[0]-A[0])
                method='exact oriented area identity'
            else:expr=dag.scalar(a)-dag.scalar(b);method='exact scalar identity'
            if expr is not None and sp.count_ops(expr)<=300 and sp.trigsimp(sp.cancel(expr))==0:
                proofs.append({'condition_index':i,'method':method,'expression':str(expr),
                    'simplified':'0','domain':'original expression and constructions defined'})
        except (ValueError,TypeError,ZeroDivisionError,RecursionError):pass
    return proofs


def scan(inputs,out):
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);rows=[]
    for p in inputs:
        dsl=json.loads(p.read_text());r=detect(dsl)
        rows.append({'case_id':dsl['id'],'path':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**r})
        if r['positive']:
            for mode in ('signed','squared','stable_gap'):
                changed=transform(dsl,r,mode)
                from geosolver.problem.models import GeometryProblem
                from geosolver.problem.validation import validate
                report=validate(GeometryProblem.model_validate(changed))
                if not report.valid:raise ValueError((dsl['id'],mode,report))
                target=out/'variants'/dsl['id']/(mode+'.json');target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(json.dumps(changed,indent=2)+'\n')
    receipt={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'uses_reference':False,
        'uses_solver_outcome':False,'inputs':len(rows),'positives':sum(r['positive'] for r in rows),'rows':rows}
    (out/'scan.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'inputs':len(rows),'positives':[r['case_id'] for r in rows if r['positive']]}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('inputs',nargs='+',type=Path)
    a=p.parse_args();scan(a.inputs,a.output)
