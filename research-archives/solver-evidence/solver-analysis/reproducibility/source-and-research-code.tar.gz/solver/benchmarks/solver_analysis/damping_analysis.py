"""Paired assessment of the damping reset/floor and residual scale experiments."""
import argparse
import json
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from natural_evidence import jmo
from stage_analysis import digits


def stage_step_counts(trace):
    # lm_step's top-level dps is the ambient arithmetic context (180 here).
    # The stage_boundary records the requested residual/Jacobian precision.
    current=None;counts={}
    for event in trace:
        if event['kind']=='stage_boundary':current=event['dps']
        elif event['kind'] in ('_run_findroot_closure','_run_rank_aware_findroot'):current=None
        elif event['kind']=='lm_step' and current is not None:counts[current]=counts.get(current,0)+1
    return counts


def analyze(campaign,out):
    if out.exists():raise FileExistsError(out)
    completion=json.loads((campaign/'completion.json').read_text())
    if completion['completed']!=completion['planned']:raise ValueError('incomplete campaign')
    out.mkdir(parents=True);pairs=[];scales=[];stage_rows=[]
    with mp.workdps(600):
        for directory in sorted((campaign/'runs/JMO-2013-PRE-05').iterdir(),key=lambda p:int(p.name)):
            records={p.stem:loads(p.read_text()) for p in directory.glob('original__*.json')}
            for name,r in records.items():
                for stage in [t for t in r['trace'] if t['kind']=='stage_boundary']:
                    v=stage.get('output')
                    stage_rows.append({'point_index':int(directory.name),'condition':name,'dps':stage['dps'],
                        'input_point':stage['input'],
                        'initial_damping':stage['initial_damping'],'carried':stage['carried'],
                        'status':v[0] if v else 'interrupted','goal_digits':digits(jmo(v[1])['goal_error']) if v else None})
            for floor in ('1e-12','1e-24','1e-48'):
                names=[f'original__floor_{floor}_carry_{c}' for c in (0,1)]
                if not all(n in records for n in names):
                    pairs.append({'point_index':int(directory.name),'floor':floor,'missing_conditions':[n for n in names if n not in records]});continue
                a,b=[records[n] for n in names]
                row={'point_index':int(directory.name),'external_seed':a['point']['external_seed'],'floor':floor}
                starts=[next((t['input'] for t in r['trace'] if t['kind']=='stage_boundary' and t['dps']==100),None) for r in (a,b)]
                row['stage100_start_coordinates_identical']=starts[0]==starts[1] if all(v is not None for v in starts) else None
                row['stage100_start_points']=starts
                for label,r in [('reset',a),('carry',b)]:
                    at100=next((t.get('output') for t in r['trace'] if t['kind']=='stage_boundary' and t['dps']==100),None)
                    steps=[t for t in r['trace'] if t['kind']=='lm_step']
                    row[label]={'status':r['status'],'error':r['error'],'goal_digits':digits(jmo(r['pre_verifier_point'])['goal_error']),
                        'stage100_goal_digits':digits(jmo(at100[1])['goal_error']) if at100 else None,
                        'stage100_status':at100[0] if at100 else 'not_entered','stage100_steps':stage_step_counts(r['trace']).get(100,0),
                        'all_lm_steps':len(steps),'numeric_seconds':r['numeric_seconds'],'censored':r['safety_deadline_hit']}
                row['goal_digit_gain']=row['carry']['goal_digits']-row['reset']['goal_digits']
                if row['carry']['stage100_goal_digits'] is not None and row['reset']['stage100_goal_digits'] is not None:
                    row['stage100_goal_digit_gain']=row['carry']['stage100_goal_digits']-row['reset']['stage100_goal_digits']
                pairs.append(row)
            base=records.get('original__scale_1_covariant_1')
            if base:
                base_steps=[t for t in base['trace'] if t['kind']=='lm_step']
                for name,r in records.items():
                    if '__scale_' not in name or r is base:continue
                    steps=[t for t in r['trace'] if t['kind']=='lm_step'];errors=[]
                    for a,b in zip(base_steps,steps):
                        if 'output' not in a or 'output' not in b:continue
                        errors.append(mp.norm(mp.matrix(a['output'])-mp.matrix(b['output']))/max(mp.mpf('1e-500'),mp.norm(mp.matrix(a['output']))))
                    scales.append({'point_index':int(directory.name),'condition':name,'paired_steps':len(errors),
                        'baseline_steps':len(base_steps),'intervention_steps':len(steps),'maximum_relative_step_error':max(errors,default=None),
                        'goal_digit_difference':digits(jmo(r['pre_verifier_point'])['goal_error'])-digits(jmo(base['pre_verifier_point'])['goal_error'])})
    for name,rows in [('carry-pairs',pairs),('scale-pairs',scales),('stages',stage_rows)]:
        (out/(name+'.jsonl')).write_text(''.join(dumps(v)+'\n' for v in rows))
    import statistics
    def median_or_none(values):
        values=list(values)
        return statistics.median(values) if values else None
    summary=[]
    for floor in ('1e-12','1e-24','1e-48'):
        v=[r for r in pairs if r['floor']==floor and 'goal_digit_gain' in r]
        summary.append({'floor':floor,'planned_pairs':sum(r['floor']==floor for r in pairs),
            'pairs':len(v),'median_goal_digit_gain':median_or_none(r['goal_digit_gain'] for r in v),
            'both_entered_stage100':sum('stage100_goal_digit_gain' in r for r in v),
            'identical_stage100_start_pairs':sum(r['stage100_start_coordinates_identical'] is True for r in v),
            'median_stage100_gain':median_or_none(r['stage100_goal_digit_gain'] for r in v if 'stage100_goal_digit_gain' in r),
            'reset_100_five_steps':sum(r['reset']['stage100_steps']==5 for r in v),
            'carry_100_five_steps':sum(r['carry']['stage100_steps']==5 for r in v),
            'reset_censored':sum(r['reset']['censored'] for r in v),
            'carry_censored':sum(r['carry']['censored'] for r in v)})
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('campaign',type=Path);p.add_argument('output',type=Path);a=p.parse_args();analyze(a.campaign,a.output)
