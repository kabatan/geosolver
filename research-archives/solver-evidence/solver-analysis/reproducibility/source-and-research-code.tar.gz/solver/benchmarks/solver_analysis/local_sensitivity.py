"""Finite-point sensitivity diagnostics, explicitly not root-order certificates.

All SVD operations retain mpmath precision. Difference discrepancies are
empirical error indicators, not interval enclosures or root-distance bounds.
"""
from mpmath import mp


def matrix(rows, n):
    return mp.matrix(rows) if rows else mp.matrix(0, n)


def spectrum(a, n, error=0):
    if a.rows == 0:
        return {'singular_values': [], 'rank': 0, 'threshold': mp.mpf(0),
                'nullspace': mp.eye(n), 'error_indicator': error}
    _, s, v = mp.svd(a, full_matrices=True)
    tol = max(mp.mpf('1e-7'), mp.mpf('1e-6') * max(s, default=0), 10 * error)
    rank = sum(z > tol for z in s)
    null = mp.matrix(n, n-rank)
    for i in range(n):
        for j in range(n-rank):
            null[i,j] = v[rank+j,i]
    return {'singular_values': list(s), 'rank': rank, 'threshold': tol,
            'nullspace': null, 'error_indicator': error}


def diagnose(jraw, jother, jcontact, gradient, *, derivative_error=0,
             probe_domain_stable=True, has_contact=True, local_feasible=True):
    n = jraw.cols
    other_norms = [mp.norm(jother[i,:]) for i in range(jother.rows)]
    tiny = [i for i,z in enumerate(other_norms) if z <= mp.mpf('1e-25')]
    # Zero derivatives at a finite point are not proofs of identity. The caller
    # must remove only rows with an independently recorded algebraic proof.
    jf = matrix([[z/max(1,other_norms[i]) for z in jother[i,:]]
                 for i in range(jother.rows)], n)
    jh = matrix([[z/max(1,mp.norm(jcontact[i,:])) for z in jcontact[i,:]]
                 for i in range(jcontact.rows)], n)
    f = spectrum(jf,n,derivative_error)
    a = spectrum(matrix(list(jf.tolist())+list(jh.tolist()),n),n,derivative_error)
    r = spectrum(jraw,n,derivative_error)
    nh = jh*f['nullspace']
    contact = spectrum(nh,nh.cols,derivative_error) if nh.cols else {'singular_values':[],'rank':0,'threshold':mp.mpf(0),'error_indicator':derivative_error}
    expected = min(jh.rows,n-f['rank'])
    all_transverse = contact['rank'] == expected and expected > 0
    weak = mp.norm(gradient*f['nullspace']) if f['nullspace'].cols else mp.mpf(0)
    gauge = mp.norm(gradient*a['nullspace']) if a['nullspace'].cols else mp.mpf(0)
    if not has_contact: label='no_detected_constructed_contact'
    elif not local_feasible: label='abstain_not_local_feasible'
    elif not probe_domain_stable: label='abstain_probe_domain_or_branch'
    elif tiny: label='abstain_unresolved_small_other_rows'
    elif not all_transverse: label='abstain_incomplete_transverse_sensitivity'
    elif gauge > mp.mpf('1e-5'): label='current_goal_sensitive_on_apparent_augmented_kernel'
    elif weak > mp.mpf('1e-5'): label='current_goal_sensitive_on_apparent_other_kernel'
    else: label='current_goal_gradient_small_on_apparent_other_kernel'
    return {'classification':label,'root_goal_order_prediction':'abstain_no_root_order_certificate',
        'scope':'current sampled point only; apparent numerical ranks are not mathematical dimensions',
        'raw':r,'other':f,'augmented':a,'transverse_contact':contact,
        'expected_transverse_rank':expected,'all_transverse_numerically_resolved':all_transverse,
        'unresolved_small_other_rows':tiny,'current_weak_goal':weak,'current_gauge_goal':gauge,
        'probe_domain_stable':probe_domain_stable,
        'error_scope':'difference-step/precision discrepancy; no rigorous truncation or rounding enclosure'}


def regression_checks():
    with mp.workdps(100):
        w=mp.mpf('4e-5')
        square=diagnose(mp.matrix([[2*w]]),mp.matrix(0,1),mp.matrix([[1]]),mp.matrix([[2*w]]))
        tiny=diagnose(mp.matrix([[0,mp.mpf('1e-30')]]),mp.matrix([[0,mp.mpf('1e-30')]]),mp.matrix([[1,0]]),mp.matrix([[1,0]]))
        partial=diagnose(mp.eye(2),mp.matrix(0,2),mp.diag([1,mp.mpf('1e-12')]),mp.matrix([[1,1]]))
        assert square['root_goal_order_prediction'].startswith('abstain')
        assert square['classification']=='current_goal_sensitive_on_apparent_other_kernel'
        assert tiny['classification']=='abstain_unresolved_small_other_rows'
        assert tiny['unresolved_small_other_rows']==[0]
        assert partial['classification']=='abstain_incomplete_transverse_sensitivity'
        return {'square_goal_at_nonroot':square,'small_regular_constraint':tiny,'partial_transversality':partial}
