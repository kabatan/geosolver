"""UKMT source-to-DSL adaptation; choices/answer keys are never solver input."""
from unknown_authoring import put,eq,gt,lt,pred,pos,segment


def regular(prefix,n,r='1'):
    return [(f'{prefix}{i}',f'Point(({r})*cos(2*{i}*pi/{n}),({r})*sin(2*{i}*pi/{n}))') for i in range(n)]


def ukmt():
    out=[]
    put(out,'UKMT-SMC-2024-04','x',[],[eq('x+7*x+x**2',180),gt('x')],
        'max(x,7*x,x**2)','Angles in degrees satisfy the triangle angle sum. The largest of the three expressions is evaluated without choosing its identity from the answer choices.')
    put(out,'UKMT-SMC-2024-15','s t',[
        ('J','Point(0,s)'),('K','Point(0,0)'),('L','Point(s,0)'),('M','Point(s,s)'),
        ('N','Point(0,t)'),('P','Point(t,0)'),('O','Point(t,t)')],
        [eq('Distance(N,L)',10),eq('Area(J,K,L,M)-Area(N,K,P,O)',62)]+pos('t')+[gt('s','t')],
        'Distance(K,N)','Rendered shading is the whole large square outside the small square. NL is a measurement line, not a boundary that removes another triangle.')
    put(out,'UKMT-SMC-2024-18','r',[],
        [eq('(pi*r**2-pi)/10','pi/4'),gt('r',1)],'r-1',
        'Rendered figure has four inner sectors and ten annular sectors, each of equal area. Outer radial piece length equals outer radius minus1.')
    put(out,'UKMT-SMC-2024-22','b fx fy i k j',[
        ('G','Point(0,0)'),('H','Point(b,0)'),('F','Point(fx,fy)'),
        ('I','Point((1-i)*fx+i*b,(1-i)*fy)'),('K','Point(k*fx,k*fy)'),('J','Point(j*fx,j*fy)')],
        [eq('Area(G,K,I)',12),eq('Area(K,J,I)',8),eq('Area(J,F,I)',4),eq('Area(G,I,H)',8)]+
        pos('b','fy','i','k')+[lt('i',1),lt('k','j'),lt('j',1)],'Area(I,K,H)',
        'The rendered order is G-K-J-F on sideGF and F-I-H on sideFH. Shapes remain free subject to the four subareas; target area is not substituted by an area-ratio theorem.')
    put(out,'UKMT-SMC-2022-13','a b c',[],
        [eq('a+b+c',60),eq('a+2*b+3*c',90),eq('b',12)]+
        [{'left':x,'operator':'>=','right':0} for x in ('a','b','c')], 'c',
        'Area-bookkeeping control: a,b,c are areas covered by exactly1,2,3 rugs. Source guarantees floor coverage. This abstract region-area representation is reported separately from spatial configuration discovery. Replaced the semantically underspecified hat diagram before outcomes.')
    put(out,'UKMT-SMC-2024-25','r',[
        ('X','Point(0,0)'),('Y','Point(r,0)'),('Z','Point(r*cos(pi/6),r*sin(pi/6))'),
        ('P','Point(r*cos(pi/3),r*sin(pi/3))')],
        [eq('pi*r**2/2',24),gt('r')],
        '3*(r**2*(2*pi/3-sin(2*pi/3))/2)-3*(r**2*(pi/2-sin(2*pi/3))/2)',
        'Diagram shades points belonging to exactly two of three semicircles. Centers X,Y,Z are radius r apart from X with angleYXZ30deg; the third diameter begins at X in directionXZ. Each pair intersection area is r²(2pi/3-sin(2pi/3))/2; triple intersection is r²(pi/2-sin(2pi/3))/2 by two polar sectors. Inclusion-exclusion gives sum(pair areas)-3*triple area. This source-derived area formula is an authoring reduction, not a solver-discovered geometry; an independent derivation is required before reference certification.')
    put(out,'UKMT-SMC-2023-03','b h',[
        ('A','Point(0,0)'),('B','Point(b,0)'),('C','Point(0,h)'),('Bp','Point(6*b/5,0)'),('Cp','Point(0,17*h/20)')],
        pos('b','h'),'100*(Area(A,Bp,Cp)/Area(A,B,C)-1)',
        'All positive original bases and heights retained; target is signed percentage change, not an answer-choice label.')
    put(out,'UKMT-SMC-2023-05','x y',[
        ('A','Point(0,0)'),('B','Point(6,0)'),('C','Point(x,y)'),
        ('omegaA','Circle(A,3)'),('omegaB','Circle(B,3)'),('omegaC','Circle(C,2)')],
        [eq('Distance(A,C)',5),eq('Distance(B,C)',5),gt('y')],'Area(A,B,C)',
        'Rendered circles are externally tangent. The two radius3 centers are fixed6 apart, and both remaining center distances equal3+2. Reflection fixes y>0.')
    put(out,'UKMT-SMC-2023-13','',[
        *[(p,f'Point(cos(2*{i}*pi/5),sin(2*{i}*pi/5))') for i,p in enumerate('PQRST')],
        ('U','Intersect(Line(S,T),PerpendicularLine(Line(P,Q),P))')],
        segment('U','S','T',True),'Angle(P,U,T)/Angle(P,T,U)',
        'Regular pentagon normalized to a unit circle; U is the source perpendicular intersection. Adaptation returns one component ratio of the requested angle triple.')
    put(out,'UKMT-SMC-2023-14','d',[
        ('O','Point(0,0)'),('P','Point(d,-d)'),('Q','Point(12-d,2*d-6)')],
        [eq('Distance(O,P)','Distance(O,Q)'),gt('Distance(O,P)')],'d',
        'Adaptation returns both possible d values separately, not their source sum. Positive common radius excludes a degenerate circle; this does not discard either valid source value.')
    put(out,'UKMT-SMC-2023-21','s',[
        ('Q','Point(0,0)'),('R','Point(s,0)'),('P','Point(s/2,s*sqrt(3)/2)'),
        ('O','Point(P.x+sqrt(3)/2,P.y-3/2)'),('X','ClosestPoint(O,Line(Q,R))'),('E','Point(P.x+sqrt(3),P.y-3)')],
        [eq('Distance(O,Line(Q,R))','sqrt(3)'),gt('s')]+segment('X','Q','R',True)+segment('E','P','R',True),
        'Distance(Q,X)','The semicircle diameter starts at P and runs along PR, length2sqrt3. Center O is one radius fromP; the curved edge is tangent toQR at its perpendicular foot. Diameter endpoint is retained onPR as drawn.')
    put(out,'UKMT-SMC-2023-23','',[
        ('A','Point(0,0)'),('B','Point(3,0)'),('C','Point(3,1)'),('D','Point(0,1)'),('M','Midpoint(A,C)'),
        ('fold','PerpendicularLine(Line(A,C),M)'),('E','Intersect(fold,Line(A,B))'),('F','Intersect(fold,Line(D,C))'),('Dp','Reflect(D,fold)')],
        [],'Area(E,B,C,Dp,F)/Area(A,B,C,D)',
        'Folding A to opposite vertex C forces the perpendicular bisector ofAC. Rendered/native geometry gives union boundary E-B-C-reflected(D)-F. This boundary order follows exact half-plane and intersection checks, to be certified independently; scale normalized to3 by1.')
    hexagon=regular('H',6)
    put(out,'UKMT-SMC-2023-24','x y s',[
        *hexagon,('A','Point(x-s/2,y+s/2)'),('B','Point(x+s/2,y+s/2)'),('C','Point(x+s/2,y-s/2)'),('D','Point(x-s/2,y-s/2)')],
        sum([segment(p,a,b,True) for p,a,b in [('A','H2','H3'),('B','H0','H1'),('C','H5','H0'),('D','H3','H4')]],[])+[gt('s')],
        's','Rendered inscribed square has horizontal/vertical sides, with its four vertices on the four sloping hexagon edges. The center is solved, not assumed from symmetry.')
    put(out,'UKMT-SMC-2022-04','',[
        ('A','Point(0,0)'),('B','Point(5,0)'),('C','Point(5,5)'),('D','Point(0,5)'),
        ('P','Point(3/2,3/2)'),('Q','Point(7/2,3/2)'),('R','Point(7/2,7/2)'),('S','Point(3/2,7/2)')],
        [],'Area(P,Q,R,S)/Area(A,B,C,R,Q,P)',
        'Rendered shading follows the outer lower-right triangle with the lower-right half of the centered inner square removed; polygon A-B-C-R-Q-P is its exact boundary.')
    edges=[('E0','Line(H0,H2)'),('E1','Line(H2,H4)'),('E2','Line(H4,H0)'),
           ('E3','Line(H1,H3)'),('E4','Line(H3,H5)'),('E5','Line(H5,H1)')]
    points=[('P0','Intersect(E0,E3)'),('P1','Intersect(E0,E5)'),('P2','Intersect(E2,E5)'),
            ('P3','Intersect(E2,E4)'),('P4','Intersect(E1,E4)'),('P5','Intersect(E1,E3)')]
    put(out,'UKMT-SMC-2022-08','r',regular('H',6,'r')+edges+points,
        [eq('Area(H0,H1,H2,H3,H4,H5)',216),gt('r')],'Area(P0,P1,P2,P3,P4,P5)',
        'Rendered central hexagon is the intersection of triangles H0H2H4 andH1H3H5. All six boundary intersections are constructed explicitly, preserving line domains.')
    put(out,'UKMT-SMC-2022-14','',[
        ('K','Point(0,1)'),('L','Point(1,1)'),('M','Point(1,0)'),('N','Point(0,0)'),
        ('P','Point(1/3,1)'),('Q','Point(1,2/3)'),('R','Point(2/3,0)'),('S','Point(0,1/3)'),
        *[(v,f'Point((2*{a}.x+{b}.x)/3,(2*{a}.y+{b}.y)/3)') for v,a,b in zip('TUVW','PQRS','QRSP')]],
        [],'Area(T,U,V,W)/Area(K,L,M,N)',
        'Two sequential ratio1:2 divisions construct the nested squares, with the same cyclic orientation as the rendered source.')
    put(out,'UKMT-SMC-2022-17','',regular('P',8,'1/(2*sin(pi/8))')+[
        ('A','Point(0,0)'),('B','Point(1,0)'),('C','Point(1/2,sqrt(3)/2)')],
        [],'Area(P0,P1,P2,P3,P4,P5,P6,P7)-4*Area(A,B,C)',
        'Rendered four removed equilateral triangles are disjoint; subtracting their areas does not assume an optimization result.')
    put(out,'UKMT-SMC-2022-20','x y s',[
        ('O','Point(0,0)'),('omega','Circle(O,10)'),('A','Point(x-s/2,y+s/2)'),('B','Point(x+s/2,y+s/2)'),
        ('C','Point(x+s/2,y-s/2)'),('D','Point(x-s/2,y-s/2)')],
        [eq('A.x','A.y'),eq('B.x','-B.y'),eq('OnCircle(C,omega)'),eq('OnCircle(D,omega)'),gt('s'),lt('A.y',0),lt('B.y',0)],
        'Area(A,B,C,D)','The quadrant points downward with its two radius rays at45degrees. Adjacent top vertices are on rays and bottom vertices on the arc; the square center is not pre-assumed.')
    put(out,'UKMT-SMC-2022-21','',[
        ('A','Point(0,0)'),('B','Point(0,2)'),('C','Point(2,0)')],
        [],'2*(Area(A,B,C)+pi*(Distance(B,C)/2)**2/2-pi*(Distance(A,C)/2)**2/2)',
        'One lobe is triangleABC plus the external semicircle onBC minus the small semicircle onAC. The other lobe is its half-turn. Their interiors do not overlap in the rendered source.')
    put(out,'UKMT-SMC-2022-23','',[
        ('P','Point(0,0)'),('O','Point(sqrt(10),0)'),('N','Point(sqrt(10)+sqrt(90),0)'),('M','Point(sqrt(10)+sqrt(90)+sqrt(40),0)'),
        ('G','Point(P.x,sqrt(10))'),('H','Point(O.x,sqrt(90))'),('J','Point(N.x,sqrt(90))'),('K','Point(M.x,sqrt(40))'),
        ('I','Intersect(Line(G,H),Line(J,K))'),('F','Intersect(Line(G,H),Line(P,M))'),('L','Intersect(Line(J,K),Line(P,M))')],
        [],'Area(F,I,L)','Rendered side order is G,H onFI andJ,K onIL, with squares adjacent along the baseline. Positive square side lengths are square roots of the source areas; no triangle area formula is pre-solved.')
    return out
