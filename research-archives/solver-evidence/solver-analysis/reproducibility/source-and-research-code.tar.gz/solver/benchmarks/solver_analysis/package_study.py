"""Seal a completed study and archive the exact source used to reproduce it.

Raw measurements stay in their existing archive; the index covers every file
except rebuildable draft rendering caches and the private report environment.
The small source archive is separate from the multi-gigabyte measurement tree.
"""
import argparse,hashlib,json,tarfile
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
REQUIRED=(
    'report/research-report-ja.md','report/research-report-ja.pdf',
    'report/research-report-ja.manifest.json','report/research-report-ja.render.json',
    'report/qa-final-v1/receipt.json','report/figures/figure-manifest.json',
    'audits/03-adoption-decision.json','audits/04-final-review-response.md',
    'analysis/detail-v1/summary.json','analysis/stage-v3/receipt.json',
    'analysis/development-comparisons-v1/summary.json','analysis/lm-events-v1/summary.json',
    'analysis/prediction-mid-v1/summary.json','analysis/prediction-final-v1/summary.json',
    'analysis/finite-lm-mid-v3/summary.json','analysis/finite-lm-final-v1/summary.json',
    'unknown-intake/rootfree-stop-v1/protocol.json',
    'unknown-intake/rootfree-stop-v1/predictions.json',
    'unknown-intake/rootfree-stop-v1/assessment.json',
    'unknown-intake/rootfree-stop-v1/independent-checks.json',
    'development/initial-stop-certificates-v1/summary.json',
    'development/denominator-pair-v1/summary.json',
)


def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()


def excluded(rel):
    return ('__pycache__' in rel.parts or '.venv' in rel.parts or
            rel.parts[0]=='reproducibility' or
            any(x.startswith('qa-draft-') for x in rel.parts) or
            ('pdf-assets' in rel.parts))


def package(archive):
    missing=[name for name in REQUIRED if not (archive/name).exists()]
    if missing:raise ValueError('Required final evidence is missing: '+', '.join(missing))
    from stage_replay import ensure_source
    product_source_hash=ensure_source()
    destination=archive/'reproducibility'
    if destination.exists():raise FileExistsError(destination)
    destination.mkdir()
    report_manifest=json.loads((archive/'report/research-report-ja.manifest.json').read_text())
    assert not report_manifest['draft'] and not report_manifest.get('review') and not report_manifest['missing_interpretation_fragments']
    for rel,wanted in report_manifest['source_files'].items():
        assert digest(archive/rel)==wanted,rel
    figures=json.loads((archive/'report/figures/figure-manifest.json').read_text())
    for rel,wanted in figures['inputs'].items():
        assert digest(archive/rel)==wanted,rel
    assert digest(ROOT/'benchmarks/solver_analysis/report_figures.py')==figures['script_sha256']
    render=json.loads((archive/'report/research-report-ja.render.json').read_text())
    assert digest(archive/'report/research-report-ja.md')==render['source_sha256']
    assert digest(archive/'report/research-report-ja.pdf')==render['pdf_sha256']
    assert not render.get('missing_glyphs') and not render['unhandled_token_types']
    qa=json.loads((archive/'report/qa-final-v1/receipt.json').read_text())
    assert qa['pdf_sha256']==render['pdf_sha256'] and qa['all_pages_inspected'] is True
    files=[]
    for p in sorted(archive.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        rel=p.relative_to(archive)
        if excluded(rel):continue
        before=p.stat();h=digest(p);after=p.stat()
        if before.st_mtime_ns!=after.st_mtime_ns or before.st_size!=after.st_size:raise RuntimeError('File changed while sealing: '+str(p))
        files.append({'path':str(rel),'bytes':after.st_size,'sha256':h})
    index=destination/'archive-files.jsonl'
    index.write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in files))
    code=[]
    for base in ('src/geosolver','benchmarks/solver_analysis','benchmarks/dsl'):
        code.extend(p for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'))
    code.extend((ROOT/'benchmarks').glob('*.py'))
    code.extend(ROOT/n for n in ('pyproject.toml','uv.lock','README.md','benchmarks/cases.jsonl') if (ROOT/n).exists())
    code.extend(ROOT.glob('LICENSE*'))
    source_index=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(set(code))]
    (destination/'source-files.json').write_text(json.dumps(source_index,indent=2)+'\n')
    tarpath=destination/'source-and-research-code.tar.gz'
    with tarfile.open(tarpath,'w:gz',compresslevel=6) as tar:
        for p in sorted(set(code)):
            info=tar.gettarinfo(str(p),arcname='solver/'+str(p.relative_to(ROOT)))
            info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            with p.open('rb') as f:tar.addfile(info,f)
    receipt={'created_utc':datetime.now(timezone.utc).isoformat(),
        'baseline_commit':'e703e2d99484793f162f961bc50126ae65e4069f',
        'product_source_hash':product_source_hash,
        'archive_root':str(archive),'file_count':len(files),'indexed_bytes':sum(v['bytes'] for v in files),
        'file_index_sha256':digest(index),'source_archive':str(tarpath),'source_archive_sha256':digest(tarpath),
        'source_files':len(source_index),'final_report_sha256':render['source_sha256'],'final_pdf_sha256':render['pdf_sha256'],
        'excluded':'report .venv, Python caches, reproducibility directory itself, draft page PNGs, rebuildable PDF math assets',
        'external_history':'Historical archives are referenced by immutable paths and prior stream-hash receipts under history; not duplicated in this package.',
        'script_sha256':digest(Path(__file__))}
    (destination/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);package(p.parse_args().archive)
