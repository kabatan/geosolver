"""Supplement: initial-state certificates after a fixed, reference-blind pilot.

This is manual structural analysis of two preselected natural inputs. It is not
an automatic detector, a new population sample, or a prediction of final goal
success. Predictor mode reads only the pilot states and fixed control constants.
"""
import argparse,copy,hashlib,json,random,time
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction as Q
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from mpmath import mp
from exact_codec import loads,dumps
from finite_stop_test import native_stage,events,rational,display,save,sha
from paired_stages import bundle_of,WorkLimit
from stage_replay import ensure_source
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.engine.standard.evaluation.classify_evaluation_failure import EvaluationStatus
from geosolver.engine.standard.problem.infer_problem_bounds import infer_problem_bounds

POS='CEMC-EUCLID-2026-08A';NEG='HMMT-NOV-2025-GUTS-12'
CFG={'seed':20260911,'points':64,'starts':4,'float_calls_per_start':256,
     'pilot_dps':50,'pilot_iterations':80,'pilot_target':'1e-35','floor':'1e-24',
     'next_dps':100,'next_iterations':80,'next_target':'1e-70','lambda0':'1e-6','delta':'1e-30','tau':'1e-10'}


def prepare(archive,out):
    assert not out.exists();items=[]
    for ident in (POS,NEG):
        source=archive/f'unknown-intake/final-extension-corpus-v1/dsl/{ident}.json'
        orig=json.loads(source.read_text());d=copy.deepcopy(orig)
        if ident==POS:
            d['variables']=['x']
            for c in d['constructions']:
                if c['name']=='C':c['expression']='Point(x,sqrt(9-(x-1)**2))'
            d['conditions']=[orig['conditions'][0],{'left':'x','operator':'>','right':-2},{'left':'x','operator':'<','right':4}]
        p=out/'inputs'/(ident+'.json');save(p,d)
        # Explicit interval for the input-derived semicircle; otherwise the
        # unchanged solver's bounds inference. Neither uses a root location.
        bounds=[(-2.,4.)] if ident==POS else infer_problem_bounds(bundle_of(d))
        items.append({'case_id':ident,'model':'rational_contact' if ident==POS else 'affine_contact',
            'source':str(source),'source_sha256':sha(source),'dsl':str(p),'dsl_sha256':sha(p),'bounds':bounds})
    save(out/'protocol.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'source_hash':ensure_source(),
        'script_sha256':sha(Path(__file__)),'config':CFG,'items':items,
        'information':'Input-derived chart and guard, seeded uniform initial points, fixed float and50dps pilot. No root-centered perturbations, references, target evaluation or future trajectories in predictor.',
        'scope':'Two manually selected final extension natural cases; not the original30-case population, not an automatic recognizer. Factor proof may expose a root but root coordinates do not initialize the pilot.',
        'theorem':'Exact arithmetic/derivatives and full accepted steps in guard. Predictions are conditional on this native realization; finite differences and rounding are measured separately.',
        'certificate':'Positive: D=9r0/max(floor,lambda0/256), eta=min(1,r0/delta); certify5small if D<1,eta D<tau,r0(1-D)^5>T. Negative: certify target<=4 if r0*(lambda0/(49+lambda0))^4<=T. Else abstain.',
        'falsification':'Non-abstaining prediction disagrees with event under full-step/guard assumptions; all failures and abstentions retained.',
        'scoring':'5small means stalled with exactly5 accepted small steps; target prediction means target_reached within4. All8 starts are at most2 natural problem clusters.'})


def pilot(out):
    prot=loads((out/'protocol.json').read_text());assert not (out/'states.json').exists();allstates=[]
    for item in prot['items']:
        d=json.loads(Path(item['dsl']).read_text());assert sha(Path(item['dsl']))==item['dsl_sha256']
        e=build_ir_evaluator(bundle_of(d));rng=random.Random(CFG['seed']);bounds=item['bounds'];rows=[];calls=0
        begin=time.monotonic()
        def evaluate(x,stage):
            nonlocal calls
            calls+=1;fv=e.evaluate_float_residual(x);valid=fv.evaluation_status is EvaluationStatus.OK
            guard=bool(e.evaluate_guard(x)[0]) if valid else False
            hard=e.evaluate_float_hard_feasibility(x,include_margins=False).hard_feasible if valid else False
            f=np.asarray(fv.residual_vector,dtype=float) if valid else np.full(len(d['conditions']),1e6)
            rows.append({'x':list(map(float,x)),'stage':stage,'valid':valid,'guard':guard,'hard':hard,'norm':float(np.linalg.norm(f))})
            return f
        for _ in range(CFG['points']):evaluate([rng.uniform(a,b) for a,b in bounds],'uniform')
        eligible=sorted((r for r in rows if r['valid'] and r['guard'] and r['hard']),key=lambda r:r['norm'])[:CFG['starts']]
        for i,start in enumerate(eligible):
            count=calls;first=len(rows);status='completed'
            def fun(x):
                if calls-count>=CFG['float_calls_per_start']:raise WorkLimit('fixed actual call cap')
                return evaluate(x,f'least_squares_{i}')
            try:
                least_squares(fun,start['x'],bounds=([p[0] for p in bounds],[p[1] for p in bounds]),x_scale='jac',
                    max_nfev=CFG['float_calls_per_start'],ftol=1e-12,xtol=1e-12,gtol=1e-12)
            except Exception as ex:status=type(ex).__name__+': '+str(ex)
            candidates=[start]+[r for r in rows[first:] if r['valid'] and r['guard'] and r['hard']]
            best=min(candidates,key=lambda r:r['norm'])
            with mp.workdps(250):point=[mp.mpf(v) for v in best['x']]
            raw=native_stage(d,point,dps=CFG['pilot_dps'],iterations=CFG['pilot_iterations'],target=CFG['pilot_target'],floor=CFG['floor'])
            p=out/'pilot'/item['case_id']/f'{i}.json';save(p,raw)
            allstates.append({'case_id':item['case_id'],'model':item['model'],'index':i,'x':raw['point'],
                'pilot_sha256':sha(p),'float_start':start['x'],'float_status':status,'float_calls':calls-count,
                'pilot_status':raw['status'],'pilot_hp_calls':raw['hp_residual_calls'],'pilot_seconds':raw['seconds']})
        save(out/'pilot'/item['case_id']/'initialization.json',{'rows':rows,'total_float_calls':calls,
            'eligible_starts':len(eligible),'total_seconds':time.monotonic()-begin,'bounds':bounds})
    # This restricted file is the predictor's complete input. No goals/refs.
    save(out/'states.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(out/'protocol.json'),
        'config':CFG,'rows':allstates})


def predict(out):
    assert not (out/'measurements').exists()
    data=loads((out/'states.json').read_text());begun=time.monotonic();rows=[]
    lam=Q(CFG['lambda0']);floor=Q(CFG['floor']);delta=Q(CFG['delta']);tau=Q(CFG['tau']);T=Q(CFG['next_target'])
    for row in data['rows']:
        x=rational(row['x'][0]);pred='abstain';record={}
        if row['model']=='rational_contact' and -2<x<4:
            r=2*(x-2)**2/(6-x);D=9*r/max(floor,lam/256);upper=min(Q(1),r/delta)*D
            lower=r*(1-D)**5 if D<1 else Q(0)
            if r<=T:pred='target_initial'
            elif D<1 and upper<tau and lower>T:pred='five_small_stall'
            record={'r0':display(r),'D':display(D),'I_upper':display(upper),'r5_lower':display(lower)}
        elif row['model']=='affine_contact' and x>0:
            r=abs(7*x-16);upper=r*(lam/(49+lam))**4
            if r<=T:pred='target_initial'
            elif upper<=T:pred='target_within4'
            record={'r0':display(r),'r4_upper':display(upper)}
        rows.append({'case_id':row['case_id'],'index':row['index'],'prediction':pred,'certificate':record})
    save(out/'predictions.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'states_sha256':sha(out/'states.json'),
        'script_sha256':sha(Path(__file__)),'seconds':time.monotonic()-begun,'future_step_evaluations':0,
        'rows':rows,'coverage':dict(Counter(r['prediction'] for r in rows))})
    print(json.dumps({'coverage':dict(Counter(r['prediction'] for r in rows)),'future_step_evaluations':0}))


def measure(out,archive):
    decision=json.loads((archive/'audits/03-adoption-decision.json').read_text())
    assert decision.get('authorize_rootfree_supplement_v1') is True
    predictions=loads((out/'predictions.json').read_text());states=loads((out/'states.json').read_text())
    assert predictions['states_sha256']==sha(out/'states.json')
    prot=loads((out/'protocol.json').read_text());items={r['case_id']:r for r in prot['items']};rows=[]
    for p,s in zip(predictions['rows'],states['rows']):
        assert (p['case_id'],p['index'])==(s['case_id'],s['index']);item=items[s['case_id']]
        d=json.loads(Path(item['dsl']).read_text());raw=native_stage(d,s['x'],dps=100,target=CFG['next_target'],floor=CFG['floor'])
        path=out/'measurements'/s['case_id']/f"{s['index']}.json";save(path,raw);ev=events(raw)
        good=None
        if p['prediction']=='five_small_stall':good=raw['status']=='stalled' and len(ev)==5 and all(v['small'] for v in ev)
        elif p['prediction'].startswith('target_'):good=raw['status']=='target_reached' and len(ev)<=4
        with mp.workdps(350):
            checks=[]
            for event in ev:
                x=event['input'][0];exact=abs(2*(x-2)**2/(6-x)) if s['case_id']==POS else abs(7*x-16)
                checks.append({'residual_relative_error':abs(event['norm']-exact)/exact if exact else None,
                    'in_guard':bool(-2<x<4) if s['case_id']==POS else bool(x>0)})
        rows.append({'case_id':s['case_id'],'index':s['index'],'prediction':p['prediction'],'actual_event':raw['status'],
            'steps':len(ev),'prediction_pass':good,'all_full':all(e['full_step'] for e in ev),'checks':checks,
            'source':str(path),'sha256':sha(path),'events':ev,'seconds':raw['seconds']})
    save(out/'assessment.json',{'rows':rows,'predictions_sha256':sha(out/'predictions.json'),'source_unchanged':ensure_source()})
    print(json.dumps([{k:v for k,v in r.items() if k not in ('events','checks')} for r in rows]))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','pilot','predict','measure']);p.add_argument('output',type=Path);p.add_argument('--archive',type=Path);a=p.parse_args()
    if a.mode=='prepare':prepare(a.archive,a.output)
    elif a.mode=='pilot':pilot(a.output)
    elif a.mode=='predict':predict(a.output)
    else:measure(a.output,a.archive)
