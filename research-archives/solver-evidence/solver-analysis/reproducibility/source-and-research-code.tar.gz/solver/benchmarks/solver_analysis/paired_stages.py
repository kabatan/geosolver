"""Reference-blind common restarts from recorded coordinates.

These are fresh optimizer starts, not restoration of internal optimizer state.
Each point runs with a fresh evaluator/cache. Results retain failures, work
limits, actual residual calls (including finite differences), and pre-verifier
coordinates. Original-condition verification is a separate, mutating stage.
"""
from __future__ import annotations
import argparse
import copy
import dataclasses
import hashlib
import importlib
import json
import time
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
import numpy as np
from mpmath import mp
from scipy.optimize import least_squares
from exact_codec import dumps,loads
from stage_replay import ensure_source,save
from geosolver.problem.models import GeometryProblem
from geosolver.engine.standard.problem.load_problem_bundle import load_problem_bundle
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator,IREvaluator
from geosolver.engine.standard.evaluation.final_verifier import verify_final_candidate
from geosolver.engine.standard.evaluation.classify_evaluation_failure import EvaluationStatus
from geosolver.engine.standard.refinement.mpmath_refiner import MpmathRefiner,_convert_problem_bounds,_run_findroot_closure
from geosolver.engine.standard.refinement.refiner_config import RefinerConfig
from geosolver.engine.standard.contracts.candidate_record import FloatCandidate
from geosolver.engine.standard.precision.type_guards.high_precision_mode import high_precision_mode
from geosolver.runtime.deadline import runtime_session
from geosolver.runtime.worker import _json_value


class WorkLimit(RuntimeError):pass


def bundle_of(dsl):
    return load_problem_bundle(GeometryProblem.model_validate(dsl).engine_document())


def extract_pool(raw_files,destination):
    """All distinct retained natural source candidates, never rank by references."""
    points=[];receipts=[]
    for file in raw_files:
        raw=json.loads(file.read_text());seen=set()
        for entry in raw['solver_result']['diagnostics']['candidate_records']:
            source=entry.get('source')
            if not source or source['candidate_uid'] in seen:continue
            seen.add(source['candidate_uid'])
            points.append({'uid':source['candidate_uid'],'x':tuple(source['x_float']),
                'source_revision':0,'external_seed':raw['seed'],'case_id':raw['case_id'],
                'source_file':str(file),'source_candidate':source})
        receipts.append({'path':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
                         'distinct_source_candidates':len(seen)})
    save(destination,{'schema':1,'sampling':'all distinct sources in retained candidate_records, in ledger order',
         'limitation':'conditional on baseline retention; not an unbiased search sample',
         'sources':receipts,'points':points})
    print(json.dumps({'pool':str(destination),'points':len(points)}))


def run_point(*,dsl,original,point,engine,dps,iterations,seconds,damping,rank_cap,verify,
              carry_damping=False,initial_damping=None,residual_scale=None):
    if residual_scale is not None and engine!='native_lm':
        raise ValueError('residual_scale is supported only for the fixed native_lm stage')
    if carry_damping and engine not in ('native_refine','scipy_refine'):
        raise ValueError('carry_damping requires a multi-precision native refinement pipeline')
    ensure_source();bundle=bundle_of(dsl);e=build_ir_evaluator(bundle)
    original_bundle=bundle_of(original);original_e=build_ir_evaluator(original_bundle)
    if bundle.var_names!=original_bundle.var_names:raise ValueError('Coordinate map required for different variable sets')
    begun=time.monotonic();deadline=begun+seconds
    trace=[];calls={'float':0,'hp':0};out=None;status='not_started';error=None
    mod=importlib.import_module('geosolver.engine.standard.refinement.mpmath_refiner')
    def observed(fn,kind):
        def call(*a,**k):
            numeric_kwargs={n:v for n,v in k.items() if n not in ('residual_fn','trial_filter')}
            row={'kind':kind,'dps':mp.dps,'elapsed_seconds':time.monotonic()-begun,
                'input':loads(dumps(numeric_kwargs)) if kind!='rank_chart' else {'args':loads(dumps(a)),'kwargs':loads(dumps(k))}}
            trace.append(row)
            result=fn(*a,**k);row['output']=loads(dumps(result));return result
        return call
    old_float=IREvaluator.evaluate_float_residual;old_hp=IREvaluator.evaluate_hp_residual
    def counted_float(*a,**k):calls['float']+=1;return old_float(*a,**k)
    def counted_hp(*a,**k):calls['hp']+=1;return old_hp(*a,**k)
    with mp.workdps(max(550,dps)):
        x=[mp.mpf(v) for v in point['x']]
        changes={'max_stage_iters':80 if engine=='scipy_refine' else iterations}
        if damping is not None:changes.update(damping_min=mp.mpf(damping))
        if initial_damping is not None:changes.update(damping_initial=mp.mpf(initial_damping))
        config=dataclasses.replace(RefinerConfig(),**changes)
    refiner=MpmathRefiner(config=config)
    ambient=180 if engine in ('native_refine','scipy_refine') else max(180,dps)
    with ExitStack() as stack,mp.workdps(ambient),runtime_session(deadline) as timings:
        stack.enter_context(patch.object(IREvaluator,'evaluate_float_residual',counted_float))
        stack.enter_context(patch.object(IREvaluator,'evaluate_hp_residual',counted_hp))
        for name,kind in [('run_line_search','line_search'),('compute_levenberg_marquardt_step','lm_step'),('_select_rank_revealing_subsystem','rank_chart')]:
            stack.enter_context(patch.object(mod,name,observed(getattr(mod,name),kind)))
        if True:  # Record every stage even when the intervention is disabled.
            stage_method=MpmathRefiner._run_stage
            carried=None
            def carry_stage(self,**kwargs):
                nonlocal carried
                before_trace=len(trace)
                used=self if not carry_damping or carried is None else MpmathRefiner(config=dataclasses.replace(self.config,damping_initial=carried))
                stage_record={'kind':'stage_boundary','dps':kwargs['dps'],'input':tuple(kwargs['start_point']),
                    'initial_damping':used.config.damping_initial,'carried':carry_damping and carried is not None}
                trace.append(stage_record)
                result=stage_method(used,**kwargs)
                stage_record['output']=loads(dumps(result))
                calls_here=trace[before_trace:]
                lm=[r for r in calls_here if r['kind']=='lm_step']
                ls=[r for r in calls_here if r['kind']=='line_search']
                if lm and ls and 'output' in ls[-1]:
                    last=lm[-1]['input']['damping']
                    carried=max(mp.mpf(self.config.damping_min),last/mp.mpf(self.config.damping_scale)) if ls[-1]['output'][-1] else last*mp.mpf(self.config.damping_scale)
                stage_record['final_damping_for_next_stage']=carried
                return result
            stack.enter_context(patch.object(MpmathRefiner,'_run_stage',carry_stage))
        for name in ('_run_findroot_closure','_run_rank_aware_findroot'):
            fn=getattr(mod,name)
            def closure_call(*a,_fn=fn,_name=name,**k):
                row={'kind':_name,'dps':mp.dps,'input':loads(dumps({n:v for n,v in k.items() if n not in ('evaluator','bounds') and not callable(v)}))}
                trace.append(row)
                result=_fn(*a,**k);row['output']=loads(dumps(result));return result
            stack.enter_context(patch.object(mod,name,closure_call))
        if rank_cap is not None:stack.enter_context(patch.object(mod,'_RANK_AWARE_MAX_STEPS',rank_cap))
        bounds=_convert_problem_bounds(bundle)
        try:
            if engine=='scipy_refine':
                start=np.array([float(z) for z in x]);last=start.copy();best=start.copy();best_norm=float('inf')
                lo=np.array([-np.inf if b[0] is None else float(b[0]) for b in bounds])
                hi=np.array([np.inf if b[1] is None else float(b[1]) for b in bounds])
                def fun(y):
                    nonlocal last,best,best_norm
                    if calls['float']>=iterations:raise WorkLimit('Actual float residual call limit')
                    last=y.copy();v=e.evaluate_float_residual(y.tolist())
                    if v.evaluation_status is not EvaluationStatus.OK:return np.full(len(bundle.targets),1e6)
                    val=np.array(v.residual_vector);norm=float(np.linalg.norm(val))
                    if norm<best_norm:best=y.copy();best_norm=norm
                    return val
                try:
                    fit=least_squares(fun,start,bounds=(lo,hi),x_scale='jac',
                        ftol=1e-12,xtol=1e-12,gtol=1e-12,max_nfev=iterations)
                    scipy_status={'status':int(fit.status),'nfev':int(fit.nfev),'njev':int(fit.njev or 0),'actual_calls':calls['float']}
                    x=[mp.mpf(float(v)) for v in fit.x]
                except WorkLimit as ex:
                    scipy_status={'status':'actual_call_limit','actual_calls':calls['float'],'message':str(ex)}
                    x=[mp.mpf(float(v)) for v in best]
                trace.append({'kind':'scipy_result','output':scipy_status,'x':tuple(x)})
            if engine in ('native_refine','scipy_refine'):
                raw=[float(v) for v in x];fv=e.evaluate_float_residual(raw)
                guarded,tags=e.evaluate_guard(raw)
                hf=e.evaluate_float_hard_feasibility(raw,include_margins=False)
                candidate=FloatCandidate(tuple(raw),fv.residual_norm_float**2,fv.residual_norm_float,guarded,
                    fv.evaluation_status,point.get('external_seed',0),0,candidate_id=0,
                    hard_feasible=hf.hard_feasible,hard_violation_tags=hf.failure_tags,
                    origin_phase='common_restart',origin_backend=engine)
                out=refiner.refine_candidates(bundle=bundle,evaluator=e,candidates=(candidate,),deadline_monotonic=deadline)
                completed=[c for c in out.candidates if c.x_hp]
                if completed:x=list(min(completed,key=lambda c:c.residual_norm_hp).x_hp)
                status='completed'
            elif engine=='native_lm':
                # The same production stage, with a requested fixed iteration cap.
                with high_precision_mode():
                    hf=e.evaluate_hp_hard_feasibility(x,precision=dps,include_margins=False)
                extra={};target=mp.mpf(10)**(-int(.7*dps))
                if residual_scale is not None:
                    factor=mp.mpf(residual_scale)
                    if factor<=0:raise ValueError('residual_scale must be positive')
                    def scaled_residual(y,precision):
                        v=refiner._residual_vector_for_stage(bundle,e,y,precision,smooth_zero_constraints=True)
                        return None if v is None else [factor*z for z in v]
                    extra['residual_fn']=scaled_residual;target*=factor
                out=refiner._run_stage(bundle=bundle,evaluator=e,start_point=x,bounds=bounds,dps=dps,
                    target_residual=target,preserve_hard_feasibility=hf.hard_feasible,**extra)
                status,x,_=out
            elif engine=='native_closure':
                def residual_fn(v,precision):
                    return refiner._residual_vector_for_stage(bundle,e,v,precision,smooth_zero_constraints=True)
                out=_run_findroot_closure(evaluator=e,start_point=x,bounds=bounds,dps=dps,
                    target_residual=mp.mpf(10)**(-int(.7*dps)),max_steps=iterations,
                    residual_fn=residual_fn,deadline_monotonic=deadline)
                if out is None:status='no_certified_closure'
                else:x,_=out;status='certified_closure'
            else:raise ValueError(engine)
        except Exception as exc:status='error';error=type(exc).__name__+': '+str(exc)
        numeric_elapsed=time.monotonic()-begun
        numeric_deadline_hit=time.monotonic()>=deadline
        numeric_calls=dict(calls)
        pre_verifier=tuple(x);verification=None;original_residual=None;original_goal=None
        verification_begun=time.monotonic();verification_deadline=verification_begun+10
        with runtime_session(verification_deadline):
            try:
                with mp.workdps(dps),high_precision_mode():
                    original_residual=original_e.evaluate_hp_residual(x,precision=dps)
                    original_goal=original_e.evaluate_answer_hp(x,precision=dps)
                if verify:
                    verification=verify_final_candidate(evaluator=original_e,values=x)
            except Exception as exc:verification={'error':type(exc).__name__+': '+str(exc)}
        return {'schema':2,'source_hash':ensure_source(),'engine':engine,'case_id':dsl['id'],
            'intervention_dsl':dsl,'original_dsl':original,'point':point,'dps':dps,
            'ambient_dps':ambient,'refiner_config':config,
            'iteration_or_actual_float_call_cap':iterations,'safety_seconds':seconds,
            'damping_override':damping,'rank_chart_cap_override':rank_cap,
            'carry_damping_across_stages':carry_damping,'initial_damping_override':initial_damping,
            'residual_scale':residual_scale,
            'status':status,'error':error,'output':out,'pre_verifier_point':pre_verifier,
            'original_residual':original_residual,'original_goal':original_goal,'verification':verification,
            'numeric_seconds':numeric_elapsed,'total_seconds':time.monotonic()-begun,
            'safety_deadline_hit':numeric_deadline_hit,'actual_calls':calls,'numeric_calls':numeric_calls,
            'verification_safety_seconds':10,'verification_seconds':time.monotonic()-verification_begun,
            'verification_deadline_hit':time.monotonic()>=verification_deadline,
            'counters':timings.counters,'phase_seconds':dict(timings),'trace':trace}


def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    x=sub.add_parser('extract');x.add_argument('output',type=Path);x.add_argument('raw',nargs='+',type=Path)
    r=sub.add_parser('run');r.add_argument('dsl',type=Path);r.add_argument('original',type=Path)
    r.add_argument('pool',type=Path);r.add_argument('index',type=int);r.add_argument('output',type=Path)
    r.add_argument('--engine',choices=['native_lm','native_closure','native_refine','scipy_refine'],default='native_refine')
    r.add_argument('--dps',type=int,default=120);r.add_argument('--iterations',type=int,default=80)
    r.add_argument('--seconds',type=float,default=180);r.add_argument('--damping');r.add_argument('--rank-cap',type=int)
    r.add_argument('--carry-damping',action='store_true');r.add_argument('--initial-damping');r.add_argument('--residual-scale')
    r.add_argument('--verify',action='store_true')
    a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    if a.command=='extract':extract_pool(a.raw,a.output);return
    v=run_point(dsl=json.loads(a.dsl.read_text()),original=json.loads(a.original.read_text()),
        point=loads(a.pool.read_text())['points'][a.index],engine=a.engine,dps=a.dps,
        iterations=a.iterations,seconds=a.seconds,damping=a.damping,rank_cap=a.rank_cap,verify=a.verify,
        carry_damping=a.carry_damping,initial_damping=a.initial_damping,residual_scale=a.residual_scale)
    save(a.output,v);print(json.dumps({'output':str(a.output),'status':v['status'],'seconds':v['total_seconds'],
        'error':v['error'],'calls':v['actual_calls']}))

if __name__=='__main__':main()
