"""Reduce already sealed historical assessments without rerunning solvers."""
import argparse,hashlib,json
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path


def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def analyze(archive,history,out):
    if out.exists():raise FileExistsError(out)
    provenance={};data={};manifests={}
    for label,folder in [('solver_a1','baseline-complete'),('current_snapshot','final-v4')]:
        p=history/'solver-improvement-20260907'/folder
        data[label]=[json.loads(line) for line in (p/'assessment.jsonl').read_text().splitlines()]
        manifests[label]=read(p/'campaign-manifest.json')
        for file in ('assessment.jsonl','campaign-manifest.json','summary.json'):
            provenance[str(p/file)]=digest(p/file)
    a,b=manifests.values()
    shared={k:a[k]==b[k] for k in ('corpus_hash','config_hash','dependency_lock_hash')}
    assert all(shared.values()),shared
    index={label:{(r['case_id'],r['seed']):r for r in rows} for label,rows in data.items()}
    assert set(index['solver_a1'])==set(index['current_snapshot'])
    pairs=[];groups=defaultdict(list)
    for key in sorted(index['solver_a1']):
        old=index['solver_a1'][key];new=index['current_snapshot'][key]
        r={'case_id':key[0],'seed':key[1],'old_matched':old['matched'],'new_matched':new['matched'],
           'change':int(new['matched'])-int(old['matched']),
           'old_failure_stage':old['failure_stage'],'new_failure_stage':new['failure_stage'],
           'old_actual':old['actual'],'new_actual':new['actual'],
           'same_reference':old['expected']==new['expected'],
           'same_output':old['actual']==new['actual']}
        assert r['same_reference'];pairs.append(r);groups[key[0]].append(r)
    problems=[{'case_id':ident,'runs':len(rows),'old_matched':sum(r['old_matched'] for r in rows),
               'new_matched':sum(r['new_matched'] for r in rows),
               'improved_pairs':sum(r['change']>0 for r in rows),'worsened_pairs':sum(r['change']<0 for r in rows),
               'changed_outputs':sum(not r['same_output'] for r in rows)} for ident,rows in groups.items()]
    gm=history/'gmb-geosolver-imo36-solver-a1-20260901/assessment/summary.json'
    gp=history/'gmb-official-goals-solver-a1-20260901-validated/summary.json'
    g=read(gm);q=read(gp);provenance[str(gm)]=digest(gm);provenance[str(gp)]=digest(gp)
    gmb={'case_count':g['case_count'],'timeout_seconds':g['timeout_seconds'],
         'primary_tolerance':g['primary_tolerance'],'interpretation':g['interpretation'],
         'resource_scope':g['resource_scope'],'checker_policy':g['checker_identity']['policy'],
         'configuration':{label:{k:v[k] for k in ('cases_succeeded_all_seeds','cases_succeeded_at_least_once',
             'case_success_count_distribution','primary')} for label,v in g['by_method'].items()},
         'conclusion_only':q['by_method'],'conclusion_policy':q['policy']['scope'],
         'conclusion_tolerance':q['policy']['evaluation'],'conclusion_replay_passed':q['replay_passed']}
    summary={'created_utc':datetime.now(timezone.utc).isoformat(),'unit':'323 problems; seeds are paired observations within each problem',
         'runs':len(pairs),'problems':len(problems),'shared_conditions':shared,
         'old_matched':sum(r['old_matched'] for r in pairs),'new_matched':sum(r['new_matched'] for r in pairs),
         'improved_pairs':sum(r['change']>0 for r in pairs),'worsened_pairs':sum(r['change']<0 for r in pairs),
         'unchanged_outputs':sum(r['same_output'] for r in pairs),
         'problems_with_improvement':sum(r['improved_pairs']>0 for r in problems),
         'problems_with_worsening':sum(r['worsened_pairs']>0 for r in problems),
         'failure_stages':{label:dict(Counter(r['failure_stage'] or 'output' for r in rows)) for label,rows in data.items()},
         'sources':{label:m['source_hash'] for label,m in manifests.items()},
         'limitations':'Historical discovery comparison. Compound implementation changes and timed runs do not identify each change causally. Old16 versus current8 concurrency timings are not compared.',
         'input_hashes':provenance,'script_sha256':digest(Path(__file__))}
    out.mkdir(parents=True)
    for name,value in [('summary',summary),('problem-results',problems),('gmb-context',gmb)]:
        (out/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    (out/'paired-runs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in pairs))
    print(json.dumps({k:summary[k] for k in ('runs','old_matched','new_matched','improved_pairs','worsened_pairs','problems_with_improvement','problems_with_worsening')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('historical_root',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();analyze(a.archive,a.historical_root,a.output)
