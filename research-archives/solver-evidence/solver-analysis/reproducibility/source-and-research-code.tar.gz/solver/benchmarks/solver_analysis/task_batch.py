"""Execute frozen experiment groups sequentially per core, eight groups in parallel.

Commands are argument arrays, never shell text. External cancellations, process
timeouts, nonzero exits and unstarted dependent commands remain explicit.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
import queue
import subprocess
import sys
import time
from pathlib import Path
from stage_campaign import THREADS
from stage_replay import ensure_source

ROOT=Path(__file__).resolve().parents[2]


def run(plan_path,destination):
    if destination.exists():raise FileExistsError(destination)
    plan=json.loads(plan_path.read_text())
    prerequisite=plan.get('wait_for_receipt')
    while prerequisite:
        p=Path(prerequisite)
        if p.exists() and json.loads(p.read_text()).get('status')=='complete':break
        time.sleep(10)
    if ensure_source()!=plan['source_hash']:raise ValueError('product changed')
    sys.path.insert(0,str(ROOT/'benchmarks'));from research_runner import _independent_cpus
    cpus=_independent_cpus()[:plan.get('jobs',8)];available=queue.Queue()
    for cpu in cpus:available.put(cpu)
    destination.mkdir(parents=True);env=dict(os.environ,**THREADS);begun=time.monotonic()
    manifest={'plan':plan,'plan_sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),'cores':cpus,
              'script_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}}
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    def group(g):
        cpu=available.get();rows=[];blocked=False
        try:
            for i,job in enumerate(g['jobs']):
                row={'group':g['id'],'job_index':i,'command':job['command'],'cpu':cpu}
                if blocked:row['status']='not_run_prerequisite_failed';rows.append(row);continue
                start=time.monotonic()
                try:
                    p=subprocess.run(['taskset','-c',str(cpu),*job['command']],cwd=ROOT,env=env,
                        text=True,capture_output=True,timeout=job.get('process_timeout',300))
                    row.update(status='completed' if p.returncode==0 else 'nonzero_exit',exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
                except subprocess.TimeoutExpired as ex:
                    row.update(status='process_timeout',stdout=str(ex.stdout),stderr=str(ex.stderr))
                row['seconds']=time.monotonic()-start;rows.append(row)
                if row['status']!='completed' and job.get('required_for_next',False):blocked=True
            return rows
        finally:available.put(cpu)
    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(cpus)) as executor:
        futures=[executor.submit(group,g) for g in plan['groups']]
        for f in concurrent.futures.as_completed(futures):
            new=f.result();rows.extend(new)
            (destination/(new[0]['group']+'.json')).write_text(json.dumps(new,indent=2)+'\n')
            print(json.dumps({'completed_groups':len(list(destination.glob('*.json')))-1,'planned_groups':len(plan['groups']),
                              'seconds':round(time.monotonic()-begun,1)}),flush=True)
    receipt={'status':'complete','groups':len(plan['groups']),'jobs':len(rows),
        'noncompleted_jobs':sum(r['status']!='completed' for r in rows),'source_hash_after':ensure_source(),
        'seconds':time.monotonic()-begun}
    (destination/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();run(a.plan,a.destination)
