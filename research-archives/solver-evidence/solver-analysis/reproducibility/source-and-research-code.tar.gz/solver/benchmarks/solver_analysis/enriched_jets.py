"""Exact input-only jets for the post-freeze common-tangent extension.

No numerical optimizer or source answer key is imported. Coefficients below
refer to Taylor powers, so second coefficients are half the second derivative.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sympy as s


def cross(a,b):return s.det(s.Matrix.hstack(a,b))
def area(points):return -sum(cross(points[i],points[(i+1)%4]) for i in range(4))/2


def derive():
    q=s.sqrt(19);a=(-25*q-200)/27;b=(-25*q+200)/27
    r1=(250+20*q)/27;r2=(250-20*q)/27
    ns=[s.Matrix([q/10,-s.Rational(9,10)]),s.Matrix([q/10,s.Rational(9,10)])]
    us=[s.Matrix([-n[1],n[0]]) for n in ns]
    centers=[s.Matrix([a,5]),s.Matrix([b,5])];radii=[r1,r2]
    # Internal order is U1,V1,U2,V2; polygon order is U1,U2,V2,V1.
    pts=[o+r*n for n in ns for o,r in zip(centers,radii)]
    order=[0,2,3,1];base=s.simplify(area([pts[i] for i in order]));assert base==200
    auxiliary=[]
    for j in range(4):
        k=order.index(j);dp=radii[j%2]*us[j//2]
        auxiliary.append(s.simplify(-cross(dp,pts[order[(k+1)%4]]-pts[order[(k-1)%4]])/2))
    assert all(v!=0 for v in auxiliary)
    # Along either circle at fixed centres each endpoint first moves along its
    # tangent. Thus both line jets start at degree two. The distance equations
    # determine centre changes at degree two, provided their Jacobian is full.
    aa,bb,th,ph=s.symbols('aa bb th ph', real=True)
    normals=[s.Matrix([s.cos(th),s.sin(th)]),s.Matrix([s.cos(ph),s.sin(ph)])]
    os=[s.Matrix([aa,5]),s.Matrix([bb,5])]
    feet=[o+(p-n.dot(o))*n for p,n in zip((3,12),normals) for o in os]
    goal=area([feet[i] for i in order])
    at={aa:a,bb:b,th:-s.asin(s.Rational(9,10)),ph:s.asin(s.Rational(9,10))}
    dg=s.Matrix([s.simplify(s.diff(goal,v).subs(at)) for v in (aa,bb,th,ph)])
    rows=[]
    for i,n in enumerate(ns):
        for j,(o,r) in enumerate(zip(centers,radii)):
            row=[s.Integer(0)]*4;row[j]=n[0]+o[0]/r;row[2+i]=us[i].dot(o)
            rows.append(row)
    M=s.Matrix(rows);det=s.simplify(M.det());assert det!=0
    coefficients=[]
    for j in range(4):
        rhs=s.zeros(4,1);rhs[j]=radii[j%2]/2
        z=(M.inv()*rhs).applyfunc(s.simplify)
        coefficients.append({'direction':['d','e','f','g'][j],
            'centre_and_normal_second_jet':[str(v) for v in z],
            'physical_goal_second_coefficient':str(s.simplify(dg.dot(z))),
            'auxiliary_goal_first_coefficient':str(auxiliary[j])})
    assert all(s.sympify(v['physical_goal_second_coefficient'])!=0 for v in coefficients)
    # The second-order equations contain only individual angle squares: no
    # first line variation means no mixed first-order physical terms.
    return {'case_id':'HMMT-NOV-2025-GEN-08','input_only':True,'optimizer_calls':0,
        'root_centres':[str(a),str(b)],'root_radii':[str(r1),str(r2)],
        'normals':[[str(v) for v in n] for n in ns],
        'root_goal_derived_from_input':str(base),'root_mirror':'x -> -x, then swap circle labels to restore a<b',
        'physical_regularity_determinant':str(det),'physical_goal_gradient':[str(v) for v in dg],
        'directional_coefficients':coefficients,
        'prediction':'m=2 in four weak contact-angle directions; auxiliary q=1 in each coordinate direction, physical q=2 in each coordinate direction after eliminating the two distance equations. Mixed cancellations are not assigned equality bounds.',
        'scope':'Input-derived local branch. Four-angle perturbations at fixed centres leave other equations at O(delta^2); exact equality-manifold probes must include centre correction.',
        'correction':'Preliminary informal q>=2 for the auxiliary quadrilateral was incorrect. This exact pre-outcome derivation supersedes it; no individual numeric forecast had been frozen.'}


def write(intake,destination):
    if destination.exists():raise FileExistsError(destination)
    result=derive();destination.mkdir(parents=True)
    base=intake/'enriched-v2/variants/HMMT-NOV-2025-GEN-08'
    for p in base.glob('constructed*.json'):
        d=json.loads(p.read_text())
        for name,center,line in [('FU1','O1','ell1'),('FU2','O1','ell2'),('FV1','O2','ell1'),('FV2','O2','ell2')]:
            d['constructions'].append({'name':name,'expression':f'ClosestPoint({center},{line})'})
        d['target']='Area(FU1,FU2,FV2,FV1)'
        out=destination/(p.stem+'_physical.json');out.write_text(json.dumps(d,indent=2)+'\n')
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (destination/'exact-jets.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('intake',type=Path);p.add_argument('destination',type=Path)
    a=p.parse_args();write(a.intake,a.destination)
