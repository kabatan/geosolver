"""Outcome-only analysis of common starts, candidate selection and Phase C.

Reads immutable saved outputs and independent benchmark references. This module
is never imported by a solver or ranking process. Missing planned outputs stay
in all summaries, and candidate rows are not counted as independent problems.
"""
import argparse,hashlib,json,statistics,sys
from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps
from natural_evidence import jmo
from paired_stages import bundle_of
from stationary_check import check
from geosolver.engine.standard.evaluation.ir_evaluator import build_ir_evaluator
from geosolver.exact import describe_exact
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from research_runner import _load_cases,reference_expressions


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(value):return json.dumps(value,sort_keys=True,ensure_ascii=False)
@lru_cache(None)
def expression_key(value):return key(describe_exact(value).canonical_key())
def med(values):return statistics.median(values) if values else None
def digit(error):return float(min(500,-mp.log10(max(abs(mp.mpf(error)),mp.mpf('1e-500')))))


def references():
    return {r.identifier:{expression_key(v) for s in r.references for v in reference_expressions(s)}
            for r in _load_cases()}


def compare_values(values,expected):
    try:
        actual={expression_key(v) for v in values}
        return {'actual_keys':sorted(actual),'expected_keys':sorted(expected),
            'matched':actual==expected,'any_reference_value':bool(actual&expected),
            'extra':sorted(actual-expected),'missing':sorted(expected-actual)}
    except Exception as ex:
        return {'matched':False,'any_reference_value':False,'assessment_error':type(ex).__name__+': '+str(ex)}


def completion_row(path,refs):
    row={'file':str(path),'available':path.exists()}
    if not path.exists():return {**row,'matched':False,'any_reference_value':False,'gate':'missing'}
    r=loads(path.read_text());assembly=r.get('assembly',{})
    ident=r.get('case_id',path.parent.name)
    row.update(case_id=ident,raw_sha256=sha(path),gate=r.get('gate'),
        source=r.get('source'),frontend_backend=r.get('frontend_backend'),
        frontend_dsl_id=r.get('frontend_dsl_id'),hp_source=r.get('hp_source'),hp_dsl=r.get('hp_dsl_path'),
        refined_candidates=r.get('refined_candidate_count',0),
        numeric_verified=len(assembly.get('numeric_feasible_candidates',[])),
        exact_accepted=len(assembly.get('accepted_candidates',[])),
        selected_hp_inputs=r.get('selected_hp_input_count'),
        hp_seconds=r.get('hp_numeric_seconds'),hp_censored=r.get('hp_censored'),
        finalization_seconds=r.get('finalization_seconds'),finalization_censored=r.get('finalization_censored'),
        hp_failures=r.get('hp_unavailable'),error=r.get('error'),
        rejection_tags=assembly.get('rejection_tags',[]),
        **compare_values(r.get('answer_values',[]),refs[ident]))
    return row


def common(archive,out,refs):
    plan=json.loads((archive/'development/comparison-plan-v1.json').read_text())
    rows=[]
    for group in plan['groups']:
        for job in group['jobs']:
            cmd=job['command']
            if Path(cmd[2]).name!='common_multistart.py' or cmd[3]!='run':continue
            p=Path(cmd[6]);backend,variant=p.stem.split('__');ident=group['id']
            variables=len(json.loads(Path(cmd[4]).read_text())['variables'])
            row={'case_id':ident,'backend':backend,'variant':variant,'file':str(p),'available':p.exists(),
                'variables':variables,'stratum':'zero' if variables==0 else 'scalar' if variables==1 else 'multivariate',
                'optimizer_comparison_applicable':variables>0}
            if p.exists():
                r=loads(p.read_text());trace=r['search_trace'];eligible=[v for v in trace if v['valid']]
                row.update(raw_sha256=sha(p),proposals=len(r['common_pool']['proposals']),
                    evaluable_initial_proposals=sum(v['valid'] for v in r['common_pool']['proposals']),
                    selected_initial_starts=len(r['common_pool']['selected_indices']),
                    executed_starts=len(r['search']),unprocessed_starts=r['unprocessed_start_indices'],
                    search_calls=len(trace),invalid_search_calls=sum(not v['valid'] for v in trace),
                    guard_hard_search_calls=sum(v['valid'] and v['guard'] and v['hard'] for v in trace),
                    selected_hp_inputs=len(r['selected_hp_inputs']),
                    best_eligible_search_norm=min((v['norm'] for v in eligible if v['guard'] and v['hard']),default=None),
                    search_seconds=r['search_seconds'],search_censored=r['search_safety_censored'],
                    hp_numeric_seconds=sum(v['numeric_seconds'] for v in r['hp_results']),
                    hp_censored=sum(v['safety_deadline_hit'] for v in r['hp_results']),
                    frontend_stop_statuses=dict(Counter(str(v['status']) for v in r['search'])))
            cp=archive/'development/common-completion-v1/runs'/ident/p.name
            row['completion']=completion_row(cp,refs);rows.append(row)
    pairs=[]
    for row in rows:
        if row['variant']=='original':continue
        base=next(v for v in rows if v['case_id']==row['case_id'] and v['backend']==row['backend'] and v['variant']=='original')
        a,b=base['completion'],row['completion']
        pairs.append({'case_id':row['case_id'],'backend':row['backend'],'variant':row['variant'],
            'original_file':base['file'],'intervention_file':row['file'],
            'both_available':base['available'] and row['available'] and a['available'] and b['available'],
            'original_matched':a['matched'],'intervention_matched':b['matched'],
            'matched_difference':int(b['matched'])-int(a['matched']),
            'original_numeric':a.get('numeric_verified',0),'intervention_numeric':b.get('numeric_verified',0),
            'search_call_difference':row.get('search_calls',0)-base.get('search_calls',0),
            'search_seconds_difference':row.get('search_seconds',0)-base.get('search_seconds',0)})
    cross=[];cplan=json.loads((archive/'development/common-completion-plan-v1.json').read_text())
    for group in cplan['groups']:
        if not group['id'].startswith('cross_'):continue
        rr=[]
        for job in group['jobs']:
            cmd=job['command'];p=Path(cmd[4]);r=completion_row(p,refs)
            r.update(group=group['id'],hp_variant=p.stem.split('__hp_')[-1]);rr.append(r);cross.append(r)
        if {v['hp_variant'] for v in rr}!={'original','signed'}:raise ValueError('HP cross arms differ')
    write(out/'common-runs.jsonl',rows);write(out/'common-pairs.jsonl',pairs);write(out/'common-hp-cross.jsonl',cross)
    return {'planned_frontend_arms':len(rows),'available':sum(r['available'] for r in rows),
        'completed_phase_c':sum(r['completion']['gate']=='completed' for r in rows),
        'planned_zero_variable_arms':sum(r['variables']==0 for r in rows),
        'nonzero_cases':len({r['case_id'] for r in rows if r['variables']>0}),
        'by_backend':{b:{'arms':len(v),'matched':sum(r['completion']['matched'] for r in v),
            'numeric_any':sum(r['completion'].get('numeric_verified',0)>0 for r in v),
            'search_censored':sum(r.get('search_censored',False) for r in v)}
            for b in ('nomad','scipy') for v in [[r for r in rows if r['backend']==b]]},
        'by_backend_and_stratum':[{ 'backend':b,'stratum':s,'arms':len(v),
            'available':sum(r['available'] for r in v),'matched':sum(r['completion']['matched'] for r in v),
            'numeric_any':sum(r['completion'].get('numeric_verified',0)>0 for r in v),
            'optimizer_comparison_applicable':s!='zero'}
            for b in ('nomad','scipy') for s in ('zero','scalar','multivariate')
            for v in [[r for r in rows if r['backend']==b and r['stratum']==s]] if v],
        'zero_variable_limit':'The frozen plan accidentally included one zero-variable case (8 arms). All4 direct NOMAD calls exited with SIGSEGV, and SciPy has no optimization variable. Preserve those attempts; exclude the zero stratum only from optimization comparisons, never recast it as a production GeoSolver failure. No optimizer rerun of that case.',
        'scope':'Nine outcome-selected development cases, common evaluable starts, fixed actual calls, common original HP and Phase C. Per-arm successes are paired; not independent trials.',
        'cross_scope':'Fresh original/signed HP restarts share each frozen frontend selection for two central cases.'}


def multiplicity(archive,out,refs):
    rows=[]
    for index in range(107):
        p=archive/'development/multiplicity-proposal-v1'/(str(index)+'.json')
        if not p.exists():
            rows.extend({'point_index':index,'multiplicity':m,'proposal':q,'available':False,'identified_correct':False}
                        for m in ('original','projection') for q in ('original','continue_after_rejection'))
            continue
        r=loads(p.read_text())
        for source in r['rows']:
            symbolic=source.get('symbolic',{});result=symbolic.get('result');descriptor=getattr(result,'descriptor',None)
            canonical=key(descriptor.canonical_key()) if descriptor is not None else None
            rows.append({**{k:v for k,v in source.items() if k!='symbolic'},'available':True,
                'file':str(p),'raw_sha256':sha(p),'symbolic_status':symbolic.get('status'),
                'input_sha256':symbolic.get('input_sha256'),
                'identification_status':getattr(result,'exact_status',None),
                'identification_method':getattr(result,'identification_method',None),
                'identified_correct':canonical in refs['JMO-2013-PRE-05'],
                'proposals':len(symbolic.get('trace',[])),
                'inner_accepted_outer_rejected':sum(v.get('inner_accepted',False) and not v.get('outer_accepted',False) for v in symbolic.get('trace',[])),
                'symbolic_seconds':symbolic.get('seconds'),'symbolic_error':symbolic.get('error')})
    pairs=[]
    for i in range(107):
        rr=[r for r in rows if r['point_index']==i];lookup={(r['multiplicity'],r['proposal']):r for r in rr}
        if len(lookup)!=4:raise ValueError('Multiplicity x proposal accounting mismatch')
        diffs={}
        for m in ('original','projection'):
            a,b=[lookup[(m,p)] for p in ('original','continue_after_rejection')]
            same=a.get('input_sha256')==b.get('input_sha256')
            if a.get('input_sha256') and not same:raise ValueError('Proposal arms changed numeric input')
            diffs[m]=int(b['identified_correct'])-int(a['identified_correct'])
        pairs.append({'point_index':i,'proposal_effect_original':diffs['original'],
            'proposal_effect_projection':diffs['projection'],
            'interaction':diffs['projection']-diffs['original']})
    write(out/'multiplicity-proposal-runs.jsonl',rows);write(out/'multiplicity-proposal-pairs.jsonl',pairs)
    return {'planned':len(rows),'available':sum(r['available'] for r in rows),
        'arms':[{'multiplicity':m,'proposal':p,'n':len(rr),
            'input_gate':dict(Counter(str(r.get('gate','missing')) for r in rr)),
            'identified_correct':sum(r['identified_correct'] for r in rr),
            'method':dict(Counter(str(r.get('identification_method','missing')) for r in rr))}
            for m in ('original','projection') for p in ('original','continue_after_rejection')
            for rr in [[r for r in rows if (r['multiplicity'],r['proposal'])==(m,p)]]],
        'mean_interaction':statistics.mean(r['interaction'] for r in pairs),
        'scope':'107 dependent source candidates from one development problem; each proposal pair uses the identical saved verifier result.'}


def selection(archive,out):
    base=archive/'development/selection-replay-v2';plan=json.loads((base/'plan.json').read_text())
    scores=loads((base/'scores.json').read_text());rows=[];groups=[];eligible=[]
    dsl=json.loads((archive/'development/representations-v2/JMO-2013-PRE-05/original.json').read_text())
    evaluator=build_ir_evaluator(bundle_of(dsl))
    def measurement(r):
        x=r['pre_verifier_point'];g=jmo(x);numeric=check(evaluator,x,precision=180)
        correct=digit(g['goal_error']);return {'point':x,'independent_geometry':g,'goal_digits':correct,
            'stationary_original':numeric,'numeric_and_goal20':bool(numeric['numeric_conditions_passed'] and correct>=20)}
    with mp.workdps(600):
        for g in plan['groups']:
            rr=[]
            for job in g['jobs']:
                cmd=job['command'];p=Path(cmd[8]);index=int(cmd[7])
                row={'group':g['id'],'point_index':index,'file':str(p),'available':p.exists(),
                    'allocated_iterations':int(cmd[cmd.index('--iterations')+1])}
                if p.exists():
                    r=loads(p.read_text());row.update(raw_sha256=sha(p),status=r['status'],error=r['error'],
                        numeric_seconds=r['numeric_seconds'],censored=r['safety_deadline_hit'],calls=r['numeric_calls'],
                        **measurement(r))
                rr.append(row);rows.append(row)
            seed,ranking,k,variant=g['id'].split('__');digits=[r['goal_digits'] for r in rr if 'goal_digits' in r]
            groups.append({'group':g['id'],'seed':int(seed[4:]),'ranking':ranking,'k':int(k[1:]),'variant':variant,
                'planned':len(rr),'available':sum(r['available'] for r in rr),
                'total_iteration_cap':sum(r['allocated_iterations'] for r in rr),
                'best_goal_digits':max(digits,default=None),
                'numeric_and_goal20':any(r.get('numeric_and_goal20',False) for r in rr),
                'censored':sum(r.get('censored',False) for r in rr),
                'numeric_seconds':sum(r.get('numeric_seconds',0) for r in rr),
                'selected_indices':[r['point_index'] for r in rr]})
        # A descriptive response surface over all retained points, including
        # points not selected by any tested ranking. Existing80-step runs only.
        for score in scores['rows']:
            r={k:v for k,v in score.items() if k not in ('raw_jacobian','gradient')};i=score['index']
            for variant in ('original','projection'):
                p=archive/f'development/stage-campaign-v2/runs/JMO-2013-PRE-05/{i}/{variant}__lm100.json'
                if p.exists():
                    v=loads(p.read_text());r[variant+'_80step']=measurement(v)
                else:r[variant+'_80step']={'missing':str(p)}
            eligible.append(r)
    write(out/'selection-runs.jsonl',rows);write(out/'selection-groups.jsonl',groups)
    write(out/'selection-all-retained-points.jsonl',eligible)
    return {'planned_runs':len(rows),'available':sum(r['available'] for r in rows),'condition_groups':len(groups),
        'source_points':len(eligible),'source_ledgers':3,
        'by_variant':{v:{'groups':len(rr),'numeric_and_goal20':sum(r['numeric_and_goal20'] for r in rr),
            'median_best_goal_digits':med([r['best_goal_digits'] for r in rr if r['best_goal_digits'] is not None])}
            for v in ('original','projection') for rr in [[r for r in groups if r['variant']==v]]},
        'scope':'One natural problem; all rankings are reference blind but the assessment is outcome informed. No unconditional ranking superiority was preregistered.',
        'order_limitation':'Equal per-point allocations cannot test pure order effects on the final union; K1/K4 tests retained set and budget allocation.'}


def write(path,rows):path.write_text(''.join(dumps(r)+'\n' for r in rows))


def main(archive,out):
    if out.exists():raise FileExistsError(out)
    receipts=[archive/'development/common-completion-batch-v1/completion.json',
              archive/'development/selection-replay-v2/batch/completion.json']
    if any(json.loads(p.read_text()).get('status')!='complete' for p in receipts):raise ValueError('Prerequisites incomplete')
    out.mkdir(parents=True);refs=references()
    result={'common':common(archive,out,refs),'multiplicity_proposal':multiplicity(archive,out,refs),
        'selection':selection(archive,out),'script_sha256':sha(Path(__file__)),
        'reference_file_sha256':sha(Path(__file__).resolve().parents[1]/'cases.jsonl'),
        'receipt_hashes':{str(p):sha(p) for p in receipts}}
    (out/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();main(a.archive,a.output)
