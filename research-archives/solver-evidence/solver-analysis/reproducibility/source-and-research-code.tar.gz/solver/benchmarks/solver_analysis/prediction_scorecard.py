"""Report prospective coverage, pointwise orders, effects, and abstentions.

No classifier is fitted after observing outcomes. The always-success baseline
is reported, but the frozen theory abstains on global output and thus has no
comparable accuracy. Multiple directions, mirrors and goals stay within their
natural case. Independent coefficient checks use pre-existing input proofs.
"""
import argparse,hashlib,json,statistics
from collections import Counter,defaultdict
from pathlib import Path
from mpmath import mp
from exact_codec import loads,dumps


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readl(p):return [loads(v) for v in p.read_text().splitlines()]
def numeric(v):return float(v) if v is not None else None


def score(archive,split,out):
    if out.exists():raise FileExistsError(out)
    forecast=archive/'unknown-intake/individual-predictions-v1.json';f=json.loads(forecast.read_text())
    probes=loads((archive/f'unknown-local-v1/probes/{split}/summary.json').read_text())['rows']
    raw=loads((archive/f'unknown-local-v1/probes/{split}/raw.json').read_text())['rows']
    local=readl(archive/f'analysis/prospective-{split}-v1/runs.jsonl')
    pairs=readl(archive/f'analysis/prospective-{split}-v1/local-pairs.jsonl')
    out.mkdir(parents=True);bycase=defaultdict(list)
    for r in probes:bycase[r['case_id']].append(r)
    orders=[];coefficients=[]
    with mp.workdps(400):
        for ident,rr in sorted(bycase.items()):
            goals=[(r,g,v) for r in rr for g,v in r['goal_scoring'].items()]
            ratios=[(mp.mpf(v['predicted_q'])/r['predicted_m'],v['measured_q']/r['slopes']['residual'])
                for r,g,v in goals if v['predicted_q'] is not None and v['measured_q'] is not None]
            orders.append({'case_id':ident,'directions':len(rr),'m_pass':sum(r['m_pass'] for r in rr),
                'guard_valid_directions':sum(r['all_probes_guard_valid'] for r in rr),
                'certified_goal_directions':sum(v['predicted_q'] is not None for r,g,v in goals),
                'q_pass':sum(v['pass'] for r,g,v in goals if v['predicted_q'] is not None),
                'cancelled_goal_directions':sum(v['predicted_q'] is None for r,g,v in goals),
                'cancellation_controls_passed':sum(v['pass'] for r,g,v in goals if v['predicted_q'] is None),
                'unscored_directions':sum(not r['goal_scoring'] for r in rr),
                'mean_absolute_ratio_error':numeric(mp.fsum(abs(a-b) for a,b in ratios)/len(ratios)) if ratios else None,
                'always_half_mean_absolute_error':numeric(mp.fsum(abs(b-mp.mpf('.5')) for a,b in ratios)/len(ratios)) if ratios else None,
                'always_one_mean_absolute_error':numeric(mp.fsum(abs(b-1) for a,b in ratios)/len(ratios)) if ratios else None,
                'scope':'Direction/goal observations within one problem; mirrors and axes are not independent cases.'})
        # Quantitative constants already present in the input derivations.
        # These are descriptive errors, not a post-hoc pass-threshold change.
        for r in raw:
            if r['delta_exponent']!=12 or r['kind']!='axis':continue
            ident=r['case_id'];delta=r['delta'];expected=None;goal='physical';power=None
            if ident=='CEMC-EUCLID-2024-08A':
                power=4 if r['axis'] in ('d','f') else 2
                expected=81*mp.sqrt(2)/4 if power==4 else 18*mp.sqrt(2)
            elif ident=='CEMC-EUCLID-2026-08A':power=1;expected=1/(3*mp.sqrt(2))
            elif ident=='HMMT-NOV-2023-GEN-06':power=2;expected=1/(3*mp.sqrt(30))
            elif ident in ('HMMT-NOV-2025-GUTS-12','GENERATED-PARABOLA-NORMAL-FOLD'):power=1;expected=mp.mpf(1)
            elif ident=='UKMT-SMC-2025-16' and r['axis']=='s':power=1;expected=mp.mpf(1)
            if expected is not None:
                measured=r['goal_errors'][goal]/delta**power
                coefficients.append({'case_id':ident,'direction':r['direction'],'goal':goal,'power':power,
                    'predicted_absolute_leading_coefficient':expected,'measured_absolute_leading_coefficient':measured,
                    'relative_error':abs(measured-expected)/expected,'assessment':'Descriptive coefficient error; no new pass criterion.'})
    effects=[]
    for ident in sorted({r['case_id'] for r in pairs}):
        for variant in sorted({r['variant'] for r in pairs if r['case_id']==ident}):
            for dps in (50,100,200):
                rr=[r for r in pairs if r['case_id']==ident and r['variant']==variant and r['dps']==dps]
                if not rr:continue
                goals={}
                for goal in ('auxiliary','physical'):
                    vv=[r[goal] for r in rr if 'gain' in r.get(goal,{})]
                    if vv:goals[goal]={'n':len(vv),'median_digit_gain':statistics.median(v['gain'] for v in vv),
                        'positive':sum(v['gain']>0 for v in vv),'zero':sum(v['gain']==0 for v in vv),
                        'negative':sum(v['gain']<0 for v in vv),'baseline20':sum(v['baseline20'] for v in vv),
                        'intervention20':sum(v['intervention20'] for v in vv)}
                effects.append({'case_id':ident,'variant':variant,'dps':dps,'planned_pairs':len(rr),'goals':goals})
    corpus=[r for r in f['natural_corpus'] if r['split']==split]
    pilot=[]
    for c in corpus:
        p=archive/f'unknown-results/{split}/pilot-v3'/f"{c['case_id']}.json"
        row={'case_id':c['case_id'],'available':p.exists(),'automatic_input_positive':c['input_detection']['positive'],
            'global_prediction':c['global_success_prediction']}
        if p.exists():
            q=loads(p.read_text());row.update(classification=q['classification'],seconds=q['seconds'],
                float_calls=q['float_calls'],safety_censored=q.get('safety_censored'),error=q.get('error'),
                progress_log10=q.get('progress_log10'),root_order=q['root_goal_order_prediction'],
                input_sha256=q['input_sha256'],source_sha256=sha(p))
        pilot.append(row)
    ar=archive/f'analysis/unknown-{split}-global-v1/assessment.jsonl';global_rows=readl(ar)
    bystratum=[]
    for label in ('zero','scalar','multivariate'):
        rr=[r for r in global_rows if ('zero' if r.get('variables')==0 else 'scalar' if r.get('variables')==1 else 'multivariate')==label]
        if rr:bystratum.append({'stratum':label,'problems':len({r['case_id'] for r in rr}),'runs':len(rr),
            'matched':sum(r['matched'] for r in rr),'any_reference_value':sum(r.get('any_reference_value',False) for r in rr),
            'always_success_accuracy':sum(r['matched'] for r in rr)/len(rr)})
    receipt={'split':split,'natural_corpus_problems':len(corpus),
        'automatic_input_positive':sum(r['automatic_input_positive'] for r in pilot),
        'input_abstentions':sum(not r['automatic_input_positive'] for r in pilot),
        'global_theory_predictions':0,'global_theory_accuracy':None,
        'global_comparison_limit':'The frozen theory abstains on complete output; it cannot be claimed to beat always-success. Global rates are measurement context, not retrospective predictive accuracy.',
        'pilot_available':sum(r['available'] for r in pilot),'pilot_classes':dict(Counter(r.get('classification','missing') for r in pilot)),
        'pilot_total_seconds':sum(r.get('seconds',0) for r in pilot),
        'local_planned_runs':len(local),'local_available':sum(r['available'] for r in local),
        'local_analysis_errors':sum('analysis_error' in r for r in local),
        'local_safety_censored':sum(r.get('censored',False) for r in local),
        'orders':orders,'effects':effects,'global_by_stratum':bystratum,
        'forecast_sha256':sha(forecast),'script_sha256':sha(Path(__file__)),
        'ambiguous_forecast':'General6 says physical-target gain may be smaller because q2. This is not a quantitative directional claim and is not scored as correct: at equal coordinate improvement q2 can give a larger digit gain. Required coordinate accuracy and realized digit gain are distinct.',
        'information_levels':'Input factor recognition; fixed root-free pilot; input-derived root-centred local diagnostics; post-solution explanations kept separate.'}
    if split=='final':
        # This mechanism-enriched cohort has a different selection process;
        # it never replaces the original 30-case coverage denominator.
        extra=archive/'unknown-intake/final-extension-corpus-v1/cases.jsonl'
        extension=[]
        for c in map(json.loads,extra.read_text().splitlines()):
            ident=c['id'];p=archive/'unknown-results/final/pilot-v3'/(ident+'.json')
            r={'case_id':ident,'cohort':'generated' if ident.startswith('GENERATED-') else 'enriched_natural',
               'available':p.exists()}
            if p.exists():
                q=loads(p.read_text());r.update(automatic_input_positive=q['detection']['positive'],
                    classification=q['classification'],seconds=q['seconds'],float_calls=q['float_calls'],
                    root_order=q['root_goal_order_prediction'],error=q.get('error'),
                    safety_censored=q.get('safety_censored'),source_sha256=sha(p))
            extension.append(r)
        er=readl(archive/'analysis/unknown-final-extension-v1/assessment.jsonl')
        receipt['extension']={
            'scope':'Four mechanism-enriched natural cases plus one generated family with three height conditions; separate from source-balanced final30.',
            'pilot':extension,
            'global_by_cohort':[{ 'cohort':label,'problems':len({r['case_id'] for r in rr}),
                'runs':len(rr),'matched':sum(r['matched'] for r in rr),
                'any_reference_value':sum(r.get('any_reference_value',False) for r in rr),
                'empty_no_root_agreement':sum(r['matched'] and r.get('expected_no_feasible_configuration',False) for r in rr)}
                for label in ('enriched_natural','generated')
                for rr in [[r for r in er if ('generated' if r['case_id'].startswith('GENERATED-') else 'enriched_natural')==label]]]
        }
        (out/'extension-pilot.jsonl').write_text(''.join(dumps(v)+'\n' for v in extension))
    for name,rr in [('pilot',pilot),('orders',orders),('effects',effects),('coefficient-errors',coefficients)]:
        (out/(name+'.jsonl')).write_text(''.join(dumps(v)+'\n' for v in rr))
    (out/'summary.json').write_text(dumps(receipt)+'\n')
    print(json.dumps({k:receipt[k] for k in ('split','natural_corpus_problems','automatic_input_positive','local_planned_runs','local_analysis_errors','local_safety_censored')}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('split',choices=['mid','final']);p.add_argument('output',type=Path)
    a=p.parse_args();score(a.archive,a.split,a.output)
