"""Independent physical-coordinate assessment, separate from frozen chart generator."""
from prospective_geometry import *


def evaluate_physical(ident,values):
    """Original physical-coordinate arm, independently of construction lifts."""
    if ident==GEN:
        u,v,r=values
        if u==0 or v==0:raise ValueError('axis-intersection selection tie outside local branch')
        xx=u+mp.sign(u)*mp.sqrt(r*r-v*v);yy=v+mp.sign(v)*mp.sqrt(r*r-u*u)
        rs=[norm((u,v))-r,r-abs(5-v),norm((xx,yy))-6]
        margins=[r,u,5-u,abs(xx),abs(yy)]
        return {'original_coordinates':tuple(values),'goals':{'physical':mp.sqrt(u*u+25)},
            'residuals':rs,'guard':min(margins)>0,'guard_margins':margins,
            'branch':'farther intersection from A on each axis; selected continuously from positive input-derived branch'}
    if ident==GUTS:
        O=tuple(values[:2]);R=values[2];ls=[line(a,b) for a,b in cuts()]
        margins=[segment_parameter(foot(O,L),a,b)[1] for L,(a,b) in zip(ls,cuts())]+[R]
        return {'original_coordinates':tuple(values),'goals':{'physical':R},'residuals':[gap(O,R,L) for L in ls],
            'guard':min(margins)>0,'guard_margins':margins}
    if ident==CEMC:
        cx,cy,m,n=values;C=(cx,cy);ends=[(m,mp.mpf(-4)),(n,mp.mpf(-4))]
        ls=[line(C,end) for end in ends];os=[((mp.mpf(0),mp.mpf(0)),4),((mp.mpf(0),mp.mpf(3)),3)]
        margins=[-m,n,cy-6]+[segment_parameter(foot(O,L),C,end)[1] for L,end in zip(ls,ends) for O,R in os]
        return {'original_coordinates':tuple(values),'goals':{'physical':polygon((ends[0],ends[1],C))},
            'residuals':[gap(O,R,L) for L in ls for O,R in os],'guard':min(margins)>0,'guard_margins':margins}
    if ident==H25:
        a,b,alpha,beta=values;os=[(a,mp.mpf(5)),(b,mp.mpf(5))];rs=[mp.sqrt(a*a+25),mp.sqrt(b*b+25)]
        ls=[((mp.cos(t),mp.sin(t)),mp.mpf(p)) for t,p in ((alpha,3),(beta,12))]
        pts=[foot(o,L) for L in ls for o in os]
        margins=[b-a]+[L[1]-dot(L[0],o) for L in ls for o in os]+[mp.pi-abs(alpha),mp.pi-abs(beta)]
        return {'original_coordinates':tuple(values),'goals':{'physical':polygon([pts[i] for i in (0,2,3,1)])},
            'residuals':[gap(o,r,L) for L in ls for o,r in zip(os,rs)],'guard':min(margins)>0,'guard_margins':margins}
    return evaluate(ident,values)

