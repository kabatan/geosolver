"""Lossless JSON codec for trusted research stage artifacts (no pickle).

mpmath values store the exact binary sign/mantissa/exponent/bitcount tuple.
Decoding never rounds through the current mp.dps. Float hex retains signed zero.
Only explicitly registered data classes may be reconstructed.
"""

from __future__ import annotations

import dataclasses
import json
from enum import Enum

from mpmath import mp

from geosolver.engine.standard.contracts.candidate_record import (
    CandidateKey, FloatCandidate, RefinedCandidate, RefinementBatchResult, SearchBatchResult,
)
from geosolver.engine.standard.evaluation.classify_evaluation_failure import EvaluationStatus
from geosolver.engine.standard.orchestration.run_initial_probe import InitialProbeResult
from geosolver.engine.standard.refinement.refiner_config import RefinerConfig
from geosolver.engine.standard.search.nomad_config import NomadConfig
from geosolver.engine.standard.contracts.pipeline_result import ExactIdentificationResult
from geosolver.engine.standard.evaluation.final_verifier import FinalVerificationResult
from geosolver.engine.standard.evaluation.evaluate_answer_hp import HPAnswerEvaluation
from geosolver.engine.standard.evaluation.evaluate_hp_residual import HPResidualEvaluation
from geosolver.engine.standard.evaluation.evaluate_float_residual import FloatResidualEvaluation
from geosolver.problem.models import AlgebraicAnswer, AlgebraicNumberDescriptor, AffinePiAnswer
from geosolver.engine.standard.contracts.hard_feasibility_snapshot import HardFeasibilitySnapshot
from geosolver.engine.standard.contracts.selection_trace_entry import SelectionTraceEntry

CLASSES = {c.__name__: c for c in (
    CandidateKey, FloatCandidate, RefinedCandidate, RefinementBatchResult,
    SearchBatchResult, InitialProbeResult, RefinerConfig, NomadConfig, ExactIdentificationResult, FinalVerificationResult,
    HPAnswerEvaluation, HPResidualEvaluation, FloatResidualEvaluation, HardFeasibilitySnapshot, SelectionTraceEntry,
)}
ENUMS = {'EvaluationStatus': EvaluationStatus}
MODELS = {c.__name__:c for c in (AlgebraicAnswer,AlgebraicNumberDescriptor,AffinePiAnswer)}


def encode(value):
    if isinstance(value,mp.matrix):
        return {'@matrix':encode(value.tolist()),'rows':value.rows,'cols':value.cols}
    if hasattr(value, '_mpf_'):
        return {'@mpf': [str(i) for i in value._mpf_]}
    if isinstance(value, Enum):
        return {'@enum': type(value).__name__, 'value': value.value}
    if type(value).__name__ in MODELS and isinstance(value,tuple(MODELS.values())):
        return {'@model': type(value).__name__, 'value':encode(value.model_dump(mode='python'))}
    if dataclasses.is_dataclass(value):
        return {'@dataclass': type(value).__name__,
                'fields': {f.name: encode(getattr(value,f.name)) for f in dataclasses.fields(value)}}
    if isinstance(value, float):
        return {'@float': value.hex()}
    if isinstance(value, tuple):
        return {'@tuple': [encode(v) for v in value]}
    if isinstance(value, list):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        if not all(isinstance(k,str) for k in value):
            raise TypeError('Only string mapping keys are supported')
        return {k:encode(v) for k,v in value.items()}
    if value is None or isinstance(value,(str,int,bool)):
        return value
    raise TypeError(f'Unsupported exact artifact value: {type(value)}')


def decode(value):
    if isinstance(value,list):
        return [decode(v) for v in value]
    if not isinstance(value,dict):
        return value
    if '@mpf' in value:
        return mp.make_mpf(tuple(int(i) for i in value['@mpf']))
    if '@matrix' in value:
        a=mp.matrix(value['rows'],value['cols'])
        rows=decode(value['@matrix'])
        for i in range(a.rows):
            for j in range(a.cols):a[i,j]=rows[i][j]
        return a
    if '@float' in value:
        return float.fromhex(value['@float'])
    if '@tuple' in value:
        return tuple(decode(v) for v in value['@tuple'])
    if '@enum' in value:
        return ENUMS[value['@enum']](value['value'])
    if '@model' in value:
        return MODELS[value['@model']].model_validate(decode(value['value']))
    if '@dataclass' in value:
        return CLASSES[value['@dataclass']](**{k:decode(v) for k,v in value['fields'].items()})
    return {k:decode(v) for k,v in value.items()}


def dumps(value):
    return json.dumps(encode(value),ensure_ascii=False,sort_keys=True,allow_nan=False)


def loads(text):
    return decode(json.loads(text))


def validate_roundtrip():
    with mp.workdps(550):
        values=(mp.sqrt(2), mp.pi, mp.mpf('1e-1000'), mp.inf, -mp.inf, mp.nan,
                0.0, -0.0, float('inf'), 0.1)
        encoded=dumps(values)
    with mp.workdps(15):
        restored=loads(encoded)
        assert dumps(restored)==encoded
    return {'working_dps_on_save':550,'working_dps_on_load':15,
            'exact_roundtrip':True,'cases':len(values)}
