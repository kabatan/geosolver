"""Thirty-seed and repeated-seed analysis, with explicit dependence evidence."""
import argparse,hashlib,json,random,statistics
from collections import Counter,defaultdict
from pathlib import Path


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def point_key(x):
    return hashlib.sha256(json.dumps([float(v).hex() for v in x],separators=(',',':')).encode()).hexdigest()
def jaccard(a,b):return len(a&b)/len(a|b) if a|b else None


def compact(raw,assessment,path):
    solver=raw.get('solver_result') or {};d=solver.get('diagnostics',{});p=d.get('pipeline_summary',{})
    records=d.get('candidate_records') or [];ledger=p.get('candidate_ledger') or []
    sources={r['source']['candidate_uid']:r['source'] for r in records if r.get('source')}
    point_keys={point_key(s['x_float']) for s in sources.values()}
    point_keys|={point_key(s['values']) for s in ledger if s.get('values')}
    fallback=p.get('search_staged_fallback',{});seeds=set(fallback.get('primary_seed_values',[]))
    if fallback.get('triggered'):seeds|=set(fallback.get('fallback_seed_values',[]))
    source_seeds={s.get('origin_seed') for s in sources.values()}|{s.get('origin_seed') for s in ledger}
    source_seeds.discard(None)
    public=[];conflicts=[]
    # Only final emission records exist in uninstrumented runs. They are not
    # assigned earlier times or earlier coordinates from the same candidate UID.
    by_revision={(r.get('candidate_uid'),r.get('revision')):r for r in records}
    for e in p.get('exact_candidate_records',[]):
        c=e['candidate'];key=(c.get('candidate_uid'),c.get('revision'));other=by_revision.get(key)
        consistent=other is not None and all(other.get(k)==c.get(k) for k in ('x_hp','answer_hp','coordinate_precision_dps','answer_precision_dps'))
        if not consistent:conflicts.append({'uid':key[0],'revision':key[1],'reason':'no identical detailed record at emitted revision'})
        public.append({'uid':key[0],'revision':key[1],'coordinate_precision_dps':c.get('coordinate_precision_dps'),
            'answer_precision_dps':c.get('answer_precision_dps'),'x_sha256':hashlib.sha256(json.dumps(c.get('x_hp')).encode()).hexdigest(),
            'answer_hp':c.get('answer_hp'),'exact_status':e['exact_result']['exact_status'],
            'descriptor':e['exact_result'].get('descriptor'),'matches_recorded_revision':consistent})
    vrs=p.get('verification_records',[]);exact=p.get('exact_assembly',{})
    return {**assessment,'file':str(path),'sha256':sha(path),'numeric_feasible_reported':d.get('numeric_feasible'),
        'initial_probe':p.get('initial_probe',{}),'search':p.get('search',{}),'refinement':p.get('refinement',{}),
        'exact_assembly':exact,'staged_fallback':fallback,
        'rescue':{k:v for k,v in p.get('phase_rescue',{}).items() if k!='box_runs'},
        'discrete':p.get('phase_discrete_completion',{}),
        'candidate_statuses':dict(Counter(r.get('refinement_status') for r in records)),
        'candidate_count':len(records),'distinct_source_count':len(sources),'retained_source_point_keys':sorted(point_keys),
        'scheduled_search_seeds':sorted(seeds),'observed_source_seeds':sorted(source_seeds),
        'verified_revisions':sum(bool(v.get('verified')) for v in vrs),'verification_revisions':len(vrs),
        'verification_statuses':dict(Counter(v.get('status') for v in vrs)),
        'emission':public,'emission_revision_conflicts':conflicts,
        'emission_time_resolution':'Final run return only; no earlier answer timestamp inferred.'}


def analyze(archive,out):
    if out.exists():raise FileExistsError(out)
    receipt=json.loads((archive/'campaigns/detail-sequence-receipt.json').read_text())
    if receipt['status']!='complete':raise ValueError('detailed campaign incomplete')
    cohort=json.loads((archive/'analysis/baseline-v1/cohort.json').read_text());ids=set(cohort['cases'])
    rows=[];repeated=[]
    for name,is_repeat in [('baseline-5seed-20260911',False),('detail-30seed-20260911',False),('detail-repeat01-20260911',True)]:
        c=archive/'campaigns'/name
        for a in map(json.loads,(c/'assessment.jsonl').read_text().splitlines()):
            if a['case_id'] not in ids:continue
            p=c/'runs'/a['case_id']/(str(a['seed'])+'.json');r=compact(json.loads(p.read_text()),a,p)
            (repeated if is_repeat else rows).append(r)
    expected={(i,s) for i in ids for s in range(30)};seen={(r['case_id'],r['seed']) for r in rows}
    if expected!=seen or len(rows)!=len(expected):raise ValueError('missing or duplicate detailed runs')
    if {(r['case_id'],r['seed']) for r in repeated}!={(i,s) for i in ids for s in (0,1)}:raise ValueError('repeat accounting mismatch')
    out.mkdir(parents=True);bycase=defaultdict(list)
    for r in rows:bycase[r['case_id']].append(r)
    problem=[];overlaps=[];repeat_pairs=[]
    for ident,rr in sorted(bycase.items()):
        rr.sort(key=lambda r:r['seed']);feature=cohort['features'][ident]
        p={'case_id':ident,'variables':feature['variables'],'runs':len(rr),'matched':sum(r['matched'] for r in rr),
            'any_reference_value':sum(bool(r['actual']) and len(r['missing'])<len(r['expected']) for r in rr),
            'any_output':sum(bool(r['actual']) for r in rr),'extra_values':sum(bool(r['extra']) for r in rr),
            'numeric_feasible_reported':sum(bool(r['numeric_feasible_reported']) for r in rr),
            'median_wall':statistics.median(r['wall_seconds'] for r in rr),
            'p90_wall':sorted(r['wall_seconds'] for r in rr)[int(.9*(len(rr)-1))],
            'failure_stage':dict(Counter(str(r['failure_stage']) for r in rr)),
            'staged_fallback_triggered':sum(r['staged_fallback'].get('triggered',False) for r in rr),
            'rescue_triggered':sum(r['rescue'].get('triggered',False) for r in rr),
            'discrete_triggered':sum(r['discrete'].get('triggered',False) for r in rr),
            'distinct_scheduled_internal_seeds':len({s for r in rr for s in r['scheduled_search_seeds']}),
            'scheduled_internal_seed_slots':sum(len(r['scheduled_search_seeds']) for r in rr),
            'adjacent_outcome_changes':sum(a['matched']!=b['matched'] for a,b in zip(rr,rr[1:])),
            'emission_conflicts':sum(len(r['emission_revision_conflicts']) for r in rr)}
        for index,a in enumerate(rr):
            for b in rr[index+1:]:
                shared=set(a['scheduled_search_seeds'])&set(b['scheduled_search_seeds'])
                shared_points=set(a['retained_source_point_keys'])&set(b['retained_source_point_keys'])
                overlaps.append({'case_id':ident,'seeds':[a['seed'],b['seed']],'seed_distance':b['seed']-a['seed'],
                    'shared_scheduled_internal_seeds':sorted(shared),'shared_retained_points':len(shared_points),
                    'retained_point_jaccard':jaccard(set(a['retained_source_point_keys']),set(b['retained_source_point_keys'])),
                    'same_matched':a['matched']==b['matched']})
        problem.append(p)
    lookup={(r['case_id'],r['seed']):r for r in rows}
    for b in repeated:
        a=lookup[b['case_id'],b['seed']];pa=a['initial_probe'].get('best_random_point');pb=b['initial_probe'].get('best_random_point')
        repeat_pairs.append({'case_id':b['case_id'],'seed':b['seed'],'same_answer_set':a['actual']==b['actual'],
            'same_matched':a['matched']==b['matched'],'matched_first':a['matched'],'matched_repeat':b['matched'],
            'best_initial_probe_point_comparable':pa is not None and pb is not None,
            'same_best_initial_probe_point':pa==pb if pa is not None and pb is not None else None,
            'same_retained_point_set':a['retained_source_point_keys']==b['retained_source_point_keys'],
            'retained_point_jaccard':jaccard(set(a['retained_source_point_keys']),set(b['retained_source_point_keys'])),
            'wall_delta':b['wall_seconds']-a['wall_seconds'],
            'search_evaluation_delta':b['search'].get('evaluation_count',0)-a['search'].get('evaluation_count',0),
            'first_file':a['file'],'repeat_file':b['file']})
    for name,values in [('runs',rows),('repeat-runs',repeated),('seed-overlap-pairs',overlaps),('same-seed-pairs',repeat_pairs)]:
        (out/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in values))
    (out/'problem-results.json').write_text(json.dumps(problem,indent=2,ensure_ascii=False)+'\n')
    # Resample problems, never seed rows, for a descriptive cohort uncertainty.
    rng=random.Random(20260911);rates=[p['matched']/30 for p in problem]
    boot=sorted(statistics.mean(rng.choices(rates,k=len(rates))) for _ in range(10000))
    summary={'problems':len(ids),'main_runs':len(rows),'repeat_runs':len(repeated),
        'matched':sum(r['matched'] for r in rows),'stable30':sum(p['matched']==30 for p in problem),
        'mixed':sum(0<p['matched']<30 for p in problem),'never_matched':sum(p['matched']==0 for p in problem),
        'mean_problem_success':statistics.mean(rates),'problem_bootstrap95':[boot[249],boot[9749]],
        'uncertainty_scope':'Outcome-selected detailed cohort only; descriptive resampling by problem, not an unbiased population estimate.',
        'same_seed_same_answers':sum(r['same_answer_set'] for r in repeat_pairs),
        'same_seed_outcome_changes':sum(not r['same_matched'] for r in repeat_pairs),
        'same_seed_initial_probe_comparable':sum(r['best_initial_probe_point_comparable'] for r in repeat_pairs),
        'same_seed_initial_probe_identical':sum(r['same_best_initial_probe_point'] is True for r in repeat_pairs),
        'pairs_with_internal_seed_overlap':sum(bool(r['shared_scheduled_internal_seeds']) for r in overlaps),
        'pairs_with_identical_retained_point':sum(r['shared_retained_points']>0 for r in overlaps),
        'emission_revision_conflicts':sum(len(r['emission_revision_conflicts']) for r in rows+repeated),
        'source_hash':receipt['source_hash'],'script_sha256':sha(Path(__file__)),
        'limits':['Overlap of retained points is a lower bound; uninstrumented runs do not save every initial point.',
            'Normal completion may exhaust an internal stage budget; status labels are not causal failure attribution.',
            'Numeric feasibility is a solver diagnostic; independent original-geometry proofs are separate case studies.']}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);a=p.parse_args();analyze(a.archive,a.output)
