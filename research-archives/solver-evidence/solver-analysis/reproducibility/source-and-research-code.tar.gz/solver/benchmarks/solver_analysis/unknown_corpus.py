"""Assemble the preregistered source corpus without invoking a solver.

AST fingerprints are a duplicate SCREEN, not a geometric isomorphism proof.
The coefficient-blind version flags identical written templates; operation
counts provide nearest neighbours for subsequent manual topology review.
"""
from __future__ import annotations
import argparse
import ast
import collections
import hashlib
import json
from pathlib import Path
import subprocess


def canonical(dsl, omit_numbers=False):
    names={v:f'v{i}' for i,v in enumerate(dsl['variables'])}
    names.update({v['name']:f'c{i}' for i,v in enumerate(dsl['constructions'])})
    class Rename(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Name(id=names.get(node.id,node.id),ctx=ast.Load()),node)
        def visit_Constant(self,node):
            if omit_numbers and isinstance(node.value,(int,float)):
                return ast.copy_location(ast.Constant(value='NUMBER'),node)
            return node
    def expression(s):return ast.dump(Rename().visit(ast.parse(str(s),mode='eval')),include_attributes=False)
    result={'n':len(dsl['variables']),
        'constructions':[expression(v['expression']) for v in dsl['constructions']],
        'conditions':sorted(json.dumps({k:expression(v) if k in ('left','right','predicate') else v for k,v in r.items()},sort_keys=True) for r in dsl['conditions']),
        'target':expression(dsl['target'])}
    return hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()


def signature(dsl):
    out=collections.Counter({'variables':len(dsl['variables'])})
    expressions=[v['expression'] for v in dsl['constructions']]+[dsl['target']]
    for r in dsl['conditions']:
        expressions.extend(r[k] for k in ('left','right','predicate') if k in r)
        out['condition:'+r.get('operator','predicate')]+=1
    for expression in expressions:
        for n in ast.walk(ast.parse(str(expression),mode='eval')):
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):out['call:'+n.func.id]+=1
    return out


def distance(a,b):
    return sum(abs(a[k]-b[k]) for k in a.keys()|b.keys())/max(1,sum(a.values())+sum(b.values()))


def build(intake,destination,repo,experiment):
    if destination.exists():raise FileExistsError(destination)
    semantic=[]
    for name in ('authored-hmmt-v1','authored-cemc-v0','authored-ukmt-v0'):
        semantic.extend(json.loads((intake/name/'semantic-manifest.json').read_text()))
    assert len(semantic)==60 and len({r['dsl']['id'] for r in semantic})==60
    paths=subprocess.check_output(['rg','--files',str(repo/'benchmarks/dsl'),
        str(experiment/'research/datasets'),str(experiment/'benchmarks/generated')],text=True).splitlines()
    historical=[];errors=[]
    def add(dsl,path):
        if isinstance(dsl,dict) and {'variables','constructions','conditions','target'}<=dsl.keys():
            historical.append({'id':dsl.get('id',Path(path).stem),'path':path,
                'exact':canonical(dsl),'template':canonical(dsl,True),'signature':signature(dsl)})
    for p in paths:
        if not p.endswith(('.json','.jsonl')):continue
        try:
            text=Path(p).read_text()
            values=[json.loads(r) for r in text.splitlines() if r.strip()] if p.endswith('.jsonl') else [json.loads(text)]
            for doc in values:
                for row in doc if isinstance(doc,list) else [doc]:
                    add(row,p)
                    if isinstance(row,dict):add(row.get('dsl'),p)
        except Exception as ex:errors.append({'path':p,'error':type(ex).__name__+': '+str(ex)})
    seen=set();historical=[r for r in historical if (r['id'],r['exact']) not in seen and not seen.add((r['id'],r['exact']))]
    inventory=experiment/'research/datasets/competition_geometry_20y/scope_inventory.jsonl'
    historical_ids={r['id'] for r in historical}
    if inventory.exists():historical_ids|={json.loads(v)['problem_id'] for v in inventory.read_text().splitlines() if v}
    destination.mkdir(parents=True);audit=[];counts=collections.Counter()
    for row in semantic:
        dsl=row['dsl'];ident=dsl['id'];split=row['split'];counts[(split,row['source_organization'])]+=1
        base=destination/split;path=base/'dsl'/(ident+'.json');path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(Path(row['dsl_path']).read_bytes())
        rec={'id':ident,'dsl_path':'dsl/'+path.name,'dsl':dsl,'answer':[],
            'truth_status':'unverified','authoring_status':'runnable','dedupe_key':ident,
            'source':row['source_organization']+' '+row['source_file']+' p'+str(row['source_page_1based']),
            'source_family':row['family'],'semantic_notes':row['semantic_notes']}
        with (base/'cases.jsonl').open('a') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        exact=canonical(dsl);template=canonical(dsl,True);sig=signature(dsl)
        near=sorted(historical,key=lambda r:(distance(sig,r['signature']),r['id']))[:3]
        audit.append({'id':ident,'split':split,'family':row['family'],'source_hash':row['sha256'],
            'id_overlap':ident in historical_ids,
            'written_ast_duplicates':[{'id':r['id'],'path':r['path']} for r in historical if r['exact']==exact],
            'coefficient_blind_template_matches':[{'id':r['id'],'path':r['path']} for r in historical if r['template']==template],
            'nearest_operation_profiles':[{'id':r['id'],'path':r['path'],'distance':distance(sig,r['signature'])} for r in near],
            'manual_geometric_isomorphism_review':'pending; no novelty certification from AST alone'})
    assert set(counts.values())=={10}
    receipt={'schema':1,'selection':str(intake/'selection-v1.json'),
        'selection_sha256':hashlib.sha256((intake/'selection-v1.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_counts':{s+':'+o:n for (s,o),n in counts.items()},'historical_distinct_inputs':len(historical),
        'historical_inventory_ids':len(historical_ids),'read_errors':errors,'solver_calls':0,'references_in_inputs':False,
        'limitation':'Exact AST and coefficient-free template matching are incomplete; nearest profiles are only manual-review prompts.',
        'rows':audit}
    (destination/'duplicate-screen.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='rows'}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('intake',type=Path);p.add_argument('destination',type=Path)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--experiment',type=Path,required=True)
    a=p.parse_args();build(a.intake,a.destination,a.repo,a.experiment)
