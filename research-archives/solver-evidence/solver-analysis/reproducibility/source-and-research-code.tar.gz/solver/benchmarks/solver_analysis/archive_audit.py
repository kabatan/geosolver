"""Verify immutable historical runs and build a discovery-only evidence index.

This module does not execute a solver. References are used only for cohort
selection and never passed to the stage replay harness.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import statistics
import tarfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def features(case):
    dsl = case['dsl']
    text = json.dumps(dsl)
    calls = set(re.findall(r'\b([A-Z][A-Za-z]+)\(', text))
    return {'variables': len(dsl['variables']),
            'equalities': sum(c.get('operator') == '=' for c in dsl['conditions']),
            'guards': sum(c.get('operator') != '=' for c in dsl['conditions']),
            'constructions': len(dsl['constructions']),
            'calls': sorted(calls), 'target': dsl['target']}


def select_cohort(cases, assessment):
    grouped = defaultdict(list)
    for row in assessment:
        grouped[row['case_id']].append(row)
    stats = {}
    for case in cases:
        rows = grouped[case['id']]
        stats[case['id']] = {**features(case), 'matched': sum(r['matched'] for r in rows),
                            'runs': len(rows),
                            'median_wall': statistics.median(r['wall_seconds'] for r in rows)}
    fragile = sorted(i for i,s in stats.items() if s['matched'] < s['runs'])
    controls = [i for i,s in stats.items() if s['matched'] == s['runs'] and s['variables']]
    selected = set()
    pairs = []
    def distance(a, b):
        x,y = stats[a],stats[b]
        cx,cy = set(x['calls']),set(y['calls'])
        return (3*abs(x['variables']-y['variables'])
                + .5*abs(x['equalities']-y['equalities'])
                + .1*abs(x['guards']-y['guards'])
                + .1*abs(x['constructions']-y['constructions'])
                + 3*(1-len(cx&cy)/max(1,len(cx|cy))))
    # Deterministic outcome-informed discovery cohort; not a confirmatory match.
    for index, ident in enumerate(sorted(fragile, key=lambda i:(-stats[i]['variables'],i))):
        eligible = [c for c in controls if c not in selected]
        near = sorted(eligible,key=lambda c:(distance(ident,c),c))[:6]
        control = sorted(near,key=lambda c:(stats[c]['median_wall'],c))[0 if index%2==0 else -1]
        selected.add(control)
        pairs.append({'case':ident,'control':control,'distance':distance(ident,control),
                      'speed_preference':'fast' if index%2==0 else 'slow'})
    while len(selected)<21:
        remaining=[c for c in controls if c not in selected]
        control=min(remaining,key=lambda c:(min(distance(i,c) for i in fragile),c))
        selected.add(control)
    return {'selection_status':'discovery; uses archived outcomes; never unknown validation',
            'rule':'3|dimension gap| + .5|equality gap| + .1|guard gap| + .1|construction gap| + 3 Jaccard call distance; alternate fastest/slowest of nearest six unused controls; two closest extra controls',
            'fragile':fragile,'controls':sorted(selected),'pairs':pairs,'features':stats}


def compact(run):
    result=run.get('solver_result') or {}
    diag=result.get('diagnostics') or {}
    pipeline=diag.get('pipeline_summary') or {}
    candidates=diag.get('candidate_records') or []
    verifications=pipeline.get('verification_records') or []
    return {'case_id':run['case_id'],'seed':run['seed'],
            'source_hash':run.get('source_hash'),'problem_hash':run.get('problem_hash'),
            'execution_contract_issues':run.get('execution_contract_issues'),
            'status':result.get('status'),'termination_reason':result.get('termination_reason'),
            'wall_seconds':result.get('elapsed_seconds'),'process':run.get('process'),
            'numeric_feasible':diag.get('numeric_feasible'),
            'answers':result.get('answers'), 'rejection_tags':diag.get('rejection_tags'),
            'phase_timings':diag.get('phase_timings'),'counters':diag.get('counters'),
            'candidate_count':len(candidates),'candidate_key_sets':dict(Counter(','.join(sorted(c)) for c in candidates)),
            'verification_count':len(verifications),
            'pipeline_summary_keys':list(pipeline),
            'verification_reasons':dict(Counter(str(r.get('rejection_reason',r.get('reason',r.get('rejection_tags')))) for r in verifications))}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('archive',type=Path)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    cases=[json.loads(x) for x in (ROOT/'benchmarks/cases.jsonl').read_text().splitlines() if x]
    assessment=[json.loads(x) for x in (args.archive/'final-v4/assessment.jsonl').read_text().splitlines() if x]
    cohort=select_cohort(cases,assessment)
    dump(args.output/'discovery-cohort.json',cohort)
    selected=set(cohort['fragile']+cohort['controls'])
    dump(args.output/'discovery-cases.json',[c for c in cases if c['id'] in selected])
    hashes=json.loads((args.archive/'archived-runs/final-v4.files.json').read_text())
    seen=set(); issues=[]; summaries=[]; source_hashes=Counter(); config_hashes=Counter()
    with tarfile.open(args.archive/'archived-runs/final-v4.tar.gz',mode='r|gz') as archive:
        for member in archive:
            if not member.isfile():
                continue
            if member.name not in hashes:
                issues.append({'member':member.name,'issue':'unexpected_member'})
                continue
            if member.name in seen:
                issues.append({'member':member.name,'issue':'duplicate_member'})
            seen.add(member.name)
            payload=archive.extractfile(member).read()
            digest=hashlib.sha256(payload).hexdigest()
            if digest!=hashes[member.name]:
                issues.append({'member':member.name,'issue':'sha256_mismatch'})
                continue
            run=json.loads(payload)
            summaries.append(compact(run))
            source_hashes[run.get('source_hash')]+=1
            config_hashes[json.dumps(run.get('config'),sort_keys=True)]+=1
            if run['case_id'] in selected:
                destination=args.output/'raw'/run['case_id']/f"{run['seed']}.json"
                destination.parent.mkdir(parents=True,exist_ok=True)
                destination.write_bytes(payload)
    for missing in sorted(set(hashes)-seen):
        issues.append({'member':missing,'issue':'missing_member'})
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'run-index.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in summaries))
    receipt={'archive':str(args.archive),'expected':len(hashes),'seen':len(seen),'valid':len(summaries),
             'selected_cases':len(selected),'issues':issues,'source_hashes':dict(source_hashes),
             'config_counts':dict(config_hashes),
             'assessment_sha256':hashlib.sha256((args.archive/'final-v4/assessment.jsonl').read_bytes()).hexdigest(),
             'member_hash_index_sha256':hashlib.sha256((args.archive/'archived-runs/final-v4.files.json').read_bytes()).hexdigest()}
    dump(args.output/'audit-receipt.json',receipt)
    print(json.dumps(receipt,ensure_ascii=False))
    if issues:
        raise SystemExit(1)


if __name__=='__main__':
    main()
