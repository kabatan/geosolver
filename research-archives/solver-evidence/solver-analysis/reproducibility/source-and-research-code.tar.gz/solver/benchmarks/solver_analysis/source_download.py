"""Archive explicitly selected public problem papers, with integrity receipts."""
import argparse
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
from urllib.request import urlopen


def main():
    p=argparse.ArgumentParser();p.add_argument('manifest',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
    sources=json.loads(a.manifest.read_text());a.destination.mkdir(parents=True,exist_ok=True);receipt=[]
    for name,url in sources.items():
        output=a.destination/name
        if output.exists():raise FileExistsError(output)
        with urlopen(url,timeout=60) as response:
            data=response.read();resolved=response.url
        if not data.startswith(b'%PDF'):raise ValueError(f'Not a PDF: {url}')
        output.write_bytes(data)
        receipt.append({'name':name,'url':url,'resolved_url':resolved,'bytes':len(data),
                        'sha256':hashlib.sha256(data).hexdigest(),'retrieved_utc':datetime.now(timezone.utc).isoformat()})
        print(name,flush=True)
    target=a.destination/(a.manifest.stem+'-receipt.json')
    target.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
