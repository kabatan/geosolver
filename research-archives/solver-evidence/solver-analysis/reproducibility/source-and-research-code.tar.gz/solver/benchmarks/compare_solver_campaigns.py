"""Pair immutable campaign assessments; include regressions and all-case cost."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import median

METRICS = ("process_wall_seconds", "wall_seconds", "cpu_seconds", "peak_rss_bytes")


def stats(values):
    values = sorted(value for value in values if isinstance(value, int | float))
    return {
        "observed": len(values),
        "total": sum(values),
        "median": median(values) if values else None,
        "p95": values[math.ceil(0.95 * len(values)) - 1] if values else None,
        "max": max(values) if values else None,
    }


def compare(before: Path, after: Path, destination: Path, seeds=None):
    manifests = [
        json.loads((path / "campaign-manifest.json").read_text()) for path in (before, after)
    ]
    for field in ("time_limit_seconds", "cores", "thread_environment"):
        if manifests[0]["config"][field] != manifests[1]["config"][field]:
            raise ValueError(f"incomparable execution configuration: {field}")
    if manifests[0]["dependency_lock_hash"] != manifests[1]["dependency_lock_hash"]:
        raise ValueError("dependency changes require a separate experiment")
    data = []
    for path in (before, after):
        rows = [json.loads(line) for line in (path / "assessment.jsonl").read_text().splitlines()]
        data.append(
            {
                (row["case_id"], row["seed"]): row
                for row in rows
                if seeds is None or row["seed"] in seeds
            }
        )
    if data[0].keys() != data[1].keys():
        raise ValueError("comparisons must contain the same case/seed pairs")
    if not data[0]:
        raise ValueError("comparison contains no runs")
    input_hashes = [
        {case["id"]: case.get("problem_hash") for case in manifest.get("cases", ())}
        for manifest in manifests
    ]
    input_hashes_verified = True
    for identifier, _seed in data[0]:
        hashes = [inputs.get(identifier) for inputs in input_hashes]
        if all(hashes) and hashes[0] != hashes[1]:
            raise ValueError(f"problem input changed: {identifier}")
        input_hashes_verified &= all(hashes)
    paired = []
    for key in sorted(data[0]):
        old, new = (rows[key] for rows in data)
        if old["expected"] != new["expected"]:
            raise ValueError(f"reference changed: {key}")
        row = {
            "case_id": key[0],
            "seed": key[1],
            "before_matched": old["matched"],
            "after_matched": new["matched"],
            "before_status": old["status"],
            "after_status": new["status"],
            "before_relation": old["set_relation"],
            "after_relation": new["set_relation"],
        }
        for metric in METRICS:
            row[f"before_{metric}"] = old.get(metric)
            row[f"after_{metric}"] = new.get(metric)
            row[f"delta_{metric}"] = (
                new[metric] - old[metric]
                if old.get(metric) is not None and new.get(metric) is not None
                else None
            )
        paired.append(row)
    common = [key for key in data[0] if all(rows[key]["matched"] for rows in data)]
    summary = {
        "run_count": len(paired),
        "sources": [str(before), str(after)],
        "source_hashes": [manifest["source_hash"] for manifest in manifests],
        "input_hashes_verified": bool(input_hashes_verified),
        "execution_layouts": [manifest.get("execution_layout") for manifest in manifests],
        "completeness": "unknown",
        "common_solved_count": len(common),
    }
    for label, rows in zip(("before", "after"), data, strict=True):
        values = list(rows.values())
        summary[label] = {
            "matched": sum(row["matched"] is True for row in values),
            "extra": sum(bool(row["extra"]) for row in values),
            "partial": sum(bool(row["missing"]) and bool(row["actual"]) for row in values),
            "errors": sum(row["status"] == "error" for row in values),
            "no_answer_runs": sum(not row["actual"] for row in values),
            "time_limit_terminations": sum(
                row.get("termination_reason") == "time_limit_reached" for row in values
            ),
            "metrics": {metric: stats(row.get(metric) for row in values) for metric in METRICS},
            "common_solved_time": stats(rows[key].get("process_wall_seconds") for key in common),
            "counter_totals": {
                counter: sum(row.get("counters", {}).get(counter, 0) for row in values)
                for counter in sorted(
                    {counter for row in values for counter in row.get("counters", {})}
                )
            },
            "phase_totals": {
                phase: sum(row.get("phase_timings", {}).get(phase, 0) for row in values)
                for phase in sorted(
                    {phase for row in values for phase in row.get("phase_timings", {})}
                )
            },
        }
    summary["gained"] = [
        list(key) for key in data[0] if not data[0][key]["matched"] and data[1][key]["matched"]
    ]
    summary["lost"] = [
        list(key) for key in data[0] if data[0][key]["matched"] and not data[1][key]["matched"]
    ]
    count = len(paired)
    accuracy_delta = (summary["after"]["matched"] - summary["before"]["matched"]) / count
    old_time = summary["before"]["metrics"]["process_wall_seconds"]["total"]
    new_time = summary["after"]["metrics"]["process_wall_seconds"]["total"]
    complete_timing = all(
        summary[label]["metrics"]["process_wall_seconds"]["observed"] == count
        for label in ("before", "after")
    )
    ratio = new_time / old_time if old_time else None
    summary["accuracy_delta_percentage_points"] = 100 * accuracy_delta
    summary["all_case_time_ratio"] = ratio
    summary["numerical_gate_passed"] = bool(
        complete_timing
        and input_hashes_verified
        and ratio is not None
        and summary["after"]["extra"] == 0
        and (
            (accuracy_delta >= 0 and ratio <= 1 and (accuracy_delta > 0 or ratio < 1))
            or (accuracy_delta >= -0.01 and ratio <= 0.8)
            or (accuracy_delta >= 0.01 and ratio <= 1.1)
        )
    )
    summary["adoption_requires"] = "general mechanism, independent families, unchanged verification"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "comparison.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (destination / "cases.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(paired[0]))
        writer.writeheader()
        writer.writerows(paired)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("before", type=Path)
    parser.add_argument("after", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--seeds", type=lambda s: set(map(int, s.split(","))))
    args = parser.parse_args()
    print(json.dumps(compare(args.before, args.after, args.destination, args.seeds), indent=2))
