"""Report analytic-family accuracy and equivalent-form agreement independently."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

if __package__:
    from .compare_solver_campaigns import stats
else:
    from compare_solver_campaigns import stats


def summarize(campaign: Path, family_manifest: Path, destination: Path):
    manifest = json.loads(family_manifest.read_text())
    cases = {row["id"]: row for row in manifest["cases"]}
    rows = [json.loads(line) for line in (campaign / "assessment.jsonl").read_text().splitlines()]
    rows = [row for row in rows if row["case_id"] in cases]
    families = {}
    for family in sorted({cases[row["case_id"]]["family"] for row in rows}):
        selected = [row for row in rows if cases[row["case_id"]]["family"] == family]
        pairs = {}
        for row in selected:
            item = cases[row["case_id"]]
            # Case index, not sampled parameters: repeated parameter draws remain distinct.
            key = (row["case_id"].rsplit("-", 1)[0], row["seed"])
            pairs.setdefault(key, {})[item["variant"]] = row
        complete = [pair for pair in pairs.values() if set(pair) == {"original", "equivalent"}]
        families[family] = {
            "runs": len(selected),
            "exact_matches": sum(row["matched"] is True for row in selected),
            "extra_answer_runs": sum(bool(row["extra"]) for row in selected),
            "process_time": stats(row.get("process_wall_seconds") for row in selected),
            "paired_instances": len(complete),
            "both_forms_correct": sum(
                all(row["matched"] for row in pair.values()) for pair in complete
            ),
            "correctness_disagreements": sum(
                pair["original"]["matched"] != pair["equivalent"]["matched"] for pair in complete
            ),
            "answer_set_disagreements": sum(
                sorted(json.dumps(value, sort_keys=True) for value in pair["original"]["actual"])
                != sorted(
                    json.dumps(value, sort_keys=True) for value in pair["equivalent"]["actual"]
                )
                for pair in complete
            ),
        }
    report = {
        "campaign": str(campaign),
        "family_manifest": str(family_manifest),
        "families": families,
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign", type=Path)
    parser.add_argument("family_manifest", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    print(json.dumps(summarize(args.campaign, args.family_manifest, args.destination), indent=2))
