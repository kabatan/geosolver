"""Fixed analytic problem families for solver improvement experiments.

Families, split, seed, and equivalence rules are fixed before campaign tuning.
The runner receives DSL only; answers are used exclusively by assessment.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from pathlib import Path

SEED = 20260907
FAMILIES = {
    "tuning": ("polynomial", "closed_endpoint", "scaled_linear", "tangent_polynomial"),
    "holdout": ("circle_line", "bisector", "right_triangle", "reflected_distance"),
}


def equality(left, right=0):
    return {"left": left, "operator": "=", "right": str(right)}


def build_case(family, a, b):
    conditions, constructions, variables, target = [], [], ["x"], "x"
    derivation = ""
    if family == "polynomial":
        conditions = [equality(f"(x-({a}))*(x+({b}))")]
        answers = [str(a), str(-b)]
        derivation = "A factored quadratic vanishes exactly at a and -b."
    elif family == "closed_endpoint":
        conditions = [equality(f"x-({a})"), {"left": "x", "operator": ">=", "right": a}]
        answers = [str(a)]
        derivation = "The linear equation has the unique solution at the closed lower bound."
    elif family == "scaled_linear":
        variables = ["x", "y"]
        conditions = [equality(f"1e-8*(x+y-({a + b}))"), equality(f"1e8*(x-y-({a - b}))")]
        target = "x+2*y"
        answers = [str(a + 2 * b)]
        derivation = "Adding/subtracting two independent linear equations gives x=a, y=b."
    elif family == "tangent_polynomial":
        conditions = [equality(f"(x-({a}))**2*(x+({b}))**2")]
        answers = [str(a), str(-b)]
        derivation = "Squaring factors changes multiplicity but not their zero set."
    elif family == "circle_line":
        constructions = [
            {"name": "O", "expression": f"Point({b},0)"},
            {"name": "P", "expression": "Point(x,0)"},
        ]
        conditions = [equality("Distance(O,P)", a)]
        answers = [str(b - a), str(b + a)]
        derivation = "The x-axis intersects a circle centered at (b,0) of radius a at b +/- a."
    elif family == "bisector":
        constructions = [
            {"name": "P", "expression": f"Point(x,{b})"},
            {"name": "A", "expression": f"Point({-a},0)"},
            {"name": "B", "expression": f"Point({a},0)"},
        ]
        conditions = [equality("Distance(P,A)", "Distance(P,B)")]
        answers = ["0"]
        derivation = "Subtracting squared distances gives 4*a*x=0, with a strictly positive."
    elif family == "right_triangle":
        constructions = [
            {"name": "O", "expression": "Point(0,0)"},
            {"name": "P", "expression": f"Point({a},x)"},
        ]
        conditions = [equality("x", b)]
        target = "Distance(O,P)"
        answers = [f"sqrt({a * a + b * b})"]
        derivation = "The unique point is (a,b); Pythagoras gives its distance from the origin."
    elif family == "reflected_distance":
        constructions = [
            {"name": "P", "expression": f"Point(x,{b})"},
            {"name": "axis", "expression": "Line(Point(0,0),Point(0,1))"},
            {"name": "Q", "expression": "Reflect(P,axis)"},
        ]
        conditions = [equality("Distance(P,Q)", 2 * a)]
        answers = [str(-a), str(a)]
        derivation = "Reflection sends (x,b) to (-x,b), so 2*abs(x)=2*a."
    else:
        raise ValueError(family)
    return (
        dict(
            variables=variables, constructions=constructions, conditions=conditions, target=target
        ),
        answers,
        derivation,
    )


def generate(destination: Path):
    rng = random.Random(SEED)
    destination.mkdir(parents=True, exist_ok=True)
    manifest = {
        "seed": SEED,
        "split_by_family": FAMILIES,
        "cases": [],
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "completeness": "unknown",
    }
    for split, families in FAMILIES.items():
        rows = []
        for family in families:
            for index in range(6):
                a, b = rng.randint(1, 8), rng.randint(9, 16)
                dsl, answers, derivation = build_case(family, a, b)
                for variant in ("original", "equivalent"):
                    identifier = f"generated-{family}-{index}-{variant}"
                    problem = json.loads(json.dumps(dsl))
                    problem["id"] = identifier
                    if variant == "equivalent":
                        # Reverse equation order, add a redundant zero equality,
                        # and multiply each equality by a fixed nonzero factor.
                        transformed = []
                        for condition in reversed(problem["conditions"]):
                            if condition.get("operator") == "=":
                                transformed.append(
                                    equality(f"-7*(({condition['left']})-({condition['right']}))")
                                )
                            else:
                                transformed.append(condition)
                        problem["conditions"] = [equality("0"), *transformed]
                    relative = Path(split) / "dsl" / f"{identifier}.json"
                    path = destination / relative
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(json.dumps(problem, indent=2) + "\n")
                    rows.append(
                        {
                            "id": identifier,
                            "dsl": problem,
                            "dsl_path": str(Path("dsl") / path.name),
                            "answer": answers,
                            "source": f"analytic/{family}",
                            "truth_status": "verified",
                        }
                    )
                    manifest["cases"].append(
                        {
                            "id": identifier,
                            "family": family,
                            "split": split,
                            "parameters": [a, b],
                            "derivation": derivation,
                            "variant": variant,
                        }
                    )
        (destination / split / "cases.jsonl").write_text(
            "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
        )
    (destination / "family-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    generate(parser.parse_args().destination)
