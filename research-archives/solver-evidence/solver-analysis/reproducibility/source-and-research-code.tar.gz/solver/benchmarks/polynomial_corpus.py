"""Build and validate the frozen real polynomial-system benchmark corpus.

The builder consumes pinned, machine-readable upstream sources.  Selection is
based only on provenance and structural metadata; GeoSolver is never imported
or executed by this module.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shutil
import subprocess
import tempfile
import urllib.request
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any

import mpmath
import sympy
from jsonschema import Draft202012Validator
from sympy.parsing.sympy_parser import (
    convert_xor,
    parse_expr,
    rationalize,
    standard_transformations,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS = ROOT / "benchmarks" / "polynomial_systems"
CASES = CORPUS / "cases"
MANIFEST = CORPUS / "manifest.jsonl"
EXCLUSIONS = CORPUS / "exclusions.jsonl"
SOURCE_LOCK = CORPUS / "sources.lock.json"
CORPUS_LOCK = CORPUS / "corpus.lock.json"
AUDIT_REPORT = CORPUS / "AUDIT.md"
CERTIFICATION = CORPUS / "reference-certification.jsonl"

PHCPACK_COMMIT = "bbdd026814a92212ef9a9b86684d8f81d26e7e93"
PTS_COMMIT = "e04087ef08cf91ffafd88546c4d4ccb25613a3c7"
PHCPACK_URL = "https://github.com/janverschelde/PHCpack.git"
PHCPACK_WEB = "https://github.com/janverschelde/PHCpack"
PTS_URL = "https://github.com/JuliaHomotopyContinuation/PolynomialTestSystems.jl.git"
BERTINI_ROOT = "https://bertini.nd.edu/BertiniExamples/"

TRANSFORMATIONS = standard_transformations + (convert_xor, rationalize)
DOMAIN_COUNTS = {
    "pure_mathematics": 40,
    "robotics_geometry": 20,
    "biochemical_physical": 20,
    "economics_control_vision": 10,
    "numerical_stress": 10,
}
SIZE_COUNTS = {"2-4": 30, "5-7": 35, "8-10": 25, "11-12": 10}


class CorpusError(RuntimeError):
    """Raised when corpus evidence or invariants are invalid."""


@dataclass(frozen=True)
class Candidate:
    identifier: str
    title: str
    variables: tuple[str, ...]
    expressions: tuple[sympy.Expr, ...]
    family_id: str
    problem_group_id: str
    domain: str
    source: dict[str, Any]
    reference: dict[str, Any]
    selection_priority: int = 100


def canonical_json(value: object) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", delete=False
    ) as stream:
        temporary = Path(stream.name)
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n")
    temporary.replace(path)


def git_revision(path: Path) -> str:
    return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()


def require_upstream(path: Path, revision: str, name: str) -> None:
    if not (path / ".git").exists():
        raise CorpusError(f"{name}: not a git checkout: {path}")
    actual = git_revision(path)
    if actual != revision:
        raise CorpusError(f"{name}: expected {revision}, got {actual}")
    dirty = subprocess.check_output(
        ["git", "-C", str(path), "status", "--porcelain", "--untracked-files=no"],
        text=True,
    ).strip()
    if dirty:
        raise CorpusError(f"{name}: upstream checkout is dirty")


def rational_text(value: sympy.Expr) -> str:
    value = sympy.Rational(value)
    return str(value.p) if value.q == 1 else f"{value.p}/{value.q}"


def parse_expressions(texts: list[str], variables: list[str] | None = None):
    joined = " ".join(texts)
    if variables is None:
        variables = sorted(
            set(re.findall(r"(?<![0-9.])\b[A-Za-z_]\w*\b", joined)) - {"E", "I", "i"}
        )
    symbols = {name: sympy.Symbol(name) for name in variables}
    expressions = tuple(
        sympy.expand(
            parse_expr(
                " ".join(text.split()),
                local_dict=symbols,
                transformations=TRANSFORMATIONS,
                evaluate=True,
            )
        )
        for text in texts
    )
    for expression in expressions:
        sympy.Poly(expression, *(symbols[name] for name in variables), domain="QQ")
    return tuple(variables), expressions


def sparse_equations(candidate: Candidate) -> list[dict[str, Any]]:
    symbols = [sympy.Symbol(name) for name in candidate.variables]
    result = []
    for expression in candidate.expressions:
        polynomial = sympy.Poly(expression, *symbols, domain="QQ")
        terms = [
            {"coefficient": rational_text(coefficient), "exponents": list(exponents)}
            for exponents, coefficient in polynomial.terms()
        ]
        result.append({"terms": terms})
    return result


def normalized_equation(equation: dict[str, Any]) -> list[tuple[tuple[int, ...], int]]:
    pairs = [
        (tuple(term["exponents"]), Fraction(term["coefficient"])) for term in equation["terms"]
    ]
    common = math.lcm(*(item.denominator for _, item in pairs))
    integers = [(powers, int(value * common)) for powers, value in pairs]
    divisor = math.gcd(*(abs(value) for _, value in integers))
    integers = [(powers, value // divisor) for powers, value in integers]
    if integers[0][1] < 0:
        integers = [(powers, -value) for powers, value in integers]
    return integers


def canonical_hash(equations: list[dict[str, Any]]) -> str:
    ordered = sorted(equations, key=canonical_json)
    return sha256_bytes(canonical_json(ordered).encode())


def mathematical_hash(equations: list[dict[str, Any]]) -> str:
    normalized = sorted(normalized_equation(equation) for equation in equations)
    return sha256_bytes(canonical_json(normalized).encode())


def structural_metadata(candidate: Candidate) -> dict[str, Any]:
    symbols = [sympy.Symbol(name) for name in candidate.variables]
    polynomials = [sympy.Poly(item, *symbols, domain="QQ") for item in candidate.expressions]
    coefficients = [abs(Fraction(rational_text(c))) for p in polynomials for c in p.coeffs() if c]
    magnitudes = [float(item) for item in coefficients]
    return {
        "variable_count": len(symbols),
        "equation_count": len(polynomials),
        "maximum_total_degree": max(int(p.total_degree()) for p in polynomials),
        "monomial_count": sum(len(p.terms()) for p in polynomials),
        "coefficient_min_abs": min(magnitudes),
        "coefficient_max_abs": max(magnitudes),
        "coefficient_dynamic_range": max(magnitudes) / min(magnitudes),
    }


def scaled_residual(candidate: Candidate, witness: dict[str, tuple[str, str]]) -> float:
    mpmath.mp.dps = 80
    values = {sympy.Symbol(name): mpmath.mpf(witness[name][0]) for name in candidate.variables}
    maximum = mpmath.mpf("0")
    symbols = [sympy.Symbol(name) for name in candidate.variables]
    radius = max(mpmath.mpf("1"), *(abs(value) for value in values.values()))
    for expression in candidate.expressions:
        polynomial = sympy.Poly(expression, *symbols, domain="QQ")
        raw = abs(sympy.N(expression.subs(values), 80))
        degree = int(polynomial.total_degree())
        scale = 1 + sum(abs(sympy.N(c, 80)) for c in polynomial.coeffs()) * radius**degree
        maximum = max(maximum, mpmath.mpf(str(raw)) / mpmath.mpf(str(scale)))
    return float(maximum)


def phc_family(name: str) -> str:
    rules = [
        (r"^chandra", "chandra"),
        (r"^katsura", "katsura"),
        (r"^cyclic", "cyclic-original"),
        (r"^redcyc", "cyclic-reduced"),
        (r"^extcyc", "cyclic-extended"),
        (r"^eco", "economics-full"),
        (r"^redeco", "economics-reduced"),
        (r"^game", "game-two"),
        (r"^noon", "noon-network"),
        (r"^rbpl24", "rbpl24-formulations"),
        (r"^pb601", "pb601-formulations"),
        (r"^chemequ", "chemical-equilibrium-formulations"),
        (r"^comb3000", "combustion-formulations"),
        (r"^caprasse", "caprasse-formulations"),
        (r"^butcher8", "butcher8-formulations"),
        (r"^(pole|pltp)", "pole-placement"),
        (r"^tangents", "sphere-tangents"),
    ]
    for pattern, family in rules:
        if re.search(pattern, name):
            return family
    return name


STRESS_NAMES = {
    "butcher8b",
    "caprasse_new",
    "chemequs",
    "comb3000s",
    "discret3s",
    "pb601es",
    "pb601vs",
    "rbpl24es",
    "rbpl24s",
}
ROBOTICS_NAMES = {
    "assur44",
    "fourbar",
    "ipp",
    "kin1",
    "kinema",
    "puma",
    "rbpl",
    "rbpl24",
    "stewgou40",
    "tangents0",
    "tangents2",
    "utbikker",
}
BIO_NAMES = {
    "boon",
    "chemequ",
    "chemkin",
    "comb3000",
    "heart",
    "lorentz",
    "rediff3",
}
ECON_NAMES = {"camera1s", "filter9", "rose"}


def phc_domain(name: str) -> str:
    if name in STRESS_NAMES:
        return "numerical_stress"
    if name in ROBOTICS_NAMES:
        return "robotics_geometry"
    if name in BIO_NAMES or name.startswith("noon"):
        return "biochemical_physical"
    if name in ECON_NAMES or name.startswith(("eco", "redeco", "game")):
        return "economics_control_vision"
    return "pure_mathematics"


def phc_reference(text: str, variables: tuple[str, ...]) -> dict[str, Any]:
    blocks = re.split(r"(?m)^solution \d+\s*:", text)[1:]
    real_witnesses = []
    for block in blocks:
        section = block.split("== err", 1)[0]
        values = re.findall(
            r"^\s*([A-Za-z_]\w*)\s*:\s*([+\-0-9.Ee]+)\s+([+\-0-9.Ee]+)\s*$",
            section,
            re.MULTILINE,
        )
        by_name: dict[str, tuple[str, str]] = {}
        for name, real, imaginary in values:
            if name in variables:
                by_name[name] = (real, imaginary)
        if len(by_name) == len(variables) and all(
            abs(float(imaginary)) <= 1e-9 for _, imaginary in by_name.values()
        ):
            real_witnesses.append(by_name)
    count_match = re.search(rf"(?im)^\s*(\d+)\s+{len(variables)}\s*$", text)
    return {
        "source_solution_count": int(count_match.group(1)) if count_match else len(blocks),
        "source_solution_blocks": len(blocks),
        "source_real_blocks": len(real_witnesses),
        "witness": real_witnesses[0] if real_witnesses else None,
        "status": "source_witness_unchecked" if real_witnesses else "reference_pending",
        "certification": "upstream_approximation_only",
    }


PHC_EXCLUSIONS = {
    "caprasse_new": "exact duplicate of the caprasse system",
    "conform1": "upstream solutions contain no real root",
    "cyclic3": "upstream solutions contain no real root",
    "cyclic8": "positive-dimensional components and singular nonisolated roots",
    "cyclic10": "mixed volume exceeds the preregistered reference-cost ceiling",
    "cyclic11": "mixed volume exceeds the preregistered reference-cost ceiling",
    "mickeyq": "exact duplicate of the mickey system",
    "robspat": "upstream solutions contain no real root",
    "sparse5": "upstream solutions contain no real root",
    "tangents1": "upstream solutions contain no real root",
}


def load_phc_candidates(checkout: Path):
    demo = checkout / "src" / "Demo"
    candidates: list[Candidate] = []
    exclusions: list[dict[str, Any]] = []
    for path in sorted(demo.iterdir()):
        if not path.is_file() or path.name == "READ_ME":
            continue
        text = path.read_text(encoding="utf-8", errors="strict")
        header = re.match(r"\s*(\d+)\s*\n", text)
        if not header:
            exclusions.append({"id": f"phc-{path.name}", "reason": "invalid PHC header"})
            continue
        count = int(header.group(1))
        raw_equations = text[header.end() :].split(";", count)
        if len(raw_equations) <= count:
            exclusions.append({"id": f"phc-{path.name}", "reason": "truncated equations"})
            continue
        raw_equations = raw_equations[:count]
        joined = " ".join(raw_equations)
        if re.search(r"(?<![A-Za-z0-9_])i(?![A-Za-z0-9_])", joined):
            exclusions.append({"id": f"phc-{path.name}", "reason": "complex coefficients"})
            continue
        if count > 12:
            exclusions.append({"id": f"phc-{path.name}", "reason": "more than 12 variables"})
            continue
        if path.name in PHC_EXCLUSIONS:
            exclusions.append({"id": f"phc-{path.name}", "reason": PHC_EXCLUSIONS[path.name]})
            continue
        variables, expressions = parse_expressions(raw_equations)
        if len(variables) != count:
            exclusions.append(
                {
                    "id": f"phc-{path.name}",
                    "reason": f"{len(variables)} variables for {count} equations",
                }
            )
            continue
        title_match = re.search(r"(?m)^TITLE\s*:\s*(.+)$", text)
        reference = phc_reference(text, variables)
        candidates.append(
            Candidate(
                identifier=f"phc-{path.name.replace('_', '-')}",
                title=title_match.group(1).strip() if title_match else path.name,
                variables=variables,
                expressions=expressions,
                family_id=phc_family(path.name),
                problem_group_id=phc_family(path.name),
                domain=phc_domain(path.name),
                source={
                    "collection": "PHCpack Test Database",
                    "upstream_id": path.name,
                    "url": f"{PHCPACK_WEB}/blob/{PHCPACK_COMMIT}/src/Demo/{path.name}",
                    "revision": PHCPACK_COMMIT,
                    "sha256": sha256_file(path),
                    "license": "GPL-3.0-only",
                    "coefficient_semantics": "finite_decimal_literal_is_exact",
                },
                reference=reference,
            )
        )
    return candidates, exclusions


def pts_chandra(n: int) -> Candidate:
    names = [f"H{i}" for i in range(1, n + 1)]
    symbols = {name: sympy.Symbol(name) for name in names}
    c = sympy.Rational(51234, 100000)
    equations = []
    for i in range(1, n + 1):
        total = 1 + sum(sympy.Rational(i, j + i) * symbols[f"H{j}"] for j in range(1, n))
        equations.append(2 * n * symbols[f"H{i}"] - c * symbols[f"H{i}"] * total - 2 * n)
    return Candidate(
        identifier=f"pts-chandra-{n}",
        title=f"Chandrasekhar H-equation, n={n}",
        variables=tuple(names),
        expressions=tuple(equations),
        family_id="chandra",
        problem_group_id="chandra",
        domain="pure_mathematics",
        source={
            "collection": "PolynomialTestSystems.jl",
            "upstream_id": f"chandra({n})",
            "url": f"https://github.com/JuliaHomotopyContinuation/PolynomialTestSystems.jl/blob/{PTS_COMMIT}/src/systems.jl",
            "revision": PTS_COMMIT,
            "sha256": None,
            "license": "MIT",
            "coefficient_semantics": "finite_decimal_literal_is_exact",
        },
        reference={
            "source_solution_count": 2 ** (n - 1),
            "source_real_blocks": None,
            "witness": None,
            "status": "reference_pending",
            "certification": "pending",
        },
    )


def pts_katsura(n: int) -> Candidate:
    names = [f"x{i}" for i in range(n + 1)]
    x = [sympy.Symbol(name) for name in names]
    equations = []
    for m in range(n):
        equations.append(
            sum(
                x[abs(index)] * x[abs(m - index)]
                for index in range(-n, n + 1)
                if abs(m - index) <= n
            )
            - x[m]
        )
    equations.append(x[0] + 2 * sum(x[1:]) - 1)
    witness = {name: ("1" if index == 0 else "0", "0") for index, name in enumerate(names)}
    return Candidate(
        identifier=f"pts-katsura-{n}",
        title=f"Katsura magnetism system, n={n}",
        variables=tuple(names),
        expressions=tuple(equations),
        family_id="katsura",
        problem_group_id="katsura",
        domain="biochemical_physical",
        source={
            "collection": "PolynomialTestSystems.jl",
            "upstream_id": f"katsura({n})",
            "url": f"https://github.com/JuliaHomotopyContinuation/PolynomialTestSystems.jl/blob/{PTS_COMMIT}/src/systems.jl",
            "revision": PTS_COMMIT,
            "sha256": None,
            "license": "MIT",
            "coefficient_semantics": "exact_rational",
        },
        reference={
            "source_solution_count": 2**n,
            "source_real_blocks": None,
            "witness": witness,
            "status": "source_witness_unchecked",
            "certification": "exact_substitution",
        },
    )


def pts_bacillus() -> Candidate:
    names = ["w", "w2", "w2v", "v", "w2v2", "vP", "sigmaB", "w2sigmaB", "vPp", "phos"]
    equations = [
        "(-0.7*w - 2*3600*(w^2/2) + 2*18*w2)*(0.2+sigmaB) + 4*0.4*(1+30*sigmaB)",
        "-0.7*w2 + 3600*(w^2/2) - 18*w2 - 3600*w2*v + 18*w2v "
        "+ 36*w2v - 3600*w2*sigmaB + 18*w2sigmaB",
        "-0.7*w2v + 3600*w2*v - 18*w2v - 3600*w2v*v + 18*w2v2 "
        "- 36*w2v + 36*w2v2 + 1800*w2sigmaB*v - 1800*w2v*sigmaB",
        "(-0.7*v - 3600*w2*v + 18*w2v - 3600*w2v*v + 18*w2v2 "
        "- 1800*w2sigmaB*v + 1800*w2v*sigmaB + 180*vPp)*(0.2+sigmaB) "
        "+ 4.5*0.4*(1+30*sigmaB)",
        "-0.7*w2v2 + 3600*w2v*v - 18*w2v2 - 36*w2v2",
        "-0.7*vP + 36*w2v + 36*w2v2 - 3600*vP*phos + 18*vPp",
        "(-0.7*sigmaB - 3600*w2*sigmaB + 18*w2sigmaB + 1800*w2sigmaB*v "
        "- 1800*w2v*sigmaB)*(0.2+sigmaB) + 0.4*(1+30*sigmaB)",
        "-0.7*w2sigmaB + 3600*w2*sigmaB - 18*w2sigmaB - 1800*w2sigmaB*v + 1800*w2v*sigmaB",
        "-0.7*vPp + 3600*vP*phos - 18*vPp - 180*vPp",
        "phos + vPp - 2",
    ]
    variables, parsed = parse_expressions(equations, names)
    return Candidate(
        identifier="pts-bacillus-subtilis",
        title="Bacillus subtilis sigma-B response network",
        variables=variables,
        expressions=parsed,
        family_id="bacillus-subtilis",
        problem_group_id="bacillus-subtilis",
        domain="biochemical_physical",
        source={
            "collection": "PolynomialTestSystems.jl",
            "upstream_id": "bacillus_subtilis()",
            "url": f"https://github.com/JuliaHomotopyContinuation/PolynomialTestSystems.jl/blob/{PTS_COMMIT}/src/systems.jl",
            "revision": PTS_COMMIT,
            "sha256": None,
            "license": "MIT",
            "coefficient_semantics": "finite_decimal_literal_is_exact",
        },
        reference={
            "source_solution_count": 44,
            "source_real_blocks": None,
            "witness": None,
            "status": "reference_pending",
            "certification": "pending",
        },
    )


def pts_griewank_osborne() -> Candidate:
    variables, expressions = parse_expressions(["(29/16)*x^3-2*x*y", "x^2-y"], ["x", "y"])
    witness = {"x": ("0", "0"), "y": ("0", "0")}
    return Candidate(
        identifier="pts-griewank-osborne",
        title="Griewank-Osborne Newton-divergence example",
        variables=variables,
        expressions=expressions,
        family_id="griewank-osborne",
        problem_group_id="griewank-osborne",
        domain="numerical_stress",
        source={
            "collection": "PolynomialTestSystems.jl",
            "upstream_id": "griewank_osborne()",
            "url": f"https://github.com/JuliaHomotopyContinuation/PolynomialTestSystems.jl/blob/{PTS_COMMIT}/src/systems.jl",
            "revision": PTS_COMMIT,
            "sha256": None,
            "license": "MIT",
            "coefficient_semantics": "exact_rational",
        },
        reference={
            "source_solution_count": 3,
            "source_real_blocks": 1,
            "witness": witness,
            "status": "source_witness_unchecked",
            "certification": "exact_substitution; origin has multiplicity three",
        },
    )


def load_pts_candidates(checkout: Path) -> list[Candidate]:
    source_hash = sha256_file(checkout / "src" / "systems.jl")
    result = [pts_chandra(n) for n in (2, 3, 7, 8, 9, 10, 11, 12)]
    result.extend(pts_katsura(n) for n in (2, 3, 4, 11))
    result.append(pts_bacillus())
    result.append(pts_griewank_osborne())
    for candidate in result:
        candidate.source["sha256"] = source_hash
    return result


BERTINI_SPECS = [
    (
        "circle-y-axis",
        "Chap1PolynomialSystems/CircleAndYaxisC0.input",
        ["x", "y"],
        ["x^2+y^2-1", "x"],
        "robotics_geometry",
        {"x": ("0", "0"), "y": ("1", "0")},
    ),
    (
        "two-circles",
        "Chap4ProjectiveSpace/TwoCircles.input",
        ["x", "y"],
        ["x^2+y^2-1", "(x-1)^2+(y+1)^2-1"],
        "robotics_geometry",
        {"x": ("1", "0"), "y": ("0", "0")},
    ),
    (
        "two-hyperbolas",
        "Chap5HomotopyTypes/TwoHyperbolas_1Hom.input",
        ["x", "y"],
        ["x*y-1", "x*y+x-y-1"],
        "pure_mathematics",
        {"x": ("1", "0"), "y": ("1", "0")},
    ),
    (
        "two-quadrics",
        "Chap5HomotopyTypes/TwoQuadrics_1hom.input",
        ["x", "y"],
        ["x*y-1", "x^2-1"],
        "pure_mathematics",
        {"x": ("1", "0"), "y": ("1", "0")},
    ),
    (
        "high-condition",
        "Chap7AdvancedIsolated/HighCondNum.input",
        ["x", "y"],
        ["y-x^10", "y-1e-10"],
        "numerical_stress",
        {"x": ("0.1", "0"), "y": ("1e-10", "0")},
    ),
    (
        "circle-parabola",
        "Chap7AdvancedIsolated/CircleParabola_eval.input",
        ["x", "y"],
        ["x^2+(y-1)^2-1", "y-2*x^2"],
        "robotics_geometry",
        {"x": ("0.866025403784438646763723170752936", "0"), "y": ("1.5", "0")},
    ),
    (
        "rounding-error",
        "Chap7AdvancedIsolated/RoundingError.input",
        ["x", "y"],
        ["x*y^3-1.414214*y^3-1", "x^2-2"],
        "numerical_stress",
        None,
    ),
    (
        "scaled-system",
        "Chap7AdvancedIsolated/ScaledSystem.input",
        ["hatx", "haty"],
        ["hatx*haty-1", "hatx-haty-10"],
        "numerical_stress",
        None,
    ),
]


def fetch_bytes(url: str) -> bytes:
    with urllib.request.urlopen(url, timeout=30) as response:
        return response.read()


def bertini_candidates() -> list[Candidate]:
    result = []
    for name, relative, variables, equations, domain, witness in BERTINI_SPECS:
        payload = fetch_bytes(BERTINI_ROOT + relative)
        resolved_variables, parsed = parse_expressions(equations, variables)
        result.append(
            Candidate(
                identifier=f"bertini-{name}",
                title=f"Bertini example: {name.replace('-', ' ')}",
                variables=resolved_variables,
                expressions=parsed,
                family_id=f"bertini-{name}",
                problem_group_id=f"bertini-{name}",
                domain=domain,
                source={
                    "collection": "Bertini Examples",
                    "upstream_id": relative,
                    "url": BERTINI_ROOT + relative,
                    "revision": "retrieved-2026-09-01",
                    "sha256": sha256_bytes(payload),
                    "license": "Bertini-policy",
                    "coefficient_semantics": "finite_decimal_literal_is_exact",
                },
                reference={
                    "source_solution_count": None,
                    "source_real_blocks": None,
                    "witness": witness,
                    "status": "source_witness_unchecked" if witness else "reference_pending",
                    "certification": "exact_or_high_precision_substitution"
                    if witness
                    else "pending",
                },
            )
        )
    result.extend([bertini_lagrange(), bertini_tangent_spheres()])
    return result


def bertini_lagrange() -> Candidate:
    variables = ["w", "r1", "x", "y", "d13", "d23"]
    equations = [
        "w*r1-1",
        "w*(1-r1)-9",
        "(x-r1)^2+y^2-d13^2",
        "(x+(1-r1))^2+y^2-d23^2",
        "w*d13^3*d23^3*x + 9*d23^3*(r1-x) + d13^3*(-(1-r1)-x)",
        "w*d13^3*d23^3*y - 9*d23^3*y - d13^3*y",
    ]
    vars_, parsed = parse_expressions(equations, variables)
    relative = "Chap5HomotopyTypes/LagrangePoints.input"
    payload = fetch_bytes(BERTINI_ROOT + relative)
    return Candidate(
        identifier="bertini-lagrange-points",
        title="Bertini example: planar Lagrange points",
        variables=vars_,
        expressions=parsed,
        family_id="lagrange-points",
        problem_group_id="lagrange-points",
        domain="biochemical_physical",
        source={
            "collection": "Bertini Examples",
            "upstream_id": relative,
            "url": BERTINI_ROOT + relative,
            "revision": "retrieved-2026-09-01",
            "sha256": sha256_bytes(payload),
            "license": "Bertini-policy",
            "coefficient_semantics": "exact_rational",
        },
        reference={
            "source_solution_count": None,
            "source_real_blocks": None,
            "witness": None,
            "status": "reference_pending",
            "certification": "pending",
        },
    )


def bertini_tangent_spheres() -> Candidate:
    variables = [f"x{i}" for i in range(6)]
    x = [sympy.Symbol(name) for name in variables]
    tangent, moment = x[:3], x[3:]
    centers = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]
    equations = [
        sum(item**2 for item in tangent) - 1,
        sum(a * b for a, b in zip(tangent, moment, strict=True)),
    ]
    for center in centers:
        cross = (
            center[1] * tangent[2] - center[2] * tangent[1],
            center[2] * tangent[0] - center[0] * tangent[2],
            center[0] * tangent[1] - center[1] * tangent[0],
        )
        equations.append(
            sum((moment[i] - cross[i]) ** 2 for i in range(3)) - sympy.Rational(201, 100)
        )
    source = (
        "https://raw.githubusercontent.com/janverschelde/PHCpack/"
        f"{PHCPACK_COMMIT}/src/Python/PHCpy2/examples/tangents4spheres.sage"
    )
    payload = fetch_bytes(source)
    return Candidate(
        identifier="phcpy-tangent-four-spheres-perturbed",
        title="Common tangents to four perturbed touching spheres",
        variables=tuple(variables),
        expressions=tuple(equations),
        family_id="four-sphere-tangents",
        problem_group_id="four-sphere-tangents",
        domain="robotics_geometry",
        source={
            "collection": "PHCpack examples",
            "upstream_id": "tangents4spheres.sage:quadruples_perturbed",
            "url": source,
            "revision": PHCPACK_COMMIT,
            "sha256": sha256_bytes(payload),
            "license": "GPL-3.0-only",
            "coefficient_semantics": "finite_decimal_literal_is_exact",
        },
        reference={
            "source_solution_count": None,
            "source_real_blocks": None,
            "witness": None,
            "status": "reference_pending",
            "certification": "pending",
        },
    )


def phcpy_examples(checkout: Path) -> list[Candidate]:
    source = checkout / "src" / "Python" / "PHCpy3" / "examples" / "appolonius.py"
    result = []
    signs = [(a, b, c) for a in (-1, 1) for b in (-1, 1) for c in (-1, 1)]
    for index, (s1, s2, s3) in enumerate(signs):
        equations = [
            f"x^2+y^2-(r{'+1' if s1 > 0 else '-1'})^2",
            f"(x-2)^2+y^2-(r{'+0.666666666666667' if s2 > 0 else '-0.666666666666667'})^2",
            f"(x-1)^2+(y-1)^2-(r{'+0.333333333333333' if s3 > 0 else '-0.333333333333333'})^2",
        ]
        variables, parsed = parse_expressions(equations, ["x", "y", "r"])
        result.append(
            Candidate(
                identifier=f"phcpy-apollonius-{index}",
                title=f"Apollonius three-circle tangency, sign pattern {index}",
                variables=variables,
                expressions=parsed,
                family_id="apollonius-circles",
                problem_group_id="apollonius-circles",
                domain="robotics_geometry",
                source={
                    "collection": "PHCpack examples",
                    "upstream_id": f"appolonius.py:eqs{index}",
                    "url": (
                        "https://github.com/janverschelde/PHCpack/blob/"
                        f"{PHCPACK_COMMIT}/src/Python/PHCpy3/examples/appolonius.py"
                    ),
                    "revision": PHCPACK_COMMIT,
                    "sha256": sha256_file(source),
                    "license": "GPL-3.0-only",
                    "coefficient_semantics": "python_format_15_decimal_is_exact",
                },
                reference={
                    "source_solution_count": None,
                    "source_real_blocks": None,
                    "witness": None,
                    "status": "reference_pending",
                    "certification": "pending",
                },
            )
        )
    touch = checkout / "src" / "Python" / "PHCpy3" / "examples" / "touchcircle.py"
    for text in ("0.6", "0.7", "0.8", "0.9", "1.0"):
        variables, parsed = parse_expressions(["(x-3)^2+(y-2)^2-1", f"y-{text}*x"], ["x", "y"])
        result.append(
            Candidate(
                identifier=f"phcpy-circle-line-{text.replace('.', '-')}",
                title=f"Circle-line intersection, slope {text}",
                variables=variables,
                expressions=parsed,
                family_id="circle-line-slope",
                problem_group_id="circle-line-slope",
                domain="robotics_geometry",
                source={
                    "collection": "PHCpack examples",
                    "upstream_id": f"touchcircle.py:slope={text}",
                    "url": (
                        "https://github.com/janverschelde/PHCpack/blob/"
                        f"{PHCPACK_COMMIT}/src/Python/PHCpy3/examples/touchcircle.py"
                    ),
                    "revision": PHCPACK_COMMIT,
                    "sha256": sha256_file(touch),
                    "license": "GPL-3.0-only",
                    "coefficient_semantics": "finite_decimal_literal_is_exact",
                },
                reference={
                    "source_solution_count": 2,
                    "source_real_blocks": 2,
                    "witness": None,
                    "status": "reference_pending",
                    "certification": "pending",
                },
            )
        )
    return result


DEV_IDS = {
    "pts-chandra-2",
    "pts-chandra-3",
    "phc-chandra4",
    "phc-chandra5",
    "phc-chandra6",
    "pts-chandra-7",
    "pts-chandra-8",
    "pts-chandra-9",
    "phc-assur44",
    "phc-stewgou40",
    "phc-puma",
    "phc-kinema",
    "phc-boon",
    "phc-heart",
    "phc-rediff3",
    "pts-bacillus-subtilis",
    "phc-camera1s",
    "phc-filter9",
    "bertini-high-condition",
    "bertini-rounding-error",
}


def size_bucket(count: int) -> str:
    if count <= 4:
        return "2-4"
    if count <= 7:
        return "5-7"
    if count <= 10:
        return "8-10"
    return "11-12"


def choose_cases(candidates: list[Candidate]):
    by_id = {candidate.identifier: candidate for candidate in candidates}
    missing = DEV_IDS - by_id.keys()
    if missing:
        raise CorpusError(f"development IDs missing: {sorted(missing)}")
    development = [by_id[item] for item in sorted(DEV_IDS)]
    dev_families = {item.family_id for item in development}
    pool = [
        item
        for item in candidates
        if item.identifier not in DEV_IDS and item.family_id not in dev_families
    ]

    # At most five representatives of a parameterized/formulation family.
    limited = []
    family_counts: Counter[str] = Counter()
    for item in sorted(
        pool, key=lambda value: (value.selection_priority, value.family_id, value.identifier)
    ):
        if family_counts[item.family_id] >= 5:
            continue
        family_counts[item.family_id] += 1
        limited.append(item)

    # The v1 eligible pool was frozen before any GeoSolver run. Requiring its
    # exact size prevents an upstream/parser change from silently changing the
    # evaluation sample.
    if len(limited) != 100:
        raise CorpusError(f"expected exactly 100 post-limit candidates, got {len(limited)}")
    domains = Counter(item.domain for item in limited)
    sizes = Counter(size_bucket(len(item.variables)) for item in limited)
    return (
        development,
        limited,
        {
            "post_family_limit_candidates": len(limited),
            "domain_deviation": sum(
                abs(domains[key] - expected) for key, expected in DOMAIN_COUNTS.items()
            ),
            "size_deviation": sum(
                abs(sizes[key] - expected) for key, expected in SIZE_COUNTS.items()
            ),
        },
    )


def candidate_case(candidate: Candidate) -> dict[str, Any]:
    equations = sparse_equations(candidate)
    return {
        "schema_version": 1,
        "id": candidate.identifier,
        "variables": list(candidate.variables),
        "equations": equations,
        "canonical_hash": canonical_hash(equations),
        "mathematical_hash": mathematical_hash(equations),
    }


def candidate_manifest(candidate: Candidate, split: str, case: dict[str, Any]) -> dict[str, Any]:
    reference = dict(candidate.reference)
    if reference.get("witness"):
        reference["scaled_residual"] = scaled_residual(candidate, reference["witness"])
        if reference["scaled_residual"] <= 1e-7:
            reference["status"] = "source_witness_verified"
    return {
        "schema_version": 1,
        "id": candidate.identifier,
        "split": split,
        "title": candidate.title,
        "family_id": candidate.family_id,
        "problem_group_id": candidate.problem_group_id,
        "domain": candidate.domain,
        "case_path": f"cases/{candidate.identifier}.json",
        "case_sha256": sha256_bytes((canonical_json(case) + "\n").encode()),
        "canonical_hash": case["canonical_hash"],
        "mathematical_hash": case["mathematical_hash"],
        "source": candidate.source,
        "structure": structural_metadata(candidate),
        "reference": reference,
    }


def build(args) -> None:
    phc = Path(args.phcpack).resolve()
    pts = Path(args.polynomial_test_systems).resolve()
    require_upstream(phc, PHCPACK_COMMIT, "PHCpack")
    require_upstream(pts, PTS_COMMIT, "PolynomialTestSystems")
    candidates, exclusions = load_phc_candidates(phc)
    candidates.extend(load_pts_candidates(pts))
    candidates.extend(bertini_candidates())
    candidates.extend(phcpy_examples(phc))
    if len({item.identifier for item in candidates}) != len(candidates):
        raise CorpusError("duplicate candidate ID")

    development, evaluation, selection = choose_cases(candidates)
    selected = [(item, "development") for item in development] + [
        (item, "evaluation") for item in evaluation
    ]
    selected_ids = {item.identifier for item, _ in selected}
    for item in candidates:
        if item.identifier not in selected_ids:
            exclusions.append(
                {"id": item.identifier, "reason": "not selected by frozen balance/family rules"}
            )

    staging = Path(tempfile.mkdtemp(prefix="polynomial-corpus-", dir=CORPUS.parent))
    try:
        (staging / "cases").mkdir()
        manifest_rows = []
        for candidate, split in sorted(selected, key=lambda item: item[0].identifier):
            case = candidate_case(candidate)
            payload = canonical_json(case) + "\n"
            (staging / "cases" / f"{candidate.identifier}.json").write_text(
                payload, encoding="utf-8"
            )
            manifest_rows.append(candidate_manifest(candidate, split, case))
        (staging / "manifest.jsonl").write_text(
            "".join(canonical_json(row) + "\n" for row in manifest_rows), encoding="utf-8"
        )
        (staging / "exclusions.jsonl").write_text(
            "".join(
                canonical_json(row) + "\n" for row in sorted(exclusions, key=lambda row: row["id"])
            ),
            encoding="utf-8",
        )
        source_lock = {
            "schema_version": 1,
            "phcpack": {"url": PHCPACK_URL, "commit": PHCPACK_COMMIT, "license": "GPL-3.0-only"},
            "polynomial_test_systems": {"url": PTS_URL, "commit": PTS_COMMIT, "license": "MIT"},
            "bertini": {
                "url": BERTINI_ROOT,
                "retrieved": "2026-09-01",
                "license": "Bertini-policy",
            },
            "selection": selection,
        }
        atomic_json(staging / "sources.lock.json", source_lock)
        for target in (CASES, MANIFEST, EXCLUSIONS, SOURCE_LOCK, CORPUS_LOCK, AUDIT_REPORT):
            if target.is_dir():
                shutil.rmtree(target)
            elif target.exists():
                target.unlink()
        shutil.move(str(staging / "cases"), CASES)
        shutil.move(str(staging / "manifest.jsonl"), MANIFEST)
        shutil.move(str(staging / "exclusions.jsonl"), EXCLUSIONS)
        shutil.move(str(staging / "sources.lock.json"), SOURCE_LOCK)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    validate_corpus(require_frozen=False)
    write_audit()
    freeze_corpus()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as error:
            raise CorpusError(f"{path}:{line_number}: {error}") from error
    return rows


def sparse_witness_residual(case: dict[str, Any], witness: dict[str, list[str]]) -> float:
    mpmath.mp.dps = 80
    values = [mpmath.mpc(*witness[name]) for name in case["variables"]]
    radius = max(mpmath.mpf(1), *(abs(value) for value in values))
    maximum = mpmath.mpf(0)
    for equation in case["equations"]:
        value = mpmath.mpc(0)
        scale = mpmath.mpf(1)
        degree = 0
        for term in equation["terms"]:
            coefficient = Fraction(term["coefficient"])
            coefficient_mp = mpmath.mpf(coefficient.numerator) / coefficient.denominator
            monomial = mpmath.mpc(1)
            for variable, exponent in zip(values, term["exponents"], strict=True):
                monomial *= variable**exponent
            value += coefficient_mp * monomial
            term_degree = sum(term["exponents"])
            degree = max(degree, term_degree)
            scale += abs(coefficient_mp) * radius**term_degree
        maximum = max(maximum, abs(value) / scale)
    return float(maximum)


def import_certification(path: Path) -> dict[str, Any]:
    manifest = {row["id"]: row for row in read_jsonl(MANIFEST)}
    pending = {
        identifier
        for identifier, row in manifest.items()
        if row["reference"]["status"] == "reference_pending"
    }
    records = []
    for raw in read_jsonl(path):
        identifier = raw["id"]
        if identifier not in pending:
            raise CorpusError(f"certification is not for a pending case: {identifier}")
        if raw.get("status") != "completed" or raw.get("real_solutions", 0) < 1:
            raise CorpusError(f"no verified real solution: {identifier}")
        row = manifest[identifier]
        case = json.loads((CORPUS / row["case_path"]).read_text(encoding="utf-8"))
        witness = raw.get("witness")
        if not witness:
            raise CorpusError(f"missing certification witness: {identifier}")
        residual = sparse_witness_residual(case, witness)
        if residual > 1e-7:
            raise CorpusError(f"certification witness residual {residual}: {identifier}")
        record = {
            key: value
            for key, value in raw.items()
            if key not in {"solve_seconds", "certify_seconds"}
        }
        record["case_sha256"] = row["case_sha256"]
        record["witness_scaled_residual"] = residual
        records.append(record)
    ids = {record["id"] for record in records}
    if ids != pending or len(ids) != len(records):
        raise CorpusError(
            f"certification coverage mismatch: missing={sorted(pending - ids)}, "
            f"extra={sorted(ids - pending)}"
        )
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=CORPUS, prefix=".reference-certification.", delete=False
    ) as stream:
        temporary = Path(stream.name)
        for record in sorted(records, key=lambda item: item["id"]):
            stream.write(canonical_json(record) + "\n")
    temporary.replace(CERTIFICATION)
    return {"certified_pending_cases": len(records)}


def validate_corpus(*, require_frozen: bool = True) -> dict[str, Any]:
    rows = read_jsonl(MANIFEST)
    schema = json.loads((CORPUS / "schema.json").read_text(encoding="utf-8"))
    schema_validator = Draft202012Validator(schema)
    issues = []
    ids = [row.get("id") for row in rows]
    if len(rows) != 120 or len(set(ids)) != 120:
        issues.append(f"expected 120 unique cases, got {len(rows)}/{len(set(ids))}")
    splits = Counter(row.get("split") for row in rows)
    if splits != {"development": 20, "evaluation": 100}:
        issues.append(f"bad split counts: {dict(splits)}")
    dev_families = {row["family_id"] for row in rows if row["split"] == "development"}
    eval_families = {row["family_id"] for row in rows if row["split"] == "evaluation"}
    overlap = dev_families & eval_families
    if overlap:
        issues.append(f"family leakage: {sorted(overlap)}")
    family_counts = Counter(row["family_id"] for row in rows if row["split"] == "evaluation")
    if family_counts and max(family_counts.values()) > 5:
        issues.append(f"evaluation family exceeds five: {family_counts.most_common(1)}")
    seen_hashes: dict[str, str] = {}
    seen_mathematical: dict[str, dict[str, Any]] = {}
    for row in rows:
        path = CORPUS / row["case_path"]
        if not path.is_file():
            issues.append(f"missing case: {path}")
            continue
        case = json.loads(path.read_text(encoding="utf-8"))
        schema_errors = sorted(
            schema_validator.iter_errors(case), key=lambda error: list(error.path)
        )
        for error in schema_errors:
            issues.append(f"schema error {row['id']}: {error.message}")
        expected_payload = canonical_json(case) + "\n"
        if path.read_text(encoding="utf-8") != expected_payload:
            issues.append(f"noncanonical JSON: {row['id']}")
        if sha256_bytes(expected_payload.encode()) != row["case_sha256"]:
            issues.append(f"case hash mismatch: {row['id']}")
        if (
            case["id"] != row["id"]
            or case["canonical_hash"] != row["canonical_hash"]
            or case["mathematical_hash"] != row["mathematical_hash"]
        ):
            issues.append(f"manifest/case mismatch: {row['id']}")
        if canonical_hash(case["equations"]) != case["canonical_hash"]:
            issues.append(f"bad canonical hash: {row['id']}")
        if mathematical_hash(case["equations"]) != case["mathematical_hash"]:
            issues.append(f"bad mathematical hash: {row['id']}")
        if (
            len(case["variables"]) != len(case["equations"])
            or not 2 <= len(case["variables"]) <= 12
        ):
            issues.append(f"not square or outside size scope: {row['id']}")
        previous = seen_hashes.setdefault(case["canonical_hash"], row["id"])
        if previous != row["id"]:
            issues.append(f"exact duplicate: {previous}, {row['id']}")
        equivalent = seen_mathematical.setdefault(case["mathematical_hash"], row)
        if equivalent["id"] != row["id"] and (
            equivalent["problem_group_id"] != row["problem_group_id"]
            or equivalent["domain"] != "numerical_stress"
            or row["domain"] != "numerical_stress"
        ):
            issues.append(f"unexplained mathematical duplicate: {equivalent['id']}, {row['id']}")
        for equation in case["equations"]:
            for term in equation["terms"]:
                if len(term["exponents"]) != len(case["variables"]):
                    issues.append(f"bad exponent arity: {row['id']}")
                Fraction(term["coefficient"])
    pending_ids = {row["id"] for row in rows if row["reference"]["status"] == "reference_pending"}
    if CERTIFICATION.exists():
        certificates = read_jsonl(CERTIFICATION)
        certificate_ids = {record.get("id") for record in certificates}
        if certificate_ids != pending_ids or len(certificate_ids) != len(certificates):
            issues.append("reference certification coverage mismatch")
        by_id = {row["id"]: row for row in rows}
        for record in certificates:
            identifier = record.get("id")
            if identifier not in by_id:
                continue
            row = by_id[identifier]
            if record.get("case_sha256") != row["case_sha256"]:
                issues.append(f"reference certification case mismatch: {identifier}")
            if record.get("status") != "completed" or record.get("real_solutions", 0) < 1:
                issues.append(f"reference certification has no real solution: {identifier}")
            if record.get("witness_scaled_residual", 1) > 1e-7:
                issues.append(f"bad reference certification witness: {identifier}")
    elif require_frozen and pending_ids:
        issues.append("reference-certification.jsonl is missing")
    if require_frozen and not CORPUS_LOCK.exists():
        issues.append("corpus.lock.json is missing")
    if issues:
        raise CorpusError("\n".join(issues))
    return {
        "cases": len(rows),
        "splits": dict(splits),
        "domains": dict(Counter(row["domain"] for row in rows if row["split"] == "evaluation")),
        "sizes": dict(
            Counter(
                size_bucket(row["structure"]["variable_count"])
                for row in rows
                if row["split"] == "evaluation"
            )
        ),
        "families": len(eval_families),
        "homotopy_reference_cases": len(pending_ids) if CERTIFICATION.exists() else 0,
    }


def lock_files() -> list[Path]:
    files = [
        MANIFEST,
        EXCLUSIONS,
        SOURCE_LOCK,
        AUDIT_REPORT,
        CERTIFICATION,
        CORPUS / "README.md",
        CORPUS / "PROTOCOL.md",
        CORPUS / "schema.json",
        ROOT / "benchmarks" / "__init__.py",
        ROOT / "benchmarks" / "polynomial_corpus.py",
    ]
    files.extend(sorted((CORPUS / "LICENSES").glob("*")))
    files.extend(sorted((CORPUS / "julia").glob("*")))
    files.extend(sorted(CASES.glob("*.json")))
    return files


def freeze_corpus() -> None:
    lock = {
        "schema_version": 1,
        "corpus_version": "polynomial-v1",
        "files": {str(path.relative_to(ROOT)): sha256_file(path) for path in lock_files()},
    }
    lock["root_sha256"] = sha256_bytes(canonical_json(lock["files"]).encode())
    atomic_json(CORPUS_LOCK, lock)


def verify_lock() -> dict[str, Any]:
    lock = json.loads(CORPUS_LOCK.read_text(encoding="utf-8"))
    actual = {str(path.relative_to(ROOT)): sha256_file(path) for path in lock_files()}
    if actual != lock["files"]:
        missing = sorted(set(lock["files"]) - set(actual))
        changed = sorted(
            key for key in set(actual) & set(lock["files"]) if actual[key] != lock["files"][key]
        )
        extra = sorted(set(actual) - set(lock["files"]))
        raise CorpusError(f"lock mismatch: missing={missing}, changed={changed}, extra={extra}")
    if sha256_bytes(canonical_json(actual).encode()) != lock["root_sha256"]:
        raise CorpusError("root hash mismatch")
    return {"files": len(actual), "root_sha256": lock["root_sha256"]}


def write_audit() -> None:
    summary = validate_corpus(require_frozen=False)
    rows = read_jsonl(MANIFEST)
    references = Counter(row["reference"]["status"] for row in rows)
    text = "\n".join(
        [
            "# Polynomial corpus audit",
            "",
            "- Corpus: `polynomial-v1`",
            f"- Cases: {summary['cases']} (development 20, evaluation 100)",
            f"- Evaluation families: {summary['families']}",
            f"- Evaluation domains: `{canonical_json(summary['domains'])}`",
            f"- Evaluation size buckets: `{canonical_json(summary['sizes'])}`",
            f"- Reference evidence: `{canonical_json(dict(references))}`",
            f"- Independent homotopy reference cases: {summary['homotopy_reference_cases']}",
            "- Exact duplicate hashes: 0",
            "- Development/evaluation family overlap: 0",
            "",
            "`source_witness_verified` means only that a published approximate witness has",
            "small scaled residual in the exact committed equations. It is not a claim of",
            "root-list completeness. `reference_pending` means the upstream source did",
            "not print a witness; all such cases are covered by the separately stored,",
            "case-hash-bound Julia homotopy reference pass.",
            "",
        ]
    )
    AUDIT_REPORT.write_text(text, encoding="utf-8")


def audit() -> dict[str, Any]:
    summary = validate_corpus()
    verify_lock()
    rows = read_jsonl(MANIFEST)
    summary["reference_status"] = dict(Counter(row["reference"]["status"] for row in rows))
    summary["domain_target"] = DOMAIN_COUNTS
    summary["size_target"] = SIZE_COUNTS
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    build_parser = subparsers.add_parser("build")
    build_parser.add_argument("--phcpack", required=True)
    build_parser.add_argument("--polynomial-test-systems", required=True)
    subparsers.add_parser("validate")
    subparsers.add_parser("audit")
    subparsers.add_parser("freeze")
    subparsers.add_parser("verify-lock")
    import_parser = subparsers.add_parser("import-certification")
    import_parser.add_argument("--input", required=True)
    args = parser.parse_args()
    if args.command == "build":
        build(args)
        result = audit()
    elif args.command == "validate":
        result = validate_corpus()
    elif args.command == "audit":
        result = audit()
    elif args.command == "freeze":
        validate_corpus(require_frozen=False)
        freeze_corpus()
        result = verify_lock()
    elif args.command == "import-certification":
        result = import_certification(Path(args.input))
    else:
        result = verify_lock()
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
