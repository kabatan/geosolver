"""Build a new complete campaign from immutable, contract-matched segments.

Used for interrupted measurements and sequential per-seed runs. Existing raw
artifacts are never overwritten, and temporary worker output is never a run.
"""

import argparse
import hashlib
import json
import shutil
from pathlib import Path


def merge(template: Path, sources: list[Path], destination: Path):
    if destination.exists():
        raise ValueError("destination must not exist")
    manifest = json.loads((template / "campaign-manifest.json").read_text())
    planned = {
        (row["id"], seed): row
        for row in manifest["cases"]
        for seed in manifest["config"]["seeds"]
        if row["authoring_status"] == "runnable"
    }
    found = {}
    segments = []
    for source in sources:
        source_manifest_path = source / "campaign-manifest.json"
        other = json.loads(source_manifest_path.read_text())
        for field in ("source_hash", "dependency_lock_hash"):
            if manifest[field] != other[field]:
                raise ValueError(f"segment mismatch: {field}")
        for field in ("time_limit_seconds", "cores", "thread_environment"):
            if manifest["config"][field] != other["config"][field]:
                raise ValueError(f"segment configuration mismatch: {field}")
        included = 0
        for path in sorted((source / "runs").glob("*/*.json")):
            if not path.stem.isdigit():
                continue
            raw = json.loads(path.read_text())
            key = raw["case_id"], raw["seed"]
            if key not in planned:
                raise ValueError(f"unplanned run: {key}")
            if raw["problem_hash"] != planned[key]["problem_hash"]:
                raise ValueError(f"problem mismatch: {key}")
            if any(
                raw[field] != manifest[field] for field in ("source_hash", "dependency_lock_hash")
            ):
                raise ValueError(f"run identity mismatch: {key}")
            # Prefer the earliest fully committed run; never choose by outcome.
            if key not in found:
                found[key] = path
                included += 1
        segments.append(
            {
                "source": str(source),
                "included_runs": included,
                "manifest_sha256": hashlib.sha256(source_manifest_path.read_bytes()).hexdigest(),
            }
        )
    if set(found) != set(planned):
        raise ValueError(f"missing runs: {sorted(set(planned) - set(found))}")
    destination.mkdir(parents=True)
    manifest["measurement_segments"] = segments
    for (identifier, seed), source in found.items():
        target = destination / "runs" / identifier / f"{seed}.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    (destination / "campaign-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("template", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("sources", type=Path, nargs="+")
    args = parser.parse_args()
    merge(args.template, args.sources, args.destination)
