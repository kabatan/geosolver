"""Profile a bounded worker solve without mixing profiling into campaign timings."""

import argparse
import cProfile
import io
import json
import os
import pstats
import time
from pathlib import Path

from geosolver.problem.models import GeometryProblem
from geosolver.runtime.integrity import source_tree_hash
from geosolver.runtime.protocol import WorkerRequest
from geosolver.runtime.worker import execute


def profile(problem_path, destination, seconds, seed):
    from geosolver.platform.processes import set_affinity

    set_affinity(os.getpid(), 1)
    problem = GeometryProblem.model_validate_json(problem_path.read_text())
    destination.mkdir(parents=True, exist_ok=True)
    request = WorkerRequest(
        engine_document=problem.engine_document(),
        seed=seed,
        deadline_monotonic=time.monotonic() + seconds,
    )
    profiler = cProfile.Profile()
    result = profiler.runcall(execute, request)
    profiler.dump_stats(str(destination / "worker.prof"))
    stream = io.StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.sort_stats("cumulative").print_stats(80)
    stats.sort_stats("tottime").print_stats(40)
    (destination / "profile.txt").write_text(stream.getvalue())
    (destination / "profile-manifest.json").write_text(
        json.dumps(
            {
                "source_hash": source_tree_hash(),
                "problem_path": str(problem_path),
                "seed": seed,
                "budget_seconds": seconds,
                "status": result.status,
                "termination_reason": result.termination_reason,
                "elapsed_seconds": result.elapsed_seconds,
                "phase_timings": result.phase_timings,
                "counters": result.counters,
                "note": "Instrumented worker time; excluded from campaign performance comparisons.",
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("problem", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--seconds", type=float, default=30)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    profile(args.problem, args.destination, args.seconds, args.seed)
