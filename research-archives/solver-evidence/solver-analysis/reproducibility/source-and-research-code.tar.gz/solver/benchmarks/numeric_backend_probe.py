"""Isolated arithmetic backend measurements and a native-float compatibility probe."""

import argparse
import json
import math
import os
import statistics
import time
from pathlib import Path

from mpmath import mp
from mpmath.libmp import BACKEND


def measure():
    from geosolver.platform.processes import set_affinity

    set_affinity(os.getpid(), 1)
    measurements = []
    for precision in (50, 180, 500):
        repeats, signature = [], None
        for _ in range(3):
            started = time.perf_counter()
            with mp.workdps(precision):
                a = mp.matrix(
                    [[mp.mpf(1) / (i + j + 1) + (i == j) for j in range(8)] for i in range(8)]
                )
                b = mp.matrix([mp.sqrt(i + 2) for i in range(8)])
                for _index in range(40):
                    x = mp.lu_solve(a, b)
                    value = mp.sqrt(mp.fsum(item * item for item in x)) + mp.sin(mp.pi / 7)
                signature = mp.nstr(value, 40)
            repeats.append(time.perf_counter() - started)
        measurements.append(
            {
                "dps": precision,
                "seconds": repeats,
                "median_seconds": statistics.median(repeats),
                "signature": signature,
            }
        )
    # A naive math/fp substitution has the same significand width but a much
    # smaller exponent range. An intermediate cross product can underflow even
    # when the resulting angle is ordinary and representable.
    with mp.workprec(53):
        tiny = mp.mpf("1e-200")
        mp_angle = float(mp.atan2(tiny * tiny, mp.mpf(0)))
    float_angle = math.atan2(1e-200 * 1e-200, 0.0)
    return {
        "mpmath_backend": BACKEND,
        "workloads": measurements,
        "native_float_probe": {
            "mpmath_53bit_angle": mp_angle,
            "native_angle": float_angle,
            "drop_in_compatible": mp_angle == float_angle,
        },
        "scope": (
            "Arithmetic microbenchmark, not solver campaign time; no production backend change."
        ),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(measure(), indent=2) + "\n")
