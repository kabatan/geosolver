# GeoSolver

GeoSolverは、有限個の値を答えとして持つ2次元幾何問題を数値探索し、可能な場合は厳密な答えdescriptorを返すsolverです。網羅性は証明せず、結果の`completeness`は常に`unknown`です。

この`research`ブランチでは、固定した幾何solverと、多分野の代数・非線形連立方程式ベンチマークを管理します。
研究作業の入口は[研究ガイド](docs/research/README.md)です。入力、比較harness、作成中の候補、
検証証跡の配置と、評価を始めるための手順をまとめています。

[practical-discovery-v1](benchmarks/algebra_large/practical_v1/README.md)は検証済み300入力・243モデル群の多分野ケース集です。
幾何323問は開発用、polynomial-v1の120問は既存の固定入力、algebra-v2/v3とlarge catalogueは旧集合・候補・原典証跡です。
これらを同一の評価集合として合算しません。solverの固定版は以下のtagで識別します。

## 固定版と再現性

2026-09-01に、修正・整理後のsolverをannotated tag **`solver-a1`** として固定しました。
再現には移動し得る`research`のHEADではなく、このtagを指定してください。
実装・既定設定・依存・評価入力を変更して固定し直す場合は、新しいtagを作成し、既存tagを移動しません。

- 実装・既定設定・依存の識別：`src/geosolver/engine-lock.json`。
- 依存の再現：Python 3.12、`uv.lock`、`uv sync --all-extras --frozen`。
- 開発用入力：`benchmarks/cases.jsonl`と対応する323問の`benchmarks/dsl/`。
- 正式な研究実行：Linux、180秒／問題、1物理コア／job、seed 0を基準とする。反復実験のseed列は実行前に別途固定する。
- 実行の識別：runnerがcommit、ソース・入力のhash、設定、環境を記録します。

`engine-lock.json`は固定した実装と実行契約の整合性を検査します。
tagの注釈にもソース・設定・依存・入力のhashと検証範囲を記録しています。

固定前のLinux検証は、1040テスト（失敗・skipなし）、323問の静的整合性、Ruff、schema、
compileall、2通りのfresh-process import、engine lock・導入依存照合を通過しました。
`uv.lock`の依存バージョンを使う独立wheel環境で、CLI・worker・代数的数およびπを含む厳密値返却も確認しました。
commit後に作業ツリーがcleanであることを確認してtagを付けています。

2026-09-01の固定時には323問の求解評価を再実行しておらず、過去の測定値をその固定ソースの成績とは扱いません。
同日の固定時にはWindows／macOSの実機検証は未実施です。固定は、欠陥不存在や全解発見の保証ではありません。

## 実験記録の保存先

過去のsolver改善・GMB比較の結果は `experiment` ブランチに移管しました。
[保存先と閲覧方法](docs/research/experiment-archive.md)を参照してください。
`research` はsolver・ベンチマーク入力・再検証証拠・再利用する実行コードを管理します。

## 対応環境

単一の`standard` engineをLinux、Windows、macOSで提供します。既定は180秒・1コアで、一般APIでは180〜900秒と正の整数コア数を指定できます。研究用の正式実行は180秒・1コアに固定します。

core指定は使用上限です。現在のsolver内部は1 coreで実行し、問題単位の並列化は研究runnerの`--jobs`で行います。

## インストールとCLI

Python 3.12を用意してください。

```bash
uv sync --all-extras --frozen
uv run geosolver doctor
uv run geosolver validate path/to/problem.json
uv run geosolver solve path/to/problem.json --output result.json
uv run geosolver catalog --json
```

`standard`のNOMAD検索にはNOMAD 4の`PyNomadBBO`を使用します。対応wheelがない環境ではSciPyフォールバックになります。

CLIは`validate`、`solve`、`doctor`、`catalog`を提供します。

## Python API

```python
from geosolver import GeometryProblem, SolveOptions, solve, validate

problem = GeometryProblem(
    id="example",
    variables=["x"],
    constructions=[],
    conditions=[{"left": "x", "operator": "=", "right": 1}],
    target="x",
)

assert validate(problem).valid
result = solve(problem, SolveOptions(time_limit_seconds=180, cores=1))
```

互換layerはありません。正式なpackage/import/CLI名はすべて`geosolver`です。

## 問題JSON

```json
{
  "id": "example",
  "variables": ["x"],
  "constructions": [
    {"name": "A", "expression": "Point(0, 0)"},
    {"name": "B", "expression": "Point(x, 0)"},
    {"name": "C", "expression": "Point(x/2, 1)"}
  ],
  "conditions": [
    {"left": "x", "operator": "=", "right": 1},
    {"left": "x", "operator": ">=", "right": 0},
    {"predicate": "AcuteTriangle(A, B, C)"}
  ],
  "target": "Distance(A, B)"
}
```

relation operatorは`=`、`!=`、`<`、`<=`、`>`、`>=`です。`right`はbooleanを認めず、整数、浮動小数、厳密式文字列を型を保ったまま扱います。幾何関数とpredicateの一覧は`geosolver catalog --json`で確認できます。

DSL 1.1では`PointOnSegment(A,B,t)`は相異なる端点と`0≤t≤1`を要求します。
延長上の点には`PointOnLine`を使いますが、パラメータの基準が異なるため、単なる関数名の置換はできません。
`PointOnCircle`のパラメータは任意の実数、`PointOnArc`は`[0,1]`、
`InscribedPolygon`の配置パラメータはすべて`(0,1)`です。
長い小数を入力する場合は式文字列を使ってください。呼び出し元で既にPython floatへ丸めた値の原文は復元できません。

## 数値評価

solverの通常精度の構成評価には、53 bitに設定した数値専用の幾何関数を使います。
`PointOnCircle`や後続の交点計算にSymPyの数式を持ち回りません。記号計算用の幾何関数は別に維持します。
高精度評価・最終検証の作業精度を通常精度へ下げる変更ではありません。

構成の依存関係と条件は問題単位で準備し、必要な構成から評価します。
変数に依存する結果は、同一の座標・演算種別・精度のときだけ、問題ごとの上限付きcacheで共有します。
近い別座標を同一視せず、交点の枝と関数呼び出しの検査記録も再利用時に引き継ぎます。
残差に不要な構成も、最終的な配置検査からは除外しません。
変数に依存しない構成は、異なる座標でも演算種別・精度ごとに再利用します。
論理条件の等式部分は、原文と枝の選択順序を保持した共有表現で評価します。

高精度の型検査は、既知のスカラー型の判定を簡略化し、エラー位置の文字列は混入を検出したときだけ作ります。
辞書・配列の検査結果は保存せず、再呼び出し時も中身を確認します。後から変更された値や、入れ子に混入したPython・NumPy・SymPyの浮動小数も検出します。

## 厳密結果

- `algebraic`: 整数係数多項式、実根番号、隔離区間、十進近似。
- `affine_pi`: 代数的数のπ係数と代数的な定数項、十進近似。

ラジアンの`π/2`は`affine_pi`、`Degrees(...)`で変換した`90`は`algebraic`です。workerのcrash、artifact欠落、artifact破損は`engine_error`であり、正常探索後の`no_answer_found`とは区別されます。

最終検証は通常120・180桁、未確定時は最大500桁まで評価し、枝変更や禁止境界への近さを検査します。
これは数値誤差の推定を伴う検証であり、一般的な存在証明ではありません。
名前付きの構成だけでなく、条件・目的式・guardに直接書かれた図形にも非退化性の検査を適用します。
低精度の予備確認でも保持済みの高精度座標は丸め直しません。
同じ座標を作業精度と追加30桁で比較し、幾何関数内部の相殺による丸め誤差も見積もります。
面積0・接線条件0の等式は検証時だけ同値な符号付き残差を使い、公開の`Area`・`IsTangent`や目的式の意味は維持します。
候補の`answer_precision_dps`は作業精度であり、全桁の正確さを保証しません。
厳密化は記録された不確かさから候補発見用の精度を選び、元の作業精度・誤差範囲で最終照合します。
内部の厳密化記録には`discovery_precision_dps`を併記します。
内部期限で正常に打ち切った場合は完成済みの答えを保持し、`termination_reason=time_limit_reached`を返します。
精密化の途中で期限が切れた場合も、最後の改善済み座標を未検証の候補として保持します。
残り時間で最終検証と厳密化を通ったものだけを答えに含め、未検証の候補値は公開しません。

## 開発

```bash
uv run python -m pytest --import-mode=importlib
uv run ruff check src tests benchmarks .github/scripts
```

研究用campaign runnerと評価資料はwheelへ含めず、repo内で管理します。

```bash
uv run python benchmarks/research_runner.py validate
uv run python benchmarks/research_runner.py run benchmarks/local-evaluation/my-run --jobs 16 --seeds 0
uv run python benchmarks/research_runner.py assess benchmarks/local-evaluation/my-run
uv run python benchmarks/research_runner.py summarize benchmarks/local-evaluation/my-run
```

正式実行はclean tree、engine lock、実際のimport元・依存version・CPU affinityの一致を要求します。
開発途中の実行だけは`run --allow-dirty`で明示的に許可できます。
worker protocolはv4です。候補revisionと保存完了通知を照合し、期限内にatomic保存が完了した結果だけを受理します。
過去のv3 artifactは読取adapterで扱い、書き換えません。

solver側の一時実行結果・profile・ソース複製は`benchmarks/local-evaluation/`へ出力し、
不要になったものは削除します。GMBの実行記録・比較記録は別に保持します。
`dist/`と`build/`は配布物の生成先で、通常実行には不要です。`uv build`で必要時に再生成できます。
回帰テストと`tests/fixtures/`は実行結果ではなく、現行の検証に必要な入力として残します。

323問は既にsolver開発に使用した集合であり、未使用の評価集合ではありません。
問題・出典・履歴の参照方法は[benchmark説明](benchmarks/README.md)を参照してください。
研究計画書`JSSA_2026_REPORT_AND_EXPERIMENT_PLAN.md`はローカル専用で、Gitの追跡対象外です。

## 作業場所

通常の作業場所は`/home/kabatan/work/solver`直下、ブランチは`research`です。
作業用worktreeは追加しません。
